/** @type {import('tailwindcss').Config} */
export default { content: ['./index.html', './src/**/*.{ts,tsx}'], theme: { extend: { colors: { navy: '#103b75', gold: '#f4bf35' } } }, plugins: [] };
