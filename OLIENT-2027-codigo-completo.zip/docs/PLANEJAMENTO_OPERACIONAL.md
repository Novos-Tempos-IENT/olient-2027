# Planejamento operacional e gerador de jogos

## O que está implementado nesta etapa

- Motor puro de calendário para todos-contra-todos, janelas por quadra, bloqueios, duração, intervalo, descanso, detecção de capacidade insuficiente e prévia cronológica/por quadra.
- Testes unitários do cálculo de confrontos, determinismo, bloqueios, descanso e insuficiência.
- Primeira migration versionada para janelas de disponibilidade, sorteios, gerações de agenda, RLS e políticas de administrador para inscrições oficiais e partidas.
- Tela administrativa de partidas mostra prévia apenas com equipes em `registrations.status = 'approved'`; a prévia não grava nem publica partidas.
- Formatos eliminatórios ficam desabilitados até haver implementação explícita de chaves, folgas e avanço de vencedores.

## Pendências antes de uso operacional

1. Aplicar e revisar `202610260004_tournament_scheduler.sql` no projeto Supabase não foi possível; nenhum banco foi fornecido.
2. Implementar um formulário administrativo para criar/editar `court_availability`, com múltiplos intervalos por quadra/data e restrições por equipe.
3. Implementar RPC transacional que valide inscrições aprovadas, datas, disponibilidade oficial, pausas, sobreposição de quadra/equipe, descanso, idempotência e grava geração + partidas como rascunho. A tentativa inicial de migration não deve ser considerada pronta para produção sem revisão SQL e aplicação em ambiente de teste.
4. Implementar RPCs auditáveis para sorteio persistido, substituição mediante confirmação, publicação e alterações após publicação; preservar partidas com resultados/pontuação.
5. Para inscrição de equipe por aluno, configurar identidade escolar confiável ligada a `auth.uid()`. A tabela `students` atual não possui vínculo seguro com `auth.users`; não se deve aceitar nome/código autodeclarado como prova de identidade.
6. Implementar submissão/validação de equipe e fluxo de aprovação, respeitando período de inscrições e evitando duplicidade dos integrantes.
7. Criar criação manual de confrontos e visualização de tabela publicada.
8. Integrar gincana administrativa exclusivamente a RPCs e RLS com permissão de administrador.

Não usar este módulo para criar agenda oficial enquanto essas etapas não forem concluídas e testadas contra Supabase.
