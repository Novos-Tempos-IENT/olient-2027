# Importar no Lovable

Este repositório usa padrões web (React, TypeScript, Vite, Tailwind) e Supabase externo; não requer backend proprietário do Lovable.

1. Importe o repositório/código-fonte no Lovable como projeto React/Vite. Se importar ZIP, extraia a raiz do projeto sem `node_modules`, `.env` ou `dist`.
2. Configure `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` nos secrets/variáveis de ambiente do projeto. Use apenas a chave publicável; nunca inclua `service_role`.
3. Configure Auth URL/site URL e redirects para os domínios local e publicado.
4. Aplique as migrations versionadas em `supabase/migrations/` na ordem, usando Supabase CLI conectado ao projeto externo. Não peça para o Lovable recriar ou substituir o banco automaticamente.
5. Faça build e teste de autenticação, RLS com sessão anônima e autenticada, bootstrap inicial, leitura de publicações, consulta de classificação e confirmação/reversão de resultado em ambiente não produtivo.
6. Confirme que o app continua apontando ao Supabase escolhido e que os secrets estão configurados no ambiente de deploy. Repita build após alterações feitas no editor.

A importação foi documentada, mas não validada nesta instância: não há projeto Lovable ou Supabase conectado e não foram fornecidas credenciais.
