-- Carga de inscrições de teste usando exclusivamente os cadastros importados.
-- Run only on the test dataset requested by the administrator.
begin;
do $$
begin
 if not exists(select 1 from public.profiles where role='administrator') then
  raise exception 'Nenhum administrador cadastrado para identificar o responsável pela carga de teste';
 end if;
end $$;
alter table public.students add column if not exists gender text check(gender in ('male','female'));
insert into team_sports(team_id,sport_id,enabled,lock_approved,updated_by)
select t.id,s.id,true,false,(select id from profiles where role='administrator' order by id limit 1) from teams t cross join sports s
where t.active and t.deleted_at is null and s.active and s.status='active'
on conflict(team_id,sport_id) do update set enabled=true,updated_by=excluded.updated_by;
insert into team_student_sports(team_id,student_id,sport_id,status,review_note,updated_at,updated_by)
select distinct m.team_id,m.student_id,s.id,'approved',null,now(),(select id from profiles where role='administrator' order by id limit 1)
from team_students m join teams t on t.id=m.team_id and t.active and t.deleted_at is null
join students st on st.id=m.student_id and st.active and st.deleted_at is null
cross join sports s where m.left_at is null and s.active and s.status='active'
on conflict(team_id,student_id,sport_id) do update set status='approved',review_note=null,updated_at=now(),updated_by=excluded.updated_by;
with entries as (
 select distinct t.id team_id,s.id sport_id,
 case when t.name ~ '^\s*[67]' then '6º e 7º anos' when t.name ~ '^\s*[1289]' then '8º, 9º, 1º e 2º anos' end base,
 case when upper(s.name) ~ 'BASQUETE|FUTSAL|FUTMESA|TÊNIS DE MESA|TENIS DE MESA|VÔLEI DE MESA|VOLEI DE MESA' then case st.gender when 'male' then 'Masculino' when 'female' then 'Feminino' end else 'Misto' end division
 from teams t join team_students m on m.team_id=t.id and m.left_at is null
 join students st on st.id=m.student_id and st.active and st.deleted_at is null
 cross join sports s where t.active and t.deleted_at is null and s.active and s.status='active'
)
insert into registrations(team_id,sport_id,category,status)
select team_id,sport_id,base||case when division='Misto' then '' else ' · '||division end,'approved'
from entries where base is not null and division is not null
on conflict(team_id,sport_id,category) do update set status='approved',updated_at=now();
commit;
select t.name,count(distinct st.id) alunos,count(distinct ss.sport_id) modalidades
from teams t join team_students m on m.team_id=t.id and m.left_at is null
join students st on st.id=m.student_id join team_student_sports ss on ss.team_id=t.id and ss.student_id=st.id
where st.active and st.deleted_at is null and ss.status='approved'
group by t.name order by t.name;

