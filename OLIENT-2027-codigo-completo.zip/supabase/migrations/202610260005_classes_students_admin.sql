-- Permit authenticated requests to reach the existing admin-only RLS policies.
-- The policies in 202610260003_rls_policies.sql continue to restrict writes to administrators.
grant insert on public.classes, public.students to authenticated;
