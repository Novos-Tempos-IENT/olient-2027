-- Allow real future-stage slots without inventing participating teams.
alter table public.matches alter column home_team_id drop not null;
alter table public.matches alter column away_team_id drop not null;
alter table public.matches add column if not exists home_placeholder text;
alter table public.matches add column if not exists away_placeholder text;
create or replace function public.publish_multi_sport_schedule(
  p_idempotency_key text, p_config jsonb, p_result jsonb
) returns uuid
language plpgsql security definer set search_path=public as $$
declare
  batch_id uuid;
  item jsonb;
  sport_config jsonb;
  fixture_start timestamptz;
  fixture_end timestamptz;
  event_day date;
  duration_value integer;
  fixture_key_value text;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if nullif(trim(p_idempotency_key),'') is null then raise exception 'Idempotency key required'; end if;
  if exists(select 1 from jsonb_array_elements(coalesce(p_result->'unscheduled','[]'::jsonb))) then
    raise exception 'Cannot publish a schedule with fixtures without times';
  end if;
  if jsonb_array_length(coalesce(p_config->'sports','[]'::jsonb)) = 0
     or jsonb_array_length(coalesce(p_result->'scheduled','[]'::jsonb)) = 0 then
    raise exception 'No sports or fixtures were provided';
  end if;
  if coalesce((p_config->>'interval_minutes')::integer,0)<0 or coalesce((p_config->>'team_rest_minutes')::integer,0)<0 then
    raise exception 'Schedule intervals cannot be negative';
  end if;
  if exists(select 1 from sports s where s.active and s.status='active'
    and not exists(select 1 from jsonb_array_elements(p_config->'sports') c where c->>'sport_id'=s.id::text)) then
    raise exception 'Every active sport must be included in the batch configuration';
  end if;
  select id into batch_id from schedule_batches where idempotency_key=p_idempotency_key;
  if batch_id is not null then return batch_id; end if;

  insert into schedule_batches(config,result,created_by,idempotency_key)
    values(p_config,p_result,auth.uid(),p_idempotency_key) returning id into batch_id;

  for item in select value from jsonb_array_elements(p_result->'scheduled') loop
    if item->>'sport_id' is null or item->>'home' is null or item->>'away' is null then
      raise exception 'Fixture has unresolved participants or sport';
    end if;
    select value into sport_config from jsonb_array_elements(p_config->'sports') c(value)
      where c.value->>'sport_id'=item->>'sport_id';
    if sport_config is null then raise exception 'Fixture sport is absent from the batch configuration'; end if;
    if not exists(select 1 from sports s where s.id=(item->>'sport_id')::uuid and s.active and s.status='active') then
      raise exception 'Fixture sport is not active';
    end if;
    if sport_config->>'format' not in ('round_robin','knockout','groups') then raise exception 'Unsupported sport format'; end if;
    if sport_config->>'format'='groups' and (sport_config->>'advancing_per_group')::integer<>2 then
      raise exception 'Group format must advance the top two teams from each group';
    end if;
    if not (sport_config->'venues' ? (item->>'court')) then raise exception 'Fixture venue is not allowed for its sport'; end if;
    event_day := (item->>'date')::date;
    duration_value := (item->>'duration')::integer;
    if duration_value < 1 or (sport_config->>'duration')::integer <> duration_value
      or not (sport_config->'dates' ? event_day::text) then raise exception 'Fixture date or duration does not match its sport configuration'; end if;
    fixture_start := ((item->>'date') || ' ' || (item->>'start'))::timestamp at time zone 'America/Sao_Paulo';
    fixture_end := ((item->>'date') || ' ' || (item->>'end'))::timestamp at time zone 'America/Sao_Paulo';
    if fixture_end <= fixture_start or extract(epoch from (fixture_end-fixture_start))/60 <> duration_value then
      raise exception 'Fixture has an invalid time range';
    end if;
    if (item->>'home' not like 'A definir%' and not exists(select 1 from registrations r where r.sport_id=(item->>'sport_id')::uuid
      and r.category is not distinct from nullif(item->>'category','')
      and r.team_id=(case when item->>'home' like 'A definir%' then null else item->>'home' end)::uuid and r.status='approved'))
      or (item->>'away' not like 'A definir%' and not exists(select 1 from registrations r where r.sport_id=(item->>'sport_id')::uuid
      and r.category is not distinct from nullif(item->>'category','')
      and r.team_id=(case when item->>'away' like 'A definir%' then null else item->>'away' end)::uuid and r.status='approved')) then
      raise exception 'Fixture includes a team not approved for this sport and category';
    end if;
    if exists(select 1 from teams t where t.id in ((case when item->>'home' like 'A definir%' then null else item->>'home' end)::uuid,(case when item->>'away' like 'A definir%' then null else item->>'away' end)::uuid)
      and (not t.active or t.deleted_at is not null)) then raise exception 'Fixture includes an inactive team'; end if;
    if not exists(select 1 from court_availability ca where ca.court_name=item->>'court'
      and (ca.available_from at time zone 'America/Sao_Paulo')::date=event_day
      and fixture_start>=ca.available_from and fixture_end<=ca.available_until
      and not exists(select 1 from jsonb_array_elements(coalesce(ca.blocked_windows,'[]'::jsonb)||coalesce(ca.pause_windows,'[]'::jsonb)) b
        where fixture_start < ((event_day::text||' '||(b->>'end'))::timestamp at time zone 'America/Sao_Paulo')
          and fixture_end > ((event_day::text||' '||(b->>'start'))::timestamp at time zone 'America/Sao_Paulo')))
      then raise exception 'Fixture is outside official availability or overlaps a blocked period';
    end if;
    if exists(select 1 from matches m where m.deleted_at is null and coalesce(m.schedule_status,'draft')<>'cancelled'
      and m.court_name=item->>'court'
      and m.scheduled_at < fixture_end+make_interval(mins=>coalesce((p_config->>'interval_minutes')::integer,0))
      and m.scheduled_at+make_interval(mins=>coalesce(m.duration_minutes,0)) > fixture_start-make_interval(mins=>coalesce((p_config->>'interval_minutes')::integer,0))) then
      raise exception 'Court time conflict with an existing match';
    end if;
    if exists(select 1 from matches m where m.deleted_at is null and coalesce(m.schedule_status,'draft')<>'cancelled'
      and (m.home_team_id in ((case when item->>'home' like 'A definir%' then null else item->>'home' end)::uuid,(case when item->>'away' like 'A definir%' then null else item->>'away' end)::uuid)
        or m.away_team_id in ((case when item->>'home' like 'A definir%' then null else item->>'home' end)::uuid,(case when item->>'away' like 'A definir%' then null else item->>'away' end)::uuid))
      and m.scheduled_at < fixture_end + make_interval(mins=>coalesce((p_config->>'team_rest_minutes')::integer,0))
      and m.scheduled_at+make_interval(mins=>coalesce(m.duration_minutes,0)) > fixture_start-make_interval(mins=>coalesce((p_config->>'team_rest_minutes')::integer,0))) then
      raise exception 'Team rest conflict with an existing match';
    end if;
    fixture_key_value := (item->>'sport_id')||':'||coalesce(item->>'category','')||':'||(item->>'id');
    insert into matches(sport_id,scheduled_at,venue,court_name,duration_minutes,round,status,schedule_status,
      home_team_id,away_team_id,created_by,schedule_batch_id,fixture_key,category,home_placeholder,away_placeholder)
    values((item->>'sport_id')::uuid,fixture_start,item->>'court',item->>'court',duration_value,item->>'round',
      'confirmed','published',(case when item->>'home' like 'A definir%' then null else item->>'home' end)::uuid,(case when item->>'away' like 'A definir%' then null else item->>'away' end)::uuid,auth.uid(),batch_id,fixture_key_value,nullif(item->>'category',''),case when item->>'home' like 'A definir%' then item->>'home' end,case when item->>'away' like 'A definir%' then item->>'away' end);
  end loop;
  insert into audit_logs(actor_id,action,table_name,record_id,new_data)
    values(auth.uid(),'publish_multi_sport_schedule','schedule_batches',batch_id::text,
      jsonb_build_object('sports',p_config->'sports','fixtures',jsonb_array_length(p_result->'scheduled')));
  return batch_id;
end $$;
revoke all on function public.publish_multi_sport_schedule(text,jsonb,jsonb) from public;
grant execute on function public.publish_multi_sport_schedule(text,jsonb,jsonb) to authenticated;

notify pgrst, 'reload schema';
