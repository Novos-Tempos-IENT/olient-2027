-- Admin-only API for creating official event availability windows.
-- Direct table writes remain unavailable to application clients.
create or replace function public.admin_create_court_availability(
  p_court_name text,
  p_event_date date,
  p_start_time time,
  p_end_time time
) returns uuid language plpgsql security definer set search_path=public as $$
declare
  v_id uuid;
  v_from timestamptz;
  v_until timestamptz;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_court_name not in ('Quadra 1','Quadra 2','Futmesa','Tênis de Mesa') then
    raise exception 'Invalid official venue';
  end if;
  if p_event_date is null or p_start_time is null or p_end_time is null or p_end_time<=p_start_time then
    raise exception 'Availability must have a date and end after start';
  end if;
  v_from := (p_event_date+p_start_time) at time zone 'America/Sao_Paulo';
  v_until := (p_event_date+p_end_time) at time zone 'America/Sao_Paulo';
  insert into public.court_availability(court_name,available_from,available_until,created_by)
  values(p_court_name,v_from,v_until,auth.uid())
  on conflict(court_name,available_from,available_until) do nothing
  returning id into v_id;
  if v_id is null then raise exception 'Esta janela já está cadastrada para o local e horário informados.'; end if;
  insert into public.audit_logs(actor_id,action,table_name,record_id,new_data)
  values(auth.uid(),'create_court_availability','court_availability',v_id::text,
    jsonb_build_object('court_name',p_court_name,'available_from',v_from,'available_until',v_until));
  return v_id;
end $$;

revoke all on function public.admin_create_court_availability(text,date,time,time) from public;
grant execute on function public.admin_create_court_availability(text,date,time,time) to authenticated;
