-- Official sports placement points requested for OLIENT 2027.
-- This does not create or approve a regulation and does not create results.
alter table public.gincana_program_items
  add column if not exists champion_points numeric(12,2) check(champion_points is null or champion_points>=0);
alter table public.gincana_program_items
  add column if not exists runner_up_points numeric(12,2) check(runner_up_points is null or runner_up_points>=0);

update public.gincana_program_items i
set champion_points=15000,runner_up_points=5000
from public.gincana_program_sections s
where s.id=i.section_id and s.name='Esportes';
