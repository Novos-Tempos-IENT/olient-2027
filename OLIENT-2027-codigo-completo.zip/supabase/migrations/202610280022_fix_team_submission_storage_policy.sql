-- Storage policies now validate the unguessable path hash against a live upload token
-- and the session's team. This avoids depending on whether Storage puts custom metadata
-- in metadata or user_metadata on a particular Storage deployment.
create or replace function public.authorize_team_submission_upload(p_name text)
returns boolean language plpgsql stable security definer
set search_path=public,storage,extensions set row_security=off as $$
declare v_team uuid; v_kind text; v_hash text;
begin
  if p_name !~ '^[0-9a-fA-F-]{36}/(shirt|roster)/[0-9a-f]{64}\.(jpg|png|webp|pdf|csv|xls|xlsx)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid;
  v_kind:=split_part(p_name,'/',2);
  v_hash:=split_part(split_part(p_name,'/',3),'.',1);
  return exists(
    select 1 from public.team_submission_upload_tokens u
    join public.team_access_sessions s on s.id=u.session_id and s.revoked_at is null and s.expires_at>now()
    join public.team_access_links l on l.id=s.link_id and l.team_id=u.team_id
    where u.token_hash=v_hash and u.team_id=v_team and u.kind=v_kind
      and u.expires_at>now() and u.used_at is null
      and ((s.representative_user_id is not null and s.representative_user_id=auth.uid()
            and exists(select 1 from public.team_representatives r where r.user_id=auth.uid() and r.team_id=l.team_id and r.active))
        or (s.representative_user_id is null and l.revoked_at is null and l.expires_at>now()))
  );
exception when others then return false;
end $$;
revoke all on function public.authorize_team_submission_upload(text) from public;
grant execute on function public.authorize_team_submission_upload(text) to anon,authenticated;

drop policy if exists "team submissions upload" on storage.objects;
create policy "team submissions upload" on storage.objects for insert
  with check(bucket_id='team-submissions' and public.authorize_team_submission_upload(name));
create or replace function public.submit_team_submission(p_session_token text,p_kind text,p_storage_path text,p_upload_token text)
returns jsonb language plpgsql security definer
set search_path=public,storage,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_upload public.team_submission_upload_tokens; v_old_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  select * into v_upload from public.team_submission_upload_tokens
    where token_hash=encode(digest(p_upload_token,'sha256'),'hex') and team_id=v_link.team_id
      and session_id=v_session.id and kind=p_kind and expires_at>now() and used_at is null for update;
  if not found then return jsonb_build_object('error','invalid_upload_token'); end if;
  if p_storage_path !~ ('^'||v_link.team_id::text||'/'||p_kind||'/'||v_upload.token_hash||'\.(jpg|png|webp|pdf|csv|xls|xlsx)$') then
    return jsonb_build_object('error','invalid_upload_path');
  end if;
  if not exists(select 1 from storage.objects where bucket_id='team-submissions' and name=p_storage_path
    ) then
    return jsonb_build_object('error','submission_upload_missing');
  end if;
  insert into public.team_submissions(team_id,shirt_path,shirt_status,shirt_review_note,shirt_submitted_at,shirt_submitted_by,
    roster_path,roster_status,roster_review_note,roster_submitted_at,roster_submitted_by,updated_at)
  values(v_link.team_id,
    case when p_kind='shirt' then p_storage_path end,case when p_kind='shirt' then 'pending' else 'not_submitted' end,null,
    case when p_kind='shirt' then now() end,case when p_kind='shirt' then v_session.representative_user_id end,
    case when p_kind='roster' then p_storage_path end,case when p_kind='roster' then 'pending' else 'not_submitted' end,null,
    case when p_kind='roster' then now() end,case when p_kind='roster' then v_session.representative_user_id end,now())
  on conflict(team_id) do update set
    shirt_path=case when p_kind='shirt' then excluded.shirt_path else public.team_submissions.shirt_path end,
    shirt_status=case when p_kind='shirt' then 'pending' else public.team_submissions.shirt_status end,
    shirt_review_note=case when p_kind='shirt' then null else public.team_submissions.shirt_review_note end,
    shirt_submitted_at=case when p_kind='shirt' then now() else public.team_submissions.shirt_submitted_at end,
    shirt_submitted_by=case when p_kind='shirt' then v_session.representative_user_id else public.team_submissions.shirt_submitted_by end,
    shirt_reviewed_at=case when p_kind='shirt' then null else public.team_submissions.shirt_reviewed_at end,
    shirt_reviewed_by=case when p_kind='shirt' then null else public.team_submissions.shirt_reviewed_by end,
    roster_path=case when p_kind='roster' then excluded.roster_path else public.team_submissions.roster_path end,
    roster_status=case when p_kind='roster' then 'pending' else public.team_submissions.roster_status end,
    roster_review_note=case when p_kind='roster' then null else public.team_submissions.roster_review_note end,
    roster_submitted_at=case when p_kind='roster' then now() else public.team_submissions.roster_submitted_at end,
    roster_submitted_by=case when p_kind='roster' then v_session.representative_user_id else public.team_submissions.roster_submitted_by end,
    roster_reviewed_at=case when p_kind='roster' then null else public.team_submissions.roster_reviewed_at end,
    roster_reviewed_by=case when p_kind='roster' then null else public.team_submissions.roster_reviewed_by end,
    updated_at=now();
  update public.team_submission_upload_tokens set used_at=now() where token_hash=v_upload.token_hash;
  insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action,old_data,new_data)
  values(v_link.team_id,null,coalesce(v_session.representative_user_id,auth.uid()),v_link.id,v_session.id,
    case when p_kind='shirt' then 'team_shirt_submitted' else 'team_roster_submitted' end,
    jsonb_build_object('previous_path',v_old_path),jsonb_build_object('path',p_storage_path,'status','pending'));
  return jsonb_build_object('ok',true,'message','Arquivo enviado para aprovação da organização.');
end $$;

create or replace function public.admin_review_team_submission(p_team_id uuid,p_kind text,p_decision text,p_note text default null)
returns void language plpgsql security definer
set search_path=public set row_security=off as $$
declare v_old_status text; v_old_note text;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_kind not in ('shirt','roster') then raise exception 'Tipo de envio inválido'; end if;
  if p_decision not in ('approved','correction_requested') then raise exception 'Decisão inválida'; end if;
  if p_decision='correction_requested' and length(trim(coalesce(p_note,'')))<3 then raise exception 'Informe o motivo da correção'; end if;
  if p_kind='shirt' then
    select shirt_status,shirt_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and shirt_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A foto da camisa não está aguardando aprovação'; end if;
    update public.team_submissions set shirt_status=p_decision,shirt_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,
      shirt_reviewed_at=now(),shirt_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  else
    select roster_status,roster_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and roster_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A lista de nomes não está aguardando aprovação'; end if;
    update public.team_submissions set roster_status=p_decision,roster_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,
      roster_reviewed_at=now(),roster_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  end if;
  insert into public.team_access_events(team_id,student_id,actor_id,action,old_data,new_data)
  values(p_team_id,null,auth.uid(),case when p_kind='shirt' then 'team_shirt_reviewed' else 'team_roster_reviewed' end,
    jsonb_build_object('status',v_old_status,'note',v_old_note),jsonb_build_object('status',p_decision,'note',p_note));
end $$;

-- Include team level uploads in the representative activity log and identify
-- the signed-in student who submitted them.
create or replace function public.admin_team_representative_audit(p_team_id uuid)
returns table(actor_name text,student_name text,action text,changed_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  return query select coalesce(p.display_name,(select concat_ws(' ',rs.first_name,rs.last_name) from public.team_representatives rr join public.students rs on rs.id=rr.student_id where rr.user_id=e.actor_id limit 1),'Acesso por link da equipe'),
    coalesce(concat_ws(' ',s.first_name,s.last_name),'Equipe'),e.action,e.created_at
  from public.team_access_events e left join public.profiles p on p.id=e.actor_id left join public.students s on s.id=e.student_id
  where e.team_id=p_team_id and e.action in ('student_info_saved','shirt_photo_submitted','shirt_photo_reviewed','team_shirt_submitted','team_roster_submitted','team_shirt_reviewed','team_roster_reviewed','representative_activated','representative_account_created')
  order by e.created_at desc limit 50;
end $$;
revoke all on function public.admin_team_representative_audit(uuid) from public;
grant execute on function public.admin_team_representative_audit(uuid) to authenticated;

revoke all on function public.get_team_submission_status(text) from public;
revoke all on function public.create_team_submission_upload_token(text,text,text) from public;
revoke all on function public.submit_team_submission(text,text,text,text) from public;
revoke all on function public.admin_review_team_submission(uuid,text,text,text) from public,anon;
grant execute on function public.get_team_submission_status(text) to anon,authenticated;
grant execute on function public.create_team_submission_upload_token(text,text,text) to anon,authenticated;
grant execute on function public.submit_team_submission(text,text,text,text) to anon,authenticated;

create or replace function public.olient_team_submission_upload_is_ready()
returns boolean language sql stable security definer set search_path=pg_catalog,public as $$
  select to_regprocedure('public.authorize_team_submission_upload(text)') is not null
    and exists(select 1 from pg_policies where schemaname='storage' and tablename='objects'
      and policyname='team submissions upload' and qual ilike '%authorize_team_submission_upload(name)%')
$$;
revoke all on function public.olient_team_submission_upload_is_ready() from public;
grant execute on function public.olient_team_submission_upload_is_ready() to anon,authenticated;
