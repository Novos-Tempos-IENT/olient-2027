-- Align publisher roster conflicts with separate male/female teams.
do $migration$
declare definition text; marker text; replacement text;
begin
 definition := pg_get_functiondef('public.publish_multi_sport_schedule(text,jsonb,jsonb)'::regprocedure);
 marker := 'and m.scheduled_at < fixture_end + make_interval(mins=>coalesce((p_config->>''team_rest_minutes'')::integer,0))';
 replacement := $clause$
 and (
   nullif(substring(coalesce(m.category,'') from '(?i)(masculino|feminino)'), '') is null
   or nullif(substring(coalesce(item->>'category','') from '(?i)(masculino|feminino)'), '') is null
   or lower(substring(m.category from '(?i)(masculino|feminino)')) = lower(substring(item->>'category' from '(?i)(masculino|feminino)'))
 )
 and m.scheduled_at < fixture_end + make_interval(mins=>coalesce((p_config->>'team_rest_minutes')::integer,0))
 $clause$;
 if position(marker in definition)=0 then raise exception 'Validação de descanso não encontrada na função de publicação'; end if;
 if position('lower(substring(m.category' in definition)=0 then execute replace(definition,marker,replacement); end if;
end $migration$;
notify pgrst,'reload schema';
