alter table public.students add column if not exists gender text check(gender in ('male','female'));
create or replace function public.admin_set_student_gender(p_student_id uuid,p_gender text) returns void language plpgsql security definer set search_path=public as $$
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if p_gender not in ('male','female') or p_gender is null then raise exception 'Sexo inválido'; end if;
 update students set gender=p_gender where id=p_student_id and deleted_at is null;
 insert into audit_logs(actor_id,action,table_name,record_id,new_data) values(auth.uid(),'set_student_gender','students',p_student_id::text,jsonb_build_object('gender',p_gender));
end $$;
revoke all on function public.admin_set_student_gender(uuid,text) from public;
grant execute on function public.admin_set_student_gender(uuid,text) to authenticated;
notify pgrst,'reload schema';
