do $migration$
declare definition text; old_clause text; new_clause text;
begin
 definition := pg_get_functiondef('public.publish_multi_sport_schedule(text,jsonb,jsonb)'::regprocedure);
 old_clause := 'and m.court_name=item->>''court''';
 new_clause := 'and m.court_name=item->>''court''
 and (item->>''court'' <> ''Quadra 1''
 or not exists(select 1 from sports s where s.id=(item->>''sport_id'')::uuid and upper(trim(s.name)) in (''VOLEIBOL'',''VÔLEI'',''VOLEI''))
 or m.sport_id <> (item->>''sport_id'')::uuid
 or (select count(*) from matches concurrent where concurrent.deleted_at is null and coalesce(concurrent.schedule_status,''draft'')<>''cancelled'' and concurrent.court_name=''Quadra 1'' and concurrent.scheduled_at < fixture_end and concurrent.scheduled_at+make_interval(mins=>coalesce(concurrent.duration_minutes,0)) > fixture_start) >= 2)';
 if position(old_clause in definition)=0 then raise exception 'Cláusula de conflito não encontrada'; end if;
 execute replace(definition,old_clause,new_clause);
end $migration$;
notify pgrst,'reload schema';
