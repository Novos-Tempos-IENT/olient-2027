-- Add team flag artwork to the existing submission and approval flow.
alter table public.team_submissions
  add column if not exists flag_path text,
  add column if not exists flag_status text not null default 'not_submitted'
    check (flag_status in ('not_submitted','pending','approved','correction_requested')),
  add column if not exists flag_review_note text,
  add column if not exists flag_submitted_at timestamptz,
  add column if not exists flag_submitted_by uuid references auth.users(id) on delete set null,
  add column if not exists flag_reviewed_at timestamptz,
  add column if not exists flag_reviewed_by uuid references public.profiles(id) on delete set null;

alter table public.team_submission_upload_tokens
  drop constraint if exists team_submission_upload_tokens_kind_check;
alter table public.team_submission_upload_tokens
  add constraint team_submission_upload_tokens_kind_check check (kind in ('shirt','flag','roster'));

create or replace function public.authorize_team_submission_upload(p_name text)
returns boolean language plpgsql stable security definer
set search_path=public,storage,extensions set row_security=off as $$
declare v_team uuid; v_kind text; v_hash text;
begin
  if p_name !~ '^[0-9a-fA-F-]{36}/(shirt|flag|roster)/[0-9a-f]{64}\.(jpg|png|webp|pdf|csv|xls|xlsx)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid;
  v_kind:=split_part(p_name,'/',2);
  v_hash:=split_part(split_part(p_name,'/',3),'.',1);
  return exists(select 1 from public.team_submission_upload_tokens u
    join public.team_access_sessions s on s.id=u.session_id and s.revoked_at is null and s.expires_at>now()
    join public.team_access_links l on l.id=s.link_id and l.team_id=u.team_id
    where u.token_hash=v_hash and u.team_id=v_team and u.kind=v_kind and u.expires_at>now() and u.used_at is null
      and ((s.representative_user_id is not null and s.representative_user_id=auth.uid()
            and exists(select 1 from public.team_representatives r where r.user_id=auth.uid() and r.team_id=l.team_id and r.active))
        or (s.representative_user_id is null and l.revoked_at is null and l.expires_at>now())));
exception when others then return false;
end $$;

create or replace function public.can_read_team_submission(p_name text)
returns boolean language plpgsql stable security definer
set search_path=public,storage set row_security=off as $$
declare v_team uuid;
begin
  if public.is_admin() then return true; end if;
  if p_name !~ '^[0-9a-fA-F-]{36}/(shirt|flag|roster)/[0-9a-f]{64}\.(jpg|png|webp|pdf|csv|xls|xlsx)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid;
  return exists(select 1 from public.team_representatives r
    join public.teams t on t.id=r.team_id and t.active and t.deleted_at is null
    where r.team_id=v_team and r.user_id=auth.uid() and r.active);
exception when others then return false;
end $$;

revoke all on function public.authorize_team_submission_upload(text) from public;
revoke all on function public.can_read_team_submission(text) from public;
grant execute on function public.authorize_team_submission_upload(text) to anon,authenticated;
grant execute on function public.can_read_team_submission(text) to anon,authenticated;

drop policy if exists "team submissions upload" on storage.objects;
drop policy if exists "team submissions read" on storage.objects;
create policy "team submissions upload" on storage.objects for insert
  with check(bucket_id='team-submissions' and public.authorize_team_submission_upload(name));
create policy "team submissions read" on storage.objects for select
  using(bucket_id='team-submissions' and public.can_read_team_submission(name));

create or replace function public.get_team_submission_status(p_session_token text)
returns jsonb language plpgsql security definer
set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_team_id uuid;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select team_id into v_team_id from public.team_access_links where id=v_session.link_id;
  if v_team_id is null then return jsonb_build_object('error','link_unavailable'); end if;
  return coalesce((select jsonb_agg(jsonb_build_object('kind',kind,'status',status,'storage_path',storage_path,'review_note',review_note,'submitted_at',submitted_at) order by kind)
    from (
      select 'shirt'::text kind,shirt_status status,shirt_path storage_path,shirt_review_note review_note,shirt_submitted_at submitted_at from public.team_submissions where team_id=v_team_id
      union all
      select 'flag',flag_status,flag_path,flag_review_note,flag_submitted_at from public.team_submissions where team_id=v_team_id
      union all
      select 'roster',roster_status,roster_path,roster_review_note,roster_submitted_at from public.team_submissions where team_id=v_team_id
    ) q),'[]'::jsonb);
end $$;

create or replace function public.create_team_submission_upload_token(p_session_token text,p_kind text,p_content_type text)
returns jsonb language plpgsql security definer
set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_token text; v_extension text; v_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  if p_kind in ('shirt','flag') and p_content_type not in ('image/jpeg','image/png','image/webp') then return jsonb_build_object('error','invalid_image_file_type'); end if;
  if p_kind='roster' and p_content_type not in ('application/pdf','text/csv','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') then return jsonb_build_object('error','invalid_roster_file_type'); end if;
  if p_kind not in ('shirt','flag','roster') then return jsonb_build_object('error','invalid_submission_kind'); end if;
  v_extension:=case p_content_type when 'image/jpeg' then 'jpg' when 'image/png' then 'png' when 'image/webp' then 'webp' when 'application/pdf' then 'pdf' when 'application/vnd.ms-excel' then 'xls' when 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' then 'xlsx' else 'csv' end;
  v_token:=encode(gen_random_bytes(24),'hex');
  v_path:=v_link.team_id::text||'/'||p_kind||'/'||encode(digest(v_token,'sha256'),'hex')||'.'||v_extension;
  insert into public.team_submission_upload_tokens(token_hash,team_id,session_id,kind,content_type,expires_at)
  values(encode(digest(v_token,'sha256'),'hex'),v_link.team_id,v_session.id,p_kind,p_content_type,now()+interval '10 minutes');
  return jsonb_build_object('upload_token',v_token,'storage_path',v_path,'expires_at',now()+interval '10 minutes');
end $$;

create or replace function public.submit_team_submission(p_session_token text,p_kind text,p_storage_path text,p_upload_token text)
returns jsonb language plpgsql security definer
set search_path=public,storage,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_upload public.team_submission_upload_tokens;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  select * into v_upload from public.team_submission_upload_tokens where token_hash=encode(digest(p_upload_token,'sha256'),'hex') and team_id=v_link.team_id and session_id=v_session.id and kind=p_kind and expires_at>now() and used_at is null for update;
  if not found then return jsonb_build_object('error','invalid_upload_token'); end if;
  if p_kind not in ('shirt','flag','roster') or p_storage_path !~ ('^'||v_link.team_id::text||'/'||p_kind||'/'||v_upload.token_hash||'\.(jpg|png|webp|pdf|csv|xls|xlsx)$') then return jsonb_build_object('error','invalid_upload_path'); end if;
  if not exists(select 1 from storage.objects where bucket_id='team-submissions' and name=p_storage_path) then return jsonb_build_object('error','submission_upload_missing'); end if;
  insert into public.team_submissions(team_id) values(v_link.team_id) on conflict(team_id) do nothing;
  update public.team_submissions set
    shirt_path=case when p_kind='shirt' then p_storage_path else shirt_path end,
    shirt_status=case when p_kind='shirt' then 'pending' else shirt_status end,
    shirt_review_note=case when p_kind='shirt' then null else shirt_review_note end,
    shirt_submitted_at=case when p_kind='shirt' then now() else shirt_submitted_at end,
    shirt_submitted_by=case when p_kind='shirt' then v_session.representative_user_id else shirt_submitted_by end,
    shirt_reviewed_at=case when p_kind='shirt' then null else shirt_reviewed_at end,
    shirt_reviewed_by=case when p_kind='shirt' then null else shirt_reviewed_by end,
    flag_path=case when p_kind='flag' then p_storage_path else flag_path end,
    flag_status=case when p_kind='flag' then 'pending' else flag_status end,
    flag_review_note=case when p_kind='flag' then null else flag_review_note end,
    flag_submitted_at=case when p_kind='flag' then now() else flag_submitted_at end,
    flag_submitted_by=case when p_kind='flag' then v_session.representative_user_id else flag_submitted_by end,
    flag_reviewed_at=case when p_kind='flag' then null else flag_reviewed_at end,
    flag_reviewed_by=case when p_kind='flag' then null else flag_reviewed_by end,
    roster_path=case when p_kind='roster' then p_storage_path else roster_path end,
    roster_status=case when p_kind='roster' then 'pending' else roster_status end,
    roster_review_note=case when p_kind='roster' then null else roster_review_note end,
    roster_submitted_at=case when p_kind='roster' then now() else roster_submitted_at end,
    roster_submitted_by=case when p_kind='roster' then v_session.representative_user_id else roster_submitted_by end,
    roster_reviewed_at=case when p_kind='roster' then null else roster_reviewed_at end,
    roster_reviewed_by=case when p_kind='roster' then null else roster_reviewed_by end,
    updated_at=now() where team_id=v_link.team_id;
  update public.team_submission_upload_tokens set used_at=now() where token_hash=v_upload.token_hash;
  insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action,new_data)
  values(v_link.team_id,null,coalesce(v_session.representative_user_id,auth.uid()),v_link.id,v_session.id,
    case p_kind when 'shirt' then 'team_shirt_submitted' when 'flag' then 'team_flag_submitted' else 'team_roster_submitted' end,
    jsonb_build_object('path',p_storage_path,'status','pending'));
  return jsonb_build_object('ok',true,'message','Arquivo enviado para aprovação da organização.');
end $$;

create or replace function public.admin_review_team_submission(p_team_id uuid,p_kind text,p_decision text,p_note text default null)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_old_status text; v_old_note text;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_kind not in ('shirt','flag','roster') then raise exception 'Tipo de envio inválido'; end if;
  if p_decision not in ('approved','correction_requested') then raise exception 'Decisão inválida'; end if;
  if p_decision='correction_requested' and length(trim(coalesce(p_note,'')))<3 then raise exception 'Informe o motivo da correção'; end if;
  if p_kind='shirt' then
    select shirt_status,shirt_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and shirt_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A foto da camisa não está aguardando aprovação'; end if;
    update public.team_submissions set shirt_status=p_decision,shirt_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,shirt_reviewed_at=now(),shirt_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  elsif p_kind='flag' then
    select flag_status,flag_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and flag_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A foto da bandeira não está aguardando aprovação'; end if;
    update public.team_submissions set flag_status=p_decision,flag_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,flag_reviewed_at=now(),flag_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  else
    select roster_status,roster_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and roster_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A lista de nomes não está aguardando aprovação'; end if;
    update public.team_submissions set roster_status=p_decision,roster_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,roster_reviewed_at=now(),roster_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  end if;
  insert into public.team_access_events(team_id,student_id,actor_id,action,old_data,new_data)
  values(p_team_id,null,auth.uid(),case p_kind when 'shirt' then 'team_shirt_reviewed' when 'flag' then 'team_flag_reviewed' else 'team_roster_reviewed' end,
    jsonb_build_object('status',v_old_status,'note',v_old_note),jsonb_build_object('status',p_decision,'note',p_note));
end $$;
revoke all on function public.admin_review_team_submission(uuid,text,text,text) from public,anon;
grant execute on function public.admin_review_team_submission(uuid,text,text,text) to authenticated;

create or replace function public.admin_team_representative_audit(p_team_id uuid)
returns table(actor_name text,student_name text,action text,changed_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  return query select coalesce(p.display_name,(select concat_ws(' ',rs.first_name,rs.last_name) from public.team_representatives rr join public.students rs on rs.id=rr.student_id where rr.user_id=e.actor_id limit 1),'Acesso por link da equipe'),
    coalesce(concat_ws(' ',s.first_name,s.last_name),'Equipe'),e.action,e.created_at
  from public.team_access_events e left join public.profiles p on p.id=e.actor_id left join public.students s on s.id=e.student_id
  where e.team_id=p_team_id and e.action in ('student_info_saved','shirt_photo_submitted','shirt_photo_reviewed','team_shirt_submitted','team_roster_submitted','team_flag_submitted','team_shirt_reviewed','team_roster_reviewed','team_flag_reviewed','representative_activated','representative_account_created')
  order by e.created_at desc limit 50;
end $$;
revoke all on function public.admin_team_representative_audit(uuid) from public;
grant execute on function public.admin_team_representative_audit(uuid) to authenticated;

create or replace function public.olient_team_flag_submission_is_ready()
returns boolean language sql stable security definer set search_path=pg_catalog,public as $$
  select exists(select 1 from information_schema.columns where table_schema='public' and table_name='team_submissions' and column_name='flag_path')
    and exists(select 1 from information_schema.columns where table_schema='public' and table_name='team_submissions' and column_name='flag_status')
$$;
revoke all on function public.olient_team_flag_submission_is_ready() from public;
grant execute on function public.olient_team_flag_submission_is_ready() to anon,authenticated;
