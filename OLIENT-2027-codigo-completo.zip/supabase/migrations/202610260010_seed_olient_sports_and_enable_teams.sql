-- OLIENT 2027: ensure the official sports exist and are available in every active team.
-- Safe to rerun: normalized names are reused, catalog rules/categories are preserved,
-- and existing team approval locks are kept.
begin;

do $$
declare
  v_name text;
  v_sport_id uuid;
  v_team_id uuid;
  v_actor_id uuid;
begin
  v_actor_id := coalesce(auth.uid(), (
    select p.id from public.profiles p
    where p.active and p.role = 'administrator'
    order by p.created_at, p.id limit 1
  ));
  if v_actor_id is null then
    raise exception 'No active administrator profile is available to attribute these updates';
  end if;

  foreach v_name in array array[
    'FUTSAL', 'HANDEBOL', 'BASQUETE 3X3', 'VOLEIBOL',
    'QUEIMADA', 'TÊNIS DE MESA', 'FUTMESA', 'VÔLEI DE MESA'
  ] loop
    perform pg_advisory_xact_lock(hashtext('olient-sport:' || public.olient_normalize_name(v_name)));

    select id into v_sport_id
    from public.sports
    where public.olient_normalize_name(name) = public.olient_normalize_name(v_name)
    order by active desc, (status = 'active') desc, created_at, id
    limit 1;

    if v_sport_id is null then
      insert into public.sports(name, status, active)
      values (v_name, 'active', true)
      returning id into v_sport_id;
    else
      update public.sports
      set active = true, status = 'active', updated_at = now()
      where id = v_sport_id;
    end if;

    for v_team_id in
      select id from public.teams where active and deleted_at is null
    loop
      insert into public.team_sports(team_id, sport_id, enabled, lock_approved, updated_by)
      values (v_team_id, v_sport_id, true, true, v_actor_id)
      on conflict (team_id, sport_id) do update
      set enabled = true, updated_by = v_actor_id, updated_at = now();
    end loop;
  end loop;
end $$;

notify pgrst, 'reload schema';
commit;

-- Verification result: each official modality should show active=true and
-- enabled_teams equal to the number of active, non-deleted teams.
select s.name, s.active, s.status, count(distinct ts.team_id) filter (where ts.enabled and exists (select 1 from public.teams t where t.id = ts.team_id and t.active and t.deleted_at is null)) as enabled_teams
from public.sports s
left join public.team_sports ts on ts.sport_id = s.id
where public.olient_normalize_name(s.name) in (
  'futsal', 'handebol', 'basquete 3x3', 'voleibol', 'queimada',
  'tenis de mesa', 'futmesa', 'volei de mesa'
)
group by s.id, s.name, s.active, s.status
order by s.name;
