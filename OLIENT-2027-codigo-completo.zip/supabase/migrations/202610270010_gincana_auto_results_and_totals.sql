-- Dynamic Gincana awards and final totals. These views read official score
-- ledger entries; placement bonuses are calculated in the summary only and
-- are never written as fabricated ledger transactions.
create or replace view public.public_gincana_sport_awards
with (security_barrier=true) as
with sport_points as (
  select l.sport_id,s.name sport_name,l.team_id,t.name team_name,sum(l.points)::numeric(14,2) points
  from public.score_ledger l
  join public.sports s on s.id=l.sport_id and s.active
  join public.teams t on t.id=l.team_id and t.active and t.deleted_at is null
  where l.voided_at is null
  group by l.sport_id,s.name,l.team_id,t.name
  having sum(l.points)<>0
), ranked as (
  select p.*,dense_rank() over(partition by p.sport_id order by p.points desc) place,
    count(*) over(partition by p.sport_id,p.points) same_points
  from sport_points p
), leader_summary as (
  select sport_id,
    count(*) filter(where place=1) first_count,
    string_agg(team_name,', ' order by team_name) filter(where place=1) first_names,
    (array_agg(team_id order by team_id) filter(where place=1 and same_points=1))[1] first_id,
    count(*) filter(where place=2) second_count,
    string_agg(team_name,', ' order by team_name) filter(where place=2) second_names,
    (array_agg(team_id order by team_id) filter(where place=2 and same_points=1))[1] second_id
  from ranked group by sport_id
), format_rows as (
  select g.created_at,g.sport_id::text,g.format from public.schedule_generation g
), latest_format as (
  select distinct on(sport_id) sport_id::uuid,format
  from format_rows order by sport_id,created_at desc
), match_progress as (
  select m.sport_id,count(*) match_count,
    bool_and(m.home_score is not null and m.away_score is not null and m.status in ('confirmed','published')) all_complete,
    bool_or(coalesce(m.round,'') ilike 'Grupo %') has_group,
    bool_or(coalesce(m.round,'') ilike '%Eliminatória%') has_knockout
  from public.matches m
  where m.deleted_at is null and coalesce(m.schedule_status,'draft')<>'cancelled'
  group by m.sport_id
), sport_formats as (
  select s.id sport_id,coalesce(lf.format,
    case when coalesce(mp.has_group,false) then 'groups'
      when coalesce(mp.has_knockout,false) then 'knockout'
      when lower(coalesce(s.format,'')) in ('knockout','single_elimination','third_place','groups') then lower(s.format)
      else 'round_robin' end) format
  from public.sports s left join latest_format lf on lf.sport_id=s.id
  left join match_progress mp on mp.sport_id=s.id
), final_rows as (
  select m.sport_id,
    case when m.home_score>m.away_score then m.home_team_id else m.away_team_id end champion_id,
    case when m.home_score>m.away_score then m.away_team_id else m.home_team_id end runner_up_id,
    row_number() over(partition by m.sport_id order by m.scheduled_at desc nulls last,m.created_at desc) rn
  from public.matches m
  where m.deleted_at is null and coalesce(m.schedule_status,'draft')<>'cancelled'
    and coalesce(m.round,'') ~* '(^|[^[:alpha:]])final([^[:alpha:]]|$)'
    and m.status in ('confirmed','published') and m.home_score is not null and m.away_score is not null
    and m.home_score<>m.away_score
), completed_final as (select * from final_rows where rn=1), resolved as (
  select s.id sport_id,s.name sport_name,
    case when f.sport_id is not null then ch.name
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 then ls.first_names
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and coalesce(ls.first_count,0)>1 then 'Empate: '||ls.first_names
      else null end champion_name,
    case when f.sport_id is not null then f.champion_id
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 then ls.first_id
      else null end champion_id,
    case when f.sport_id is not null then ru.name
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 and ls.second_count=1 then ls.second_names
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 and ls.second_count>1 then 'Empate: '||ls.second_names
      else null end runner_up_name,
    case when f.sport_id is not null then f.runner_up_id
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 and ls.second_count=1 then ls.second_id
      else null end runner_up_id,
    case when f.sport_id is not null then 'Definido pela final'
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and coalesce(ls.first_count,0)=1 then 'Definido pela classificação final'
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and coalesce(ls.first_count,0)>1 then 'Empate · desempate pendente'
      when coalesce(mp.match_count,0)=0 then 'Aguardando resultados'
      when sf.format in ('knockout','single_elimination','third_place','groups') then 'Aguardando final'
      else 'Aguardando conclusão da tabela' end champion_status,
    case when f.sport_id is not null then 'Definido pela final'
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 and ls.second_count=1 then 'Definido pela classificação final'
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 and ls.second_count>1 then 'Empate · desempate pendente'
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 then 'Vice ainda não definido'
      when coalesce(mp.match_count,0)=0 then 'Aguardando resultados'
      when sf.format in ('knockout','single_elimination','third_place','groups') then 'Aguardando final'
      else 'Aguardando conclusão da tabela' end runner_up_status
  from public.sports s
  left join leader_summary ls on ls.sport_id=s.id
  left join sport_formats sf on sf.sport_id=s.id
  left join match_progress mp on mp.sport_id=s.id
  left join completed_final f on f.sport_id=s.id
  left join public.teams ch on ch.id=f.champion_id
  left join public.teams ru on ru.id=f.runner_up_id
  where s.active
)
select sport_id,sport_name,champion_name,champion_id,
  case when champion_id is not null then 15000::numeric(12,2) else null end champion_points,
  champion_status,runner_up_name,runner_up_id,
  case when runner_up_id is not null then 5000::numeric(12,2) else null end runner_up_points,
  runner_up_status
from resolved;

create or replace view public.public_gincana_totals
with (security_barrier=true) as
with ledger_totals as (
  select t.id team_id,t.name team_name,
    coalesce(sum(l.points) filter(where l.sport_id is not null),0)::numeric(14,2) sports_points,
    coalesce(sum(l.points) filter(where l.sport_id is null),0)::numeric(14,2) other_points,
    coalesce(sum(l.points),0)::numeric(14,2) ledger_total
  from public.teams t left join public.score_ledger l on l.team_id=t.id and l.voided_at is null
  where t.active and t.deleted_at is null group by t.id,t.name
), placement_bonuses as (
  select t.id team_id,
    coalesce(sum(case when a.champion_id=t.id then a.champion_points else 0 end),0)::numeric(14,2) champion_bonus,
    coalesce(sum(case when a.runner_up_id=t.id then a.runner_up_points else 0 end),0)::numeric(14,2) runner_up_bonus
  from public.teams t cross join public.public_gincana_sport_awards a
  where t.active and t.deleted_at is null group by t.id
), totals as (
  select l.team_id,l.team_name,l.sports_points,l.other_points,
    coalesce(b.champion_bonus,0)::numeric(14,2) champion_bonus,
    coalesce(b.runner_up_bonus,0)::numeric(14,2) runner_up_bonus,
    (l.ledger_total+coalesce(b.champion_bonus,0)+coalesce(b.runner_up_bonus,0))::numeric(14,2) final_points
  from ledger_totals l left join placement_bonuses b using(team_id)
)
select team_id,team_name,sports_points,other_points,champion_bonus,runner_up_bonus,final_points,
  dense_rank() over(order by final_points desc)::bigint place
from totals;

grant select on public.public_gincana_sport_awards,public.public_gincana_totals to anon,authenticated;
comment on view public.public_gincana_sport_awards is 'Per-sport champion and vice from a confirmed final, or completed round-robin tables; ties remain unresolved.';
comment on view public.public_gincana_totals is 'Per-team official ledger totals plus dynamic champion and vice bonuses for the Gincana final table.';
