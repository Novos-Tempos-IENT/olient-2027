-- Configurable point value for each Gincana program activity.
alter table public.gincana_program_items
  add column if not exists points_value numeric(12,2)
  check(points_value is null or points_value between 0 and 1000000000);

comment on column public.gincana_program_items.points_value is
  'Maximum/configured value of this Gincana activity. It is not an awarded team score until a result is entered.';

create or replace function public.set_gincana_program_item_points(p_item_id uuid,p_points numeric)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_points is not null and (p_points<0 or p_points>1000000000) then
    raise exception 'Activity points must be between 0 and 1000000000';
  end if;
  update public.gincana_program_items set points_value=p_points where id=p_item_id;
  if not found then raise exception 'Gincana activity not found'; end if;
  insert into public.audit_logs(actor_id,action,table_name,record_id,new_data)
    values(auth.uid(),'set_gincana_activity_points','gincana_program_items',p_item_id::text,
      jsonb_build_object('points_value',p_points));
end $$;
revoke all on function public.set_gincana_program_item_points(uuid,numeric) from public;
grant execute on function public.set_gincana_program_item_points(uuid,numeric) to authenticated;
