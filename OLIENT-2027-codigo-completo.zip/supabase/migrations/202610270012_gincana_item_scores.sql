-- Points awarded to a team for one non-sports Gincana activity.
-- Sports results continue to come from the official score ledger and standings.
create table if not exists public.gincana_item_scores (
  item_id uuid not null references public.gincana_program_items(id) on delete cascade,
  team_id uuid not null references public.teams(id) on delete cascade,
  score_type text not null check (score_type in ('standard','variable')),
  points numeric(12,2) not null check (points between 0 and 1000000000),
  created_by uuid references public.profiles(id),
  updated_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (item_id,team_id)
);

alter table public.gincana_item_scores enable row level security;
drop policy if exists "gincana item scores are publicly readable" on public.gincana_item_scores;
create policy "gincana item scores are publicly readable"
  on public.gincana_item_scores for select using (true);
grant select on public.gincana_item_scores to anon,authenticated;
revoke insert,update,delete on public.gincana_item_scores from anon,authenticated;

create or replace function public.set_gincana_item_result(
  p_item_id uuid,p_team_id uuid,p_score_type text,p_points numeric
) returns void language plpgsql security definer set search_path=public as $$
declare
  v_points numeric(12,2);
  v_sport_section boolean;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_score_type not in ('standard','variable') then raise exception 'Invalid score type'; end if;
  if p_points is null or p_points<0 or p_points>1000000000 then
    raise exception 'Activity points must be between 0 and 1000000000';
  end if;
  select (s.name='Esportes'),i.points_value into v_sport_section,v_points
  from public.gincana_program_items i
  join public.gincana_program_sections s on s.id=i.section_id
  where i.id=p_item_id;
  if not found then raise exception 'Gincana activity not found'; end if;
  if v_sport_section then raise exception 'Sports placements are awarded automatically from the final standings'; end if;
  if p_score_type='standard' and (v_points is null or p_points<>v_points) then
    raise exception 'Standard points must match the configured activity value';
  end if;
  if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null) then
    raise exception 'Active team not found';
  end if;
  insert into public.gincana_item_scores(item_id,team_id,score_type,points,created_by,updated_by)
  values(p_item_id,p_team_id,p_score_type,p_points,auth.uid(),auth.uid())
  on conflict(item_id,team_id) do update set score_type=excluded.score_type,points=excluded.points,
    updated_by=auth.uid(),updated_at=now();
  insert into public.audit_logs(actor_id,action,table_name,record_id,new_data)
  values(auth.uid(),'set_gincana_activity_result','gincana_item_scores',p_item_id::text||':'||p_team_id::text,
    jsonb_build_object('item_id',p_item_id,'team_id',p_team_id,'score_type',p_score_type,'points',p_points));
end $$;

create or replace function public.remove_gincana_item_result(p_item_id uuid,p_team_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare v_old public.gincana_item_scores%rowtype;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  delete from public.gincana_item_scores where item_id=p_item_id and team_id=p_team_id returning * into v_old;
  if not found then return; end if;
  insert into public.audit_logs(actor_id,action,table_name,record_id,old_data)
  values(auth.uid(),'remove_gincana_activity_result','gincana_item_scores',p_item_id::text||':'||p_team_id::text,
    jsonb_build_object('item_id',v_old.item_id,'team_id',v_old.team_id,'score_type',v_old.score_type,'points',v_old.points));
end $$;

revoke all on function public.set_gincana_item_result(uuid,uuid,text,numeric) from public;
revoke all on function public.remove_gincana_item_result(uuid,uuid) from public;
grant execute on function public.set_gincana_item_result(uuid,uuid,text,numeric) to authenticated;
grant execute on function public.remove_gincana_item_result(uuid,uuid) to authenticated;

create or replace view public.public_gincana_totals
with (security_barrier=true) as
with ledger_totals as (
  select t.id team_id,t.name team_name,
    coalesce(sum(l.points) filter(where l.sport_id is not null),0)::numeric(14,2) sports_points,
    coalesce(sum(l.points) filter(where l.sport_id is null),0)::numeric(14,2) ledger_other_points,
    coalesce(sum(l.points),0)::numeric(14,2) ledger_total
  from public.teams t left join public.score_ledger l on l.team_id=t.id and l.voided_at is null
  where t.active and t.deleted_at is null group by t.id,t.name
), activity_totals as (
  select team_id,coalesce(sum(points),0)::numeric(14,2) activity_points
  from public.gincana_item_scores group by team_id
), placement_bonuses as (
  select t.id team_id,
    coalesce(sum(case when a.champion_id=t.id then a.champion_points else 0 end),0)::numeric(14,2) champion_bonus,
    coalesce(sum(case when a.runner_up_id=t.id then a.runner_up_points else 0 end),0)::numeric(14,2) runner_up_bonus
  from public.teams t cross join public.public_gincana_sport_awards a
  where t.active and t.deleted_at is null group by t.id
), totals as (
  select l.team_id,l.team_name,l.sports_points,
    (l.ledger_other_points+coalesce(a.activity_points,0))::numeric(14,2) other_points,
    coalesce(b.champion_bonus,0)::numeric(14,2) champion_bonus,
    coalesce(b.runner_up_bonus,0)::numeric(14,2) runner_up_bonus,
    (l.ledger_total+coalesce(a.activity_points,0)+coalesce(b.champion_bonus,0)+coalesce(b.runner_up_bonus,0))::numeric(14,2) final_points
  from ledger_totals l left join activity_totals a using(team_id) left join placement_bonuses b using(team_id)
)
select team_id,team_name,sports_points,other_points,champion_bonus,runner_up_bonus,final_points,
  dense_rank() over(order by final_points desc)::bigint place
from totals;

grant select on public.public_gincana_totals to anon,authenticated;
comment on table public.gincana_item_scores is 'Official Gincana event scores by team. Sports champion and runner-up points are calculated separately.';
