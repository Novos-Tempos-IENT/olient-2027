-- Confirm match scores independently from championship awards.
create or replace function public.confirm_match_result(p_match_id uuid,p_home_score numeric,p_away_score numeric,p_idempotency_key text) returns uuid
language plpgsql security definer set search_path=public as $$
declare m public.matches; old_result public.match_results; rev integer; res_id uuid; r public.scoring_rules; winner uuid; loser uuid;
begin
 if not public.can_manage() then raise exception 'Permission denied'; end if;
 select * into m from matches where id=p_match_id and deleted_at is null for update;
 if not found then raise exception 'Match not found'; end if;
 if exists(select 1 from match_results where idempotency_key=p_idempotency_key) then select id into res_id from match_results where idempotency_key=p_idempotency_key; return res_id; end if;
 if m.home_team_id is null or m.away_team_id is null then raise exception 'Defina os participantes antes de confirmar o resultado'; end if;
 if p_home_score < 0 or p_away_score < 0 or p_home_score is null or p_away_score is null then raise exception 'Placar inválido'; end if;
 if p_home_score=p_away_score and (select coalesce(rules->>'allow_draw','false')<>'true' from sports where id=m.sport_id) then raise exception 'Tie requires a configured sport rule'; end if;
 select * into old_result from match_results where match_id=m.id and status in ('confirmed','published') order by revision desc limit 1;
 rev:=coalesce((select max(revision) from match_results where match_id=m.id),0)+1;
 insert into match_results(match_id,revision,home_score,away_score,status,created_by,idempotency_key,supersedes_id) values(m.id,rev,p_home_score,p_away_score,'confirmed',auth.uid(),p_idempotency_key,old_result.id) returning id into res_id;
 if old_result.id is not null then
  insert into score_ledger(team_id,sport_id,match_id,source_type,source_id,points,regulation_id,entry_type,description,created_by,idempotency_key,reversal_of)
  select team_id,sport_id,match_id,'reversal',source_id,-points,regulation_id,'reversal','Reversão da revisão anterior',auth.uid(),'reversal:'||id::text,id from score_ledger where source_type='match_result' and source_id=old_result.id and reversal_of is null;
  update score_ledger set voided_at=now() where source_type='match_result' and source_id=old_result.id and voided_at is null;
 end if;
 -- A match result does not award championship placement points.
 -- Champion/runner-up bonuses are computed by the Gincana final-results views.
 update matches set home_score=p_home_score,away_score=p_away_score,status='confirmed' where id=m.id;
 insert into audit_logs(actor_id,action,table_name,record_id,new_data) values(auth.uid(),'confirm_result','match_results',res_id::text,jsonb_build_object('home_score',p_home_score,'away_score',p_away_score,'revision',rev));
 return res_id;
end $$;
revoke all on function public.confirm_match_result(uuid,numeric,numeric,text) from public;
grant execute on function public.confirm_match_result(uuid,numeric,numeric,text) to authenticated;


notify pgrst,'reload schema';
