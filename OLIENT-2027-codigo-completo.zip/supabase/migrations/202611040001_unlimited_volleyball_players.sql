-- Complete finalizer; replaces fragile text-based function patches.
create or replace function public.finish_match_live(p_match_id uuid,p_data jsonb) returns void
language plpgsql security definer set search_path=public as $$
declare m public.matches; sport_name text; home_points integer:=0; away_points integer:=0; player_limit integer; set_row jsonb; home_value integer; away_value integer;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 select * into m from matches where id=p_match_id and deleted_at is null for update;
 if m.id is null or m.home_team_id is null or m.away_team_id is null then raise exception 'Defina as equipes antes de finalizar'; end if;
 if exists(select 1 from match_live_state where match_id=p_match_id and data->>'finishedAt' is not null) then raise exception 'Partida já finalizada'; end if;
 select upper(trim(name)) into sport_name from sports where id=m.sport_id;
 if sport_name ~ 'TÊNIS|TENIS|VÔLEI|VOLEI|FUTMESA' then
  if jsonb_array_length(coalesce(p_data->'sets','[]'::jsonb))<>3 then raise exception 'Informe a pontuação dos sets'; end if;
  for set_row in select value from jsonb_array_elements(p_data->'sets') loop
   if greatest(home_points,away_points)=2 then
    if set_row->>'home' is not null or set_row->>'away' is not null then raise exception 'Não pode haver set após duas vitórias'; end if;
    continue;
   end if;
   if set_row->>'home' is null or set_row->>'away' is null then raise exception 'Set incompleto'; end if;
   home_value:=(set_row->>'home')::integer; away_value:=(set_row->>'away')::integer;
   if home_value<0 or away_value<0 or home_value=away_value then raise exception 'Pontuação do set inválida'; end if;
   if home_value>away_value then home_points:=home_points+1; else away_points:=away_points+1; end if;
  end loop;
  if greatest(home_points,away_points)<>2 then raise exception 'Uma equipe deve vencer dois sets'; end if;
  if sport_name in ('VOLEIBOL','VÔLEI','VOLEI') then
   if jsonb_array_length(coalesce(p_data->'lineups'->m.home_team_id::text,'[]'::jsonb))<1 or jsonb_array_length(coalesce(p_data->'lineups'->m.away_team_id::text,'[]'::jsonb))<1 then raise exception 'Selecione os atletas de cada equipe'; end if;
  else
   player_limit:=case when sport_name ~ 'TÊNIS|TENIS' then 1 else 2 end;
   if jsonb_array_length(coalesce(p_data->'lineups'->m.home_team_id::text,'[]'::jsonb))<>player_limit or jsonb_array_length(coalesce(p_data->'lineups'->m.away_team_id::text,'[]'::jsonb))<>player_limit then raise exception 'Quantidade de atletas selecionados inválida'; end if;
  end if;
 elsif sport_name like '%BASQUETE%' then
  if jsonb_array_length(coalesce(p_data->'lineups'->m.home_team_id::text,'[]'::jsonb)) not between 1 and 4 or jsonb_array_length(coalesce(p_data->'lineups'->m.away_team_id::text,'[]'::jsonb)) not between 1 and 4 then raise exception 'Selecione de 1 a 4 jogadores por equipe'; end if;
  select coalesce(sum(case e->>'kind' when '2 pontos' then 2 when '3 pontos' then 3 else 0 end),0) into home_points from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) e where e->>'team'=m.home_team_id::text;
  select coalesce(sum(case e->>'kind' when '2 pontos' then 2 when '3 pontos' then 3 else 0 end),0) into away_points from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) e where e->>'team'=m.away_team_id::text;
 elsif sport_name ~ 'QUEIMADA|DODGEBALL' then
  if p_data->>'winnerTeamId' is null or p_data->>'winnerTeamId' not in (m.home_team_id::text,m.away_team_id::text) then raise exception 'Selecione a equipe vencedora'; end if;
  home_points:=case when p_data->>'winnerTeamId'=m.home_team_id::text then 1 else 0 end;
  away_points:=1-home_points;
 else
  select count(*) into home_points from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) e where e->>'kind'='Gol' and e->>'team'=m.home_team_id::text;
  select count(*) into away_points from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) e where e->>'kind'='Gol' and e->>'team'=m.away_team_id::text;
 end if;
 perform public.confirm_match_result(p_match_id,home_points,away_points,'live-finish-'||p_match_id::text||'-'||gen_random_uuid()::text);
 perform public.save_match_live_state(p_match_id,p_data||jsonb_build_object('runningSince',null,'finishedAt',now()));
end $$;
revoke all on function public.finish_match_live(uuid,jsonb) from public;
grant execute on function public.finish_match_live(uuid,jsonb) to authenticated;
notify pgrst,'reload schema';
