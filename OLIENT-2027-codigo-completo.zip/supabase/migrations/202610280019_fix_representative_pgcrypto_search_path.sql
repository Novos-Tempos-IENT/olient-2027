-- The account-binding RPC uses pgcrypto to create a random team link token.
-- Supabase installs pgcrypto functions in the extensions schema.
alter function public.admin_bind_team_representative_account(uuid,smallint,uuid,text,uuid,uuid)
  set search_path = public, auth, extensions;
