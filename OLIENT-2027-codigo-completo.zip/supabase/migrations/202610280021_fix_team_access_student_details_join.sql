-- Fix the missing student-details join used by get_team_access_page.
create or replace function public.get_team_access_page(p_session_token text)
returns jsonb language plpgsql security definer set search_path=public set row_security=off as $$
declare l public.team_access_links; v_session public.team_access_sessions; t public.teams; result jsonb; v_total integer; v_complete integer;
begin
 v_session:=public.validate_team_access_session(p_session_token);
 if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
 select * into l from public.team_access_links where id=v_session.link_id;
 if not found then return jsonb_build_object('error','link_unavailable'); end if;
 if not public.team_access_rate_limit(l.id,null,'read') then return jsonb_build_object('error','rate_limited'); end if;
 update public.team_access_links set last_used_at=now() where id=l.id;
 select * into t from public.teams where id=l.team_id and active and deleted_at is null;
 if not found then return jsonb_build_object('error','link_unavailable'); end if;
 select count(distinct s.id) into v_total from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=t.id and ts.left_at is null;
 select count(distinct s.id) into v_complete from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null join public.team_student_details d on d.team_id=ts.team_id and d.student_id=ts.student_id
 where ts.team_id=t.id and ts.left_at is null and nullif(trim(d.shirt_name),'') is not null and (not l.require_shirt_number or d.shirt_number is not null) and exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status in ('pending','approved','correction_requested'));
 select jsonb_build_object(
   'team',jsonb_build_object('name',t.name,'color',t.color,'logo_path',t.logo_path),
   'locked',l.edits_locked,'expires_at',l.expires_at,
   'number_rules',jsonb_build_object('required',l.require_shirt_number,'min',l.shirt_number_min,'max',l.shirt_number_max,'unique',l.unique_shirt_number),
   'progress',jsonb_build_object('complete',v_complete,'total',v_total),
   'sports',coalesce((select jsonb_agg(jsonb_build_object('id',sp.id,'name',sp.name,'category',coalesce(ts.category,sp.category),'lock_approved',ts.lock_approved) order by sp.name) from public.team_sports ts join public.sports sp on sp.id=ts.sport_id and sp.active where ts.team_id=t.id and ts.enabled),'[]'::jsonb),
     'students',coalesce((select jsonb_agg(jsonb_build_object(
      'id',s.id,'first_name',s.first_name,'last_name',s.last_name,'class_name',c.name,
      'shirt_name',d.shirt_name,'shirt_number',d.shirt_number,
      'completion_status',case when d.shirt_name is null or l.require_shirt_number and d.shirt_number is null or not exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status in ('pending','approved','correction_requested')) then 'pending' when exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status='correction_requested') then 'correction_requested' when exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status='pending') then 'awaiting_approval' when not exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status in ('pending','correction_requested')) and exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status='approved') then 'approved' else 'pending' end,
      'sports',coalesce((select jsonb_agg(jsonb_build_object('id',sp.id,'status',ss.status,'selected',ss.status in ('pending','approved','correction_requested'),'enabled',coalesce(ts.enabled,false),'name',sp.name,'review_note',ss.review_note) order by sp.name) from public.team_student_sports ss join public.sports sp on sp.id=ss.sport_id left join public.team_sports ts on ts.team_id=ss.team_id and ts.sport_id=ss.sport_id where ss.team_id=t.id and ss.student_id=s.id),'[]'::jsonb)
    ) order by c.name,s.last_name,s.first_name) from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null left join public.classes c on c.id=s.class_id left join public.team_student_details d on d.team_id=ts.team_id and d.student_id=s.id where ts.team_id=t.id and ts.left_at is null),'[]'::jsonb)
 ) into result;
 return result;
end $$;
revoke all on function public.get_team_access_page(text) from public;
grant execute on function public.get_team_access_page(text) to anon,authenticated;
-- Readiness probe used by the client to detect this specific correction.
create or replace function public.olient_team_access_roster_is_ready()
returns boolean language sql stable security definer set search_path=pg_catalog,public as $$
  select coalesce(pg_get_functiondef('public.get_team_access_page(text)'::regprocedure) ilike '%team_student_details d%',false)
$$;
revoke all on function public.olient_team_access_roster_is_ready() from public;
grant execute on function public.olient_team_access_roster_is_ready() to anon,authenticated;