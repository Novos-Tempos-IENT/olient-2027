-- Restore the administrative roster-save RPC expected by the app.
begin;

create or replace function public.admin_save_team_student_info(p_team_id uuid,p_student_id uuid,p_shirt_name text,p_shirt_number integer,p_sport_ids uuid[])
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare l public.team_access_links; v_sport_id uuid; v_sport public.sports; v_limit integer; v_old jsonb; v_new jsonb;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null)
   or not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=p_team_id and ts.student_id=p_student_id and ts.left_at is null) then
   raise exception 'Student is not an active member of this team';
 end if;
 select * into l from public.team_access_links where team_id=p_team_id;
 if length(trim(coalesce(p_shirt_name,''))) not between 1 and 30 or p_shirt_name ~ '[[:cntrl:]]' then raise exception 'Shirt name must contain 1 to 30 valid characters'; end if;
 if coalesce(l.require_shirt_number,true) and p_shirt_number is null then raise exception 'Shirt number is required'; end if;
 if p_shirt_number is not null and p_shirt_number not between coalesce(l.shirt_number_min,0) and coalesce(l.shirt_number_max,99) then raise exception 'Shirt number is outside the configured range'; end if;
 if coalesce(l.unique_shirt_number,false) and p_shirt_number is not null and exists(select 1 from public.team_student_details d where d.team_id=p_team_id and d.student_id<>p_student_id and d.shirt_number=p_shirt_number) then raise exception 'Shirt number is already used by another team member'; end if;
 if p_sport_ids is null then p_sport_ids:='{}'::uuid[]; end if;
 if cardinality(p_sport_ids)<>(select count(distinct x) from unnest(p_sport_ids) x) then raise exception 'Duplicate sport selection'; end if;
 if exists(select 1 from unnest(p_sport_ids) u(id) left join public.team_sports ts on ts.team_id=p_team_id and ts.sport_id=u.id and ts.enabled left join public.sports sp on sp.id=u.id and sp.active where ts.sport_id is null or sp.id is null) then raise exception 'A selected sport is not enabled for this team'; end if;
 perform pg_advisory_xact_lock(hashtext(p_team_id::text||':'||p_student_id::text));
 for v_sport_id in select unnest(p_sport_ids) loop
   select * into v_sport from public.sports where id=v_sport_id;
   v_limit:=case when v_sport.rules->>'max_modalities_per_student' ~ '^[0-9]+$' then (v_sport.rules->>'max_modalities_per_student')::integer else null end;
   if v_limit is not null and cardinality(p_sport_ids)>v_limit then raise exception 'Selected sports exceed the participant limit'; end if;
 end loop;
 select jsonb_build_object('shirt_name',d.shirt_name,'shirt_number',d.shirt_number,'sports',coalesce((select jsonb_agg(jsonb_build_object('sport_id',ss.sport_id,'status',ss.status) order by ss.sport_id) from public.team_student_sports ss where ss.team_id=p_team_id and ss.student_id=p_student_id),'[]'::jsonb)) into v_old from public.team_student_details d where d.team_id=p_team_id and d.student_id=p_student_id;
 insert into public.team_student_details(team_id,student_id,shirt_name,shirt_number,updated_by,updated_at) values(p_team_id,p_student_id,trim(p_shirt_name),p_shirt_number,auth.uid(),now()) on conflict(team_id,student_id) do update set shirt_name=excluded.shirt_name,shirt_number=excluded.shirt_number,updated_by=auth.uid(),updated_at=now();
 update public.team_student_sports set status='withdrawn',review_note=null,updated_by=auth.uid(),updated_at=now() where team_id=p_team_id and student_id=p_student_id and status<>'withdrawn' and not(sport_id=any(p_sport_ids));
 foreach v_sport_id in array p_sport_ids loop
   insert into public.team_student_sports(team_id,student_id,sport_id,status,review_note,updated_by,updated_at) values(p_team_id,p_student_id,v_sport_id,'pending',null,auth.uid(),now()) on conflict(team_id,student_id,sport_id) do update set status=case when team_student_sports.status='approved' then 'approved' else 'pending' end,review_note=null,updated_by=auth.uid(),updated_at=now();
 end loop;
 select jsonb_build_object('shirt_name',d.shirt_name,'shirt_number',d.shirt_number,'sports',coalesce((select jsonb_agg(jsonb_build_object('sport_id',ss.sport_id,'status',ss.status) order by ss.sport_id) from public.team_student_sports ss where ss.team_id=p_team_id and ss.student_id=p_student_id),'[]'::jsonb)) into v_new from public.team_student_details d where d.team_id=p_team_id and d.student_id=p_student_id;
 insert into public.team_access_events(team_id,student_id,actor_id,action,old_data,new_data) values(p_team_id,p_student_id,auth.uid(),'admin_student_info_saved',v_old,v_new);
 return jsonb_build_object('ok',true);
end $$;
revoke all on function public.admin_save_team_student_info(uuid,uuid,text,integer,uuid[]) from public;
grant execute on function public.admin_save_team_student_info(uuid,uuid,text,integer,uuid[]) to authenticated;

notify pgrst, 'reload schema';

commit;
