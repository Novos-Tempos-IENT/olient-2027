create or replace function public.admin_clear_previous_schedule() returns integer
language plpgsql security definer set search_path=public as $$
declare removed integer;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 perform pg_advisory_xact_lock(hashtext('olient_schedule_clear'));
 update public.matches set deleted_at=now(),schedule_status='cancelled',updated_at=now() where deleted_at is null;
 get diagnostics removed=row_count;
 insert into public.audit_logs(actor_id,action,table_name,new_data) values(auth.uid(),'clear_previous_schedule','matches',jsonb_build_object('removed_matches',removed));
 return removed;
end $$;
revoke all on function public.admin_clear_previous_schedule() from public;
grant execute on function public.admin_clear_previous_schedule() to authenticated;
notify pgrst,'reload schema';
