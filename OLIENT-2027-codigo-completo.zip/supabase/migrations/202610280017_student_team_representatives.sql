-- Two individually authenticated student representatives per school team.
-- Each representative signs up with their own personal email and a password
-- they choose; the invitation token is single-use and bound to that email.

alter table public.team_access_sessions
  add column if not exists representative_user_id uuid references auth.users(id) on delete cascade;

create table if not exists public.team_representatives (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  slot smallint not null check(slot in (1,2)),
  student_id uuid not null references public.students(id),
  email text not null check(email=lower(trim(email))),
  user_id uuid unique references auth.users(id) on delete set null,
  active boolean not null default true,
  invited_at timestamptz,
  accepted_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(team_id,slot),
  check(email ~* '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$')
);
create unique index if not exists team_representatives_email_unique_idx
  on public.team_representatives(lower(email)) where active;
create index if not exists team_representatives_team_idx
  on public.team_representatives(team_id,slot) where active;
create unique index if not exists team_representatives_student_active_idx
  on public.team_representatives(team_id,student_id) where active;

create table if not exists public.team_representative_invites (
  id uuid primary key default gen_random_uuid(),
  representative_id uuid not null references public.team_representatives(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  accepted_at timestamptz,
  revoked_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);
create index if not exists team_representative_invites_pending_idx
  on public.team_representative_invites(representative_id,expires_at desc)
  where accepted_at is null and revoked_at is null;
alter table public.team_representatives enable row level security;
alter table public.team_representative_invites enable row level security;
revoke all on public.team_representatives,public.team_representative_invites from anon,authenticated;

create or replace function public.admin_issue_team_representative_invite(
  p_team_id uuid,p_slot smallint,p_student_id uuid,p_email text
) returns jsonb
language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare
  v_rep public.team_representatives;
  v_email text:=lower(trim(coalesce(p_email,'')));
  v_token text:=encode(gen_random_bytes(32),'hex');
  v_user_id uuid;
  v_link public.team_access_links;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_slot not in (1,2) then raise exception 'Representative slot must be 1 or 2'; end if;
  if v_email !~* '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$' then raise exception 'Informe um e-mail pessoal válido'; end if;
  if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null) then raise exception 'Equipe ativa não encontrada'; end if;
  if not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id where ts.team_id=p_team_id and ts.student_id=p_student_id and ts.left_at is null and s.active and s.deleted_at is null) then raise exception 'O representante precisa ser um aluno ativo desta turma'; end if;

  perform pg_advisory_xact_lock(hashtext(p_team_id::text));
  select * into v_rep from public.team_representatives where team_id=p_team_id and slot=p_slot for update;
  if found and v_rep.user_id is not null and v_rep.active then raise exception 'Desative o representante atual antes de substituí-lo'; end if;
  if exists(select 1 from public.team_representatives r where r.active and lower(r.email)=v_email and (r.team_id,r.slot) is distinct from (p_team_id,p_slot)) then raise exception 'Este e-mail já está vinculado a outro representante'; end if;
  if exists(select 1 from public.team_representatives r where r.team_id=p_team_id and r.active and r.student_id=p_student_id and r.slot<>p_slot) then raise exception 'O mesmo aluno não pode ocupar os dois lugares de representante'; end if;

  select * into v_link from public.team_access_links where team_id=p_team_id for update;
  if not found then
    insert into public.team_access_links(team_id,token_hash,expires_at,created_by)
    values(p_team_id,encode(digest(gen_random_bytes(32),'sha256'),'hex'),now()+interval '30 days',auth.uid());
  elsif v_link.revoked_at is not null or v_link.expires_at<=now() then
    update public.team_access_links set revoked_at=null,expires_at=now()+interval '30 days',updated_at=now() where id=v_link.id;
  end if;

  if v_rep.id is not null then
    v_user_id:=v_rep.user_id;
    update public.team_representatives set active=false,user_id=null,updated_at=now() where id=v_rep.id;
    update public.team_access_sessions set revoked_at=now() where representative_user_id=v_user_id and revoked_at is null;
  end if;

  if v_rep.id is null then
    insert into public.team_representatives(team_id,slot,student_id,email,active,invited_at,created_by)
    values(p_team_id,p_slot,p_student_id,v_email,true,now(),auth.uid()) returning * into v_rep;
  else
    update public.team_representatives set student_id=p_student_id,email=v_email,active=true,invited_at=now(),accepted_at=null,updated_at=now()
      where id=v_rep.id returning * into v_rep;
  end if;
  update public.team_representative_invites set revoked_at=now()
    where representative_id=v_rep.id and revoked_at is null;
  insert into public.team_representative_invites(representative_id,token_hash,expires_at,created_by)
    values(v_rep.id,encode(digest(v_token,'sha256'),'hex'),now()+interval '30 days',auth.uid());
  insert into public.team_access_events(team_id,student_id,actor_id,action,new_data)
    values(p_team_id,p_student_id,auth.uid(),'representative_invited',jsonb_build_object('slot',p_slot,'email',v_email));
  return jsonb_build_object('invite_token',v_token,'expires_at',now()+interval '30 days','slot',p_slot,'email',v_email);
end $$;
revoke all on function public.admin_issue_team_representative_invite(uuid,smallint,uuid,text) from public;
grant execute on function public.admin_issue_team_representative_invite(uuid,smallint,uuid,text) to authenticated;

create or replace function public.get_my_profile()
returns public.profiles language sql stable security definer set search_path=public set row_security=off as $$
  select p.* from public.profiles p where p.id=auth.uid() and (p.active or exists(select 1 from public.team_representatives r where r.user_id=auth.uid() and r.active))
$$;
revoke all on function public.get_my_profile() from public;
grant execute on function public.get_my_profile() to authenticated;

create or replace function public.admin_list_team_representatives(p_team_id uuid)
returns table(slot smallint,student_id uuid,student_name text,email text,status text,accepted_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  return query
  select r.slot,r.student_id,concat_ws(' ',s.first_name,s.last_name),r.email,
    case when not r.active then 'revoked' when r.user_id is not null then 'active'
      when exists(select 1 from public.team_representative_invites i where i.representative_id=r.id and i.accepted_at is null and i.revoked_at is null and i.expires_at>now()) then 'invite_pending'
      else 'expired' end,
    r.accepted_at
  from public.team_representatives r join public.students s on s.id=r.student_id
  where r.team_id=p_team_id order by r.slot;
end $$;
revoke all on function public.admin_list_team_representatives(uuid) from public;
grant execute on function public.admin_list_team_representatives(uuid) to authenticated;

create or replace function public.admin_revoke_team_representative(p_team_id uuid,p_slot smallint)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_rep_id uuid; v_student_id uuid; v_user_id uuid;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  select id,student_id,user_id into v_rep_id,v_student_id,v_user_id
    from public.team_representatives where team_id=p_team_id and slot=p_slot for update;
  if v_rep_id is null then return; end if;
  update public.team_representatives set active=false,user_id=null,updated_at=now() where id=v_rep_id;
  update public.team_representative_invites set revoked_at=now() where representative_id=v_rep_id and accepted_at is null and revoked_at is null;
  update public.team_access_sessions set revoked_at=now() where representative_user_id=v_user_id and revoked_at is null;
  insert into public.team_access_events(team_id,student_id,actor_id,action,new_data)
    values(p_team_id,v_student_id,auth.uid(),'representative_revoked',jsonb_build_object('slot',p_slot));
end $$;
revoke all on function public.admin_revoke_team_representative(uuid,smallint) from public;
grant execute on function public.admin_revoke_team_representative(uuid,smallint) to authenticated;

create or replace function public.accept_team_representative_invite(p_invite_token text)
returns jsonb language plpgsql security definer set search_path=public,auth set row_security=off as $$
declare v_invite public.team_representative_invites; v_rep public.team_representatives; v_student public.students; v_email text;
begin
  if auth.uid() is null then raise exception 'Entre ou crie sua conta antes de aceitar o convite'; end if;
  select lower(u.email) into v_email from auth.users u where u.id=auth.uid() and u.email_confirmed_at is not null;
  if v_email is null then raise exception 'Confirme seu e-mail antes de ativar o acesso'; end if;
  if p_invite_token is null or length(p_invite_token)<>64 then raise exception 'Convite inválido ou expirado'; end if;
  select * into v_invite from public.team_representative_invites where token_hash=encode(digest(p_invite_token,'sha256'),'hex') and accepted_at is null and revoked_at is null and expires_at>now() for update;
  if not found then raise exception 'Convite inválido, expirado ou já utilizado'; end if;
  select * into v_rep from public.team_representatives where id=v_invite.representative_id and active for update;
  if not found or lower(v_rep.email)<>v_email then raise exception 'Use o e-mail pessoal para o qual este convite foi criado'; end if;
  if v_rep.user_id is not null and v_rep.user_id<>auth.uid() then raise exception 'Este lugar de representante já está ativado'; end if;
  select * into v_student from public.students where id=v_rep.student_id and active and deleted_at is null;
  if not found then raise exception 'O cadastro do estudante não está mais ativo'; end if;
  insert into public.profiles(id,display_name,role,active)
    values(auth.uid(),concat_ws(' ',v_student.first_name,v_student.last_name),'viewer',true)
    on conflict(id) do update set display_name=excluded.display_name,active=true;
  update public.team_representatives set user_id=auth.uid(),accepted_at=now(),updated_at=now() where id=v_rep.id;
  update public.team_representative_invites set accepted_at=now() where id=v_invite.id;
  insert into public.team_access_events(team_id,student_id,actor_id,action,new_data)
    values(v_rep.team_id,v_rep.student_id,auth.uid(),'representative_activated',jsonb_build_object('slot',v_rep.slot,'email',v_email));
  return jsonb_build_object('team_id',v_rep.team_id,'team_slug',(select slug from public.teams where id=v_rep.team_id),
    'team_name',(select name from public.teams where id=v_rep.team_id),'student_id',v_rep.student_id,
    'student_name',concat_ws(' ',v_student.first_name,v_student.last_name),'slot',v_rep.slot);
end $$;
revoke all on function public.accept_team_representative_invite(text) from public;
grant execute on function public.accept_team_representative_invite(text) to authenticated;

create or replace function public.get_my_team_representative()
returns jsonb language sql stable security definer set search_path=public set row_security=off as $$
  select jsonb_build_object('team_id',r.team_id,'team_slug',t.slug,'team_name',t.name,
    'student_id',r.student_id,'student_name',concat_ws(' ',s.first_name,s.last_name),'slot',r.slot)
  from public.team_representatives r
  join public.teams t on t.id=r.team_id and t.active and t.deleted_at is null
  join public.students s on s.id=r.student_id and s.active and s.deleted_at is null
  where r.user_id=auth.uid() and r.active
  limit 1
$$;
revoke all on function public.get_my_team_representative() from public;
grant execute on function public.get_my_team_representative() to authenticated;

create or replace function public.start_team_representative_session()
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_rep public.team_representatives; v_link public.team_access_links; v_token text; v_session_id uuid;
begin
  if auth.uid() is null then raise exception 'Representative authentication required'; end if;
  select * into v_rep from public.team_representatives where user_id=auth.uid() and active for update;
  if not found then return jsonb_build_object('error','representative_not_found'); end if;
  select * into v_link from public.team_access_links where team_id=v_rep.team_id for update;
  if not found then raise exception 'O acesso da equipe precisa ser configurado pela organização'; end if;
  update public.team_access_sessions set revoked_at=now() where representative_user_id=auth.uid() and revoked_at is null;
  v_token:=encode(gen_random_bytes(32),'hex');
  insert into public.team_access_sessions(link_id,session_hash,expires_at,representative_user_id)
    values(v_link.id,encode(digest(v_token,'sha256'),'hex'),now()+interval '4 hours',auth.uid()) returning id into v_session_id;
  insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action)
    values(v_rep.team_id,v_rep.student_id,auth.uid(),v_link.id,v_session_id,'representative_session_started');
  return jsonb_build_object('session_token',v_token,'slug',(select slug from public.teams where id=v_rep.team_id),
    'team_name',(select name from public.teams where id=v_rep.team_id),'representative_name',(select concat_ws(' ',first_name,last_name) from public.students where id=v_rep.student_id));
end $$;
revoke all on function public.start_team_representative_session() from public;
grant execute on function public.start_team_representative_session() to authenticated;

-- The shared roster editor records authenticated representative identity.
create or replace function public.save_team_student_info(p_session_token text,p_student_id uuid,p_shirt_name text,p_shirt_number integer,p_sport_ids uuid[])
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare l public.team_access_links; v_session public.team_access_sessions; v_team public.teams; v_sport_id uuid; v_sport public.sports; v_limit integer; v_old jsonb; v_new jsonb;
begin
 v_session:=public.validate_team_access_session(p_session_token);
 if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
 select * into l from public.team_access_links where id=v_session.link_id;
 if not found then return jsonb_build_object('error','link_unavailable'); end if;
 if l.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
 if not public.team_access_rate_limit(l.id,p_student_id,'save') then return jsonb_build_object('error','rate_limited'); end if;
 select * into v_team from public.teams where id=l.team_id and active and deleted_at is null;
 if not found or not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=l.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
 if length(trim(coalesce(p_shirt_name,''))) not between 1 and 30 or p_shirt_name ~ '[[:cntrl:]]' then return jsonb_build_object('error','invalid_shirt_name'); end if;
 if l.require_shirt_number and p_shirt_number is null then return jsonb_build_object('error','shirt_number_required'); end if;
 if p_shirt_number is not null and p_shirt_number not between l.shirt_number_min and l.shirt_number_max then return jsonb_build_object('error','invalid_shirt_number'); end if;
 perform pg_advisory_xact_lock(hashtext(l.team_id::text));
 if p_sport_ids is null then p_sport_ids:='{}'::uuid[]; end if;
 if cardinality(p_sport_ids)<>(select count(distinct x) from unnest(p_sport_ids) x) then return jsonb_build_object('error','duplicate_sports'); end if;
 if exists(select 1 from unnest(p_sport_ids) u(id) left join public.team_sports ts on ts.team_id=l.team_id and ts.sport_id=u.id and ts.enabled left join public.sports sp on sp.id=u.id and sp.active where (ts.sport_id is null or sp.id is null) and not exists(select 1 from public.team_student_sports old where old.team_id=l.team_id and old.student_id=p_student_id and old.sport_id=u.id and old.status in ('pending','approved','correction_requested'))) then return jsonb_build_object('error','sport_unavailable'); end if;
 if l.unique_shirt_number and p_shirt_number is not null and exists(select 1 from public.team_student_details d where d.team_id=l.team_id and d.student_id<>p_student_id and d.shirt_number=p_shirt_number) then return jsonb_build_object('error','duplicate_shirt_number'); end if;
 for v_sport_id in select unnest(p_sport_ids) loop
   if exists(select 1 from public.team_student_sports old where old.team_id=l.team_id and old.student_id=p_student_id and old.sport_id=v_sport_id and old.status in ('pending','approved','correction_requested')) and not exists(select 1 from public.team_sports ts join public.sports sp on sp.id=ts.sport_id and sp.active where ts.team_id=l.team_id and ts.sport_id=v_sport_id and ts.enabled) then continue; end if;
   select sp.* into v_sport from public.sports sp join public.team_sports ts on ts.sport_id=sp.id and ts.team_id=l.team_id and ts.enabled where sp.id=v_sport_id and sp.active;
   v_limit:=case when v_sport.rules->>'max_modalities_per_student' ~ '^[0-9]+$' then (v_sport.rules->>'max_modalities_per_student')::integer else null end;
   if v_limit is not null and cardinality(p_sport_ids)>v_limit then return jsonb_build_object('error','modality_limit'); end if;
 end loop;
 if exists(select 1 from public.team_student_sports ss join public.team_sports ts on ts.team_id=ss.team_id and ts.sport_id=ss.sport_id where ss.team_id=l.team_id and ss.student_id=p_student_id and ss.status='approved' and ts.lock_approved and not(ss.sport_id=any(p_sport_ids))) then return jsonb_build_object('error','approved_sports_locked'); end if;
 select jsonb_build_object('shirt_name',d.shirt_name,'shirt_number',d.shirt_number,'sports',coalesce((select jsonb_agg(jsonb_build_object('sport_id',ss.sport_id,'status',ss.status) order by ss.sport_id) from public.team_student_sports ss where ss.team_id=l.team_id and ss.student_id=p_student_id),'[]'::jsonb)) into v_old from public.team_student_details d where d.team_id=l.team_id and d.student_id=p_student_id;
 insert into public.team_student_details(team_id,student_id,shirt_name,shirt_number,updated_by,updated_at) values(l.team_id,p_student_id,trim(p_shirt_name),p_shirt_number,v_session.representative_user_id,now()) on conflict(team_id,student_id) do update set shirt_name=excluded.shirt_name,shirt_number=excluded.shirt_number,updated_by=coalesce(v_session.representative_user_id,public.team_student_details.updated_by),updated_at=now();
 update public.team_student_sports ss set status='withdrawn',review_note=null,updated_by=coalesce(v_session.representative_user_id,ss.updated_by),updated_at=now() where ss.team_id=l.team_id and ss.student_id=p_student_id and ss.status<>'withdrawn' and not(ss.sport_id=any(p_sport_ids)) and (ss.status<>'approved' or not exists(select 1 from public.team_sports ts where ts.team_id=ss.team_id and ts.sport_id=ss.sport_id and ts.lock_approved));
 foreach v_sport_id in array p_sport_ids loop
   insert into public.team_student_sports(team_id,student_id,sport_id,status,review_note,updated_by,updated_at) values(l.team_id,p_student_id,v_sport_id,'pending',null,v_session.representative_user_id,now())
   on conflict(team_id,student_id,sport_id) do update set status=case when team_student_sports.status='approved' then 'approved' else 'pending' end,review_note=null,updated_by=coalesce(v_session.representative_user_id,team_student_sports.updated_by),updated_at=now();
 end loop;
 select jsonb_build_object('shirt_name',d.shirt_name,'shirt_number',d.shirt_number,'sports',coalesce((select jsonb_agg(jsonb_build_object('sport_id',ss.sport_id,'status',ss.status) order by ss.sport_id) from public.team_student_sports ss where ss.team_id=l.team_id and ss.student_id=p_student_id),'[]'::jsonb)) into v_new from public.team_student_details d where d.team_id=l.team_id and d.student_id=p_student_id;
 insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action,old_data,new_data) values(l.team_id,p_student_id,coalesce(v_session.representative_user_id,auth.uid()),l.id,v_session.id,'student_info_saved',v_old,v_new);
 return jsonb_build_object('ok',true,'message','Informações salvas com sucesso!');
end $$;
revoke all on function public.save_team_student_info(text,uuid,text,integer,uuid[]) from public;
grant execute on function public.save_team_student_info(text,uuid,text,integer,uuid[]) to anon,authenticated;

create or replace function public.admin_team_representative_audit(p_team_id uuid)
returns table(actor_name text,student_name text,action text,changed_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  return query select coalesce(p.display_name,(select concat_ws(' ',rs.first_name,rs.last_name) from public.team_representatives rr join public.students rs on rs.id=rr.student_id where rr.user_id=e.actor_id limit 1),'Acesso por link da equipe'),
    coalesce(concat_ws(' ',s.first_name,s.last_name),'Equipe'),e.action,e.created_at
  from public.team_access_events e
  left join public.profiles p on p.id=e.actor_id
  left join public.students s on s.id=e.student_id
  where e.team_id=p_team_id and e.action in ('student_info_saved','shirt_photo_submitted','shirt_photo_reviewed','representative_activated','representative_account_created')
  order by e.created_at desc limit 50;
end $$;
revoke all on function public.admin_team_representative_audit(uuid) from public;
grant execute on function public.admin_team_representative_audit(uuid) to authenticated;

create or replace function public.validate_team_access_session(p_session_token text)
returns public.team_access_sessions language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions;
begin
  if p_session_token is null or length(p_session_token)<>64 or p_session_token!~'^[0-9a-f]{64}$' then return null; end if;
  select s.* into v_session from public.team_access_sessions s join public.team_access_links l on l.id=s.link_id
  where s.session_hash=encode(digest(p_session_token,'sha256'),'hex') and s.revoked_at is null and s.expires_at>now()
    and ((s.representative_user_id is not null and s.representative_user_id=auth.uid()
       and exists(select 1 from public.team_representatives r where r.user_id=auth.uid() and r.team_id=l.team_id and r.active))
      or (s.representative_user_id is null and l.revoked_at is null and l.expires_at>now()));
  if not found then return null; end if;
  update public.team_access_sessions set last_used_at=now() where id=v_session.id;
  return v_session;
end $$;
revoke all on function public.validate_team_access_session(text) from public;
grant execute on function public.validate_team_access_session(text) to anon,authenticated;

comment on table public.team_representatives is 'Up to two individually authenticated student representatives for each school team.';
comment on table public.team_representative_invites is 'Single-use email-bound invitations for student representative account activation.';

create or replace function public.submit_team_shirt_photo(p_session_token text,p_student_id uuid,p_storage_path text,p_upload_token text)
returns jsonb language plpgsql security definer set search_path=public,storage,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_old_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  if not exists(select 1 from public.team_shirt_upload_tokens u where u.token_hash=encode(digest(p_upload_token,'sha256'),'hex') and u.team_id=v_link.team_id and u.student_id=p_student_id and u.session_id=v_session.id and u.expires_at>now() and u.used_at is null) then return jsonb_build_object('error','invalid_upload_token'); end if;
  if p_storage_path !~ ('^'||v_link.team_id::text||'/'||p_student_id::text||'/'||encode(digest(p_upload_token,'sha256'),'hex')||'\.(jpg|png|webp)$') then return jsonb_build_object('error','invalid_upload_path'); end if;
  if not exists(select 1 from storage.objects o where o.bucket_id='team-shirt-photos' and o.name=p_storage_path and o.metadata->>'team_shirt_upload_token'=p_upload_token) then return jsonb_build_object('error','photo_upload_missing'); end if;
  if not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=v_link.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
  select shirt_photo_path into v_old_path from public.team_student_details where team_id=v_link.team_id and student_id=p_student_id;
  insert into public.team_student_details(team_id,student_id,shirt_photo_path,shirt_photo_status,shirt_photo_review_note,shirt_photo_submitted_at,shirt_photo_reviewed_at,shirt_photo_reviewed_by,updated_at)
  values(v_link.team_id,p_student_id,p_storage_path,'pending',null,now(),null,null,now()) on conflict(team_id,student_id) do update set shirt_photo_path=excluded.shirt_photo_path,shirt_photo_status='pending',shirt_photo_review_note=null,shirt_photo_submitted_at=now(),shirt_photo_reviewed_at=null,shirt_photo_reviewed_by=null,updated_at=now();
  update public.team_shirt_upload_tokens set used_at=now() where token_hash=encode(digest(p_upload_token,'sha256'),'hex');
  insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action,old_data,new_data)
  values(v_link.team_id,p_student_id,coalesce(v_session.representative_user_id,auth.uid()),v_link.id,v_session.id,'shirt_photo_submitted',jsonb_build_object('path',v_old_path),jsonb_build_object('path',p_storage_path,'status','pending'));
  return jsonb_build_object('ok',true,'message','Imagem da camisa enviada para análise.');
end $$;
revoke all on function public.submit_team_shirt_photo(text,uuid,text,text) from public;
grant execute on function public.submit_team_shirt_photo(text,uuid,text,text) to anon,authenticated;

create or replace function public.start_team_access_session(p_slug text,p_share_secret text)
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_link public.team_access_links;v_token text;v_session uuid;
begin
 select l.* into v_link from public.team_access_links l join public.teams t on t.id=l.team_id where t.slug=p_slug and t.active and t.deleted_at is null and l.token_hash=encode(digest(p_share_secret,'sha256'),'hex') and l.revoked_at is null and l.expires_at>now() for update;
 if not found then return jsonb_build_object('error','link_unavailable');end if;
 v_token:=encode(gen_random_bytes(32),'hex');
 insert into public.team_access_sessions(link_id,session_hash,expires_at) values(v_link.id,encode(digest(v_token,'sha256'),'hex'),least(v_link.expires_at,now()+interval '8 hours')) returning id into v_session;
 update public.team_access_links set last_used_at=now() where id=v_link.id;
 return jsonb_build_object('session_token',v_token);
end $$;
revoke all on function public.start_team_access_session(text,text) from public;
grant execute on function public.start_team_access_session(text,text) to anon,authenticated;
