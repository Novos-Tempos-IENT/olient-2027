-- Private shirt-photo submissions with team-link scoped upload/read policies.
alter table public.team_student_details
  add column if not exists shirt_photo_path text,
  add column if not exists shirt_photo_status text not null default 'not_submitted'
    check (shirt_photo_status in ('not_submitted','pending','approved','correction_requested')),
  add column if not exists shirt_photo_review_note text,
  add column if not exists shirt_photo_submitted_at timestamptz,
  add column if not exists shirt_photo_reviewed_at timestamptz,
  add column if not exists shirt_photo_reviewed_by uuid references public.profiles(id);

create table if not exists public.team_shirt_upload_tokens (
  id uuid primary key default gen_random_uuid(),
  token_hash text not null unique,
  team_id uuid not null references public.teams(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  session_id uuid not null references public.team_access_sessions(id) on delete cascade,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.team_shirt_upload_tokens enable row level security;
revoke all on public.team_shirt_upload_tokens from anon,authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('team-shirt-photos','team-shirt-photos',false,8388608,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

create or replace function public.authorize_team_shirt_photo_upload(p_name text,p_token text)
returns boolean language plpgsql stable security definer set search_path=public,storage,extensions set row_security=off as $$
declare v_team uuid; v_student uuid; v_token text;
begin
  if p_name !~ '^[0-9a-fA-F-]{36}/[0-9a-fA-F-]{36}/[0-9a-f]{64}\.(jpg|png|webp)$' or p_token is null then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid;
  v_student:=split_part(p_name,'/',2)::uuid;
  v_token:=split_part(split_part(p_name,'/',3),'.',1);
  return exists(
    select 1 from public.team_shirt_upload_tokens u
    join public.team_access_sessions s on s.id=u.session_id and s.revoked_at is null and s.expires_at>now()
    join public.team_access_links l on l.id=s.link_id and l.team_id=u.team_id and l.revoked_at is null and l.expires_at>now()
    join public.team_students ts on ts.team_id=u.team_id and ts.student_id=u.student_id and ts.left_at is null
    where u.token_hash=encode(digest(p_token,'sha256'),'hex') and u.team_id=v_team and u.student_id=v_student
      and u.expires_at>now() and u.used_at is null and v_token=encode(digest(p_token,'sha256'),'hex')
  );
exception when others then return false;
end $$;

create or replace function public.can_read_team_shirt_photo(p_name text)
returns boolean language plpgsql stable security definer set search_path=public,storage set row_security=off as $$
declare v_team uuid; v_student uuid;
begin
  if public.is_admin() then return true; end if;
  if p_name !~ '^[0-9a-fA-F-]{36}/[0-9a-fA-F-]{36}/[0-9a-f]{64}\.(jpg|png|webp)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid; v_student:=split_part(p_name,'/',2)::uuid;
  return exists(select 1 from public.team_access_links l
    join public.team_students ts on ts.team_id=l.team_id and ts.student_id=v_student and ts.left_at is null
    where l.team_id=v_team and l.revoked_at is null and l.expires_at>now());
exception when others then return false;
end $$;

create or replace function public.can_delete_team_shirt_photo(p_name text)
returns boolean language plpgsql stable security definer set search_path=public,storage set row_security=off as $$
declare v_team uuid; v_student uuid;
begin
  if public.is_admin() then return true; end if;
  if p_name !~ '^[0-9a-fA-F-]{36}/[0-9a-fA-F-]{36}/[0-9a-f]{64}\.(jpg|png|webp)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid; v_student:=split_part(p_name,'/',2)::uuid;
  -- Students replace an image by uploading a new object; only administrators
  -- may remove stored objects, preventing deletion of another student's photo.
  return false;
exception when others then return false;
end $$;

revoke all on function public.authorize_team_shirt_photo_upload(text,text) from public;
revoke all on function public.can_read_team_shirt_photo(text) from public;
revoke all on function public.can_delete_team_shirt_photo(text) from public;
grant execute on function public.authorize_team_shirt_photo_upload(text,text) to anon,authenticated;
grant execute on function public.can_read_team_shirt_photo(text) to anon,authenticated;
grant execute on function public.can_delete_team_shirt_photo(text) to anon,authenticated;

drop policy if exists "team shirt photos read" on storage.objects;
drop policy if exists "team shirt photos upload" on storage.objects;
drop policy if exists "team shirt photos replace" on storage.objects;
drop policy if exists "team shirt photos delete" on storage.objects;
create policy "team shirt photos read" on storage.objects for select
  using(bucket_id='team-shirt-photos' and public.can_read_team_shirt_photo(name));
create policy "team shirt photos upload" on storage.objects for insert
  with check(bucket_id='team-shirt-photos' and public.authorize_team_shirt_photo_upload(name,metadata->>'team_shirt_upload_token'));
create policy "team shirt photos replace" on storage.objects for update
  using(bucket_id='team-shirt-photos' and public.can_read_team_shirt_photo(name))
  with check(bucket_id='team-shirt-photos' and public.authorize_team_shirt_photo_upload(name,metadata->>'team_shirt_upload_token'));
create policy "team shirt photos delete" on storage.objects for delete
  using(bucket_id='team-shirt-photos' and public.can_delete_team_shirt_photo(name));

create or replace function public.create_team_shirt_upload_token(p_session_token text,p_student_id uuid,p_content_type text)
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_token text; v_extension text; v_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found or v_link.edits_locked then return jsonb_build_object('error',case when not found then 'link_unavailable' else 'edits_locked' end); end if;
  if not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=v_link.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
  if p_content_type not in ('image/jpeg','image/png','image/webp') then return jsonb_build_object('error','invalid_photo_type'); end if;
  if not public.team_access_rate_limit(v_link.id,p_student_id,'upload') then return jsonb_build_object('error','rate_limited'); end if;
  v_extension:=case p_content_type when 'image/jpeg' then 'jpg' when 'image/png' then 'png' else 'webp' end;
  v_token:=encode(gen_random_bytes(24),'hex');
  v_path:=v_link.team_id::text||'/'||p_student_id::text||'/'||encode(digest(v_token,'sha256'),'hex')||'.'||v_extension;
  insert into public.team_shirt_upload_tokens(token_hash,team_id,student_id,session_id,expires_at)
  values(encode(digest(v_token,'sha256'),'hex'),v_link.team_id,p_student_id,v_session.id,now()+interval '10 minutes');
  return jsonb_build_object('upload_token',v_token,'storage_path',v_path,'expires_at',now()+interval '10 minutes');
end $$;

create or replace function public.submit_team_shirt_photo(p_session_token text,p_student_id uuid,p_storage_path text,p_upload_token text)
returns jsonb language plpgsql security definer set search_path=public,storage,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_old_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  if not exists(select 1 from public.team_shirt_upload_tokens u where u.token_hash=encode(digest(p_upload_token,'sha256'),'hex') and u.team_id=v_link.team_id and u.student_id=p_student_id and u.session_id=v_session.id and u.expires_at>now() and u.used_at is null) then return jsonb_build_object('error','invalid_upload_token'); end if;
  if p_storage_path !~ ('^'||v_link.team_id::text||'/'||p_student_id::text||'/'||encode(digest(p_upload_token,'sha256'),'hex')||'\.(jpg|png|webp)$') then return jsonb_build_object('error','invalid_upload_path'); end if;
  if not exists(select 1 from storage.objects o where o.bucket_id='team-shirt-photos' and o.name=p_storage_path and o.metadata->>'team_shirt_upload_token'=p_upload_token) then return jsonb_build_object('error','photo_upload_missing'); end if;
  if not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=v_link.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
  select shirt_photo_path into v_old_path from public.team_student_details where team_id=v_link.team_id and student_id=p_student_id;
  insert into public.team_student_details(team_id,student_id,shirt_photo_path,shirt_photo_status,shirt_photo_review_note,shirt_photo_submitted_at,shirt_photo_reviewed_at,shirt_photo_reviewed_by,updated_at)
  values(v_link.team_id,p_student_id,p_storage_path,'pending',null,now(),null,null,now())
  on conflict(team_id,student_id) do update set shirt_photo_path=excluded.shirt_photo_path,shirt_photo_status='pending',shirt_photo_review_note=null,shirt_photo_submitted_at=now(),shirt_photo_reviewed_at=null,shirt_photo_reviewed_by=null,updated_at=now();
  update public.team_shirt_upload_tokens set used_at=now() where token_hash=encode(digest(p_upload_token,'sha256'),'hex');
  insert into public.team_access_events(team_id,student_id,link_id,session_id,action,old_data,new_data)
  values(v_link.team_id,p_student_id,v_link.id,v_session.id,'shirt_photo_submitted',jsonb_build_object('path',v_old_path),jsonb_build_object('path',p_storage_path,'status','pending'));
  return jsonb_build_object('ok',true,'message','Imagem da camisa enviada para análise.');
end $$;

create or replace function public.get_team_shirt_photo_status(p_session_token text,p_student_id uuid)
returns jsonb language plpgsql security definer set search_path=public set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_photo public.team_student_details;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found or not exists(select 1 from public.team_students ts where ts.team_id=v_link.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
  select * into v_photo from public.team_student_details where team_id=v_link.team_id and student_id=p_student_id;
  if not found then return jsonb_build_object('status','not_submitted','storage_path',null,'review_note',null); end if;
  return jsonb_build_object('status',v_photo.shirt_photo_status,'storage_path',v_photo.shirt_photo_path,'review_note',v_photo.shirt_photo_review_note,'submitted_at',v_photo.shirt_photo_submitted_at);
end $$;

create or replace function public.admin_review_team_shirt_photo(p_team_id uuid,p_student_id uuid,p_decision text,p_note text default null)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_old_status text; v_old_note text;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_decision not in ('approved','correction_requested') then raise exception 'Invalid decision'; end if;
  if p_decision='correction_requested' and length(trim(coalesce(p_note,'')))<3 then raise exception 'Informe o motivo da correção com pelo menos 3 caracteres'; end if;
  select shirt_photo_status,shirt_photo_review_note into v_old_status,v_old_note from public.team_student_details where team_id=p_team_id and student_id=p_student_id and shirt_photo_path is not null for update;
  if not found or v_old_status<>'pending' then raise exception 'A imagem não está aguardando análise'; end if;
  update public.team_student_details set shirt_photo_status=p_decision,shirt_photo_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) else null end,shirt_photo_reviewed_at=now(),shirt_photo_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id and student_id=p_student_id;
  insert into public.team_access_events(team_id,student_id,actor_id,action,old_data,new_data)
  values(p_team_id,p_student_id,auth.uid(),'shirt_photo_reviewed',jsonb_build_object('status',v_old_status,'note',v_old_note),jsonb_build_object('status',p_decision,'note',p_note));
end $$;

revoke all on function public.create_team_shirt_upload_token(text,uuid,text) from public;
revoke all on function public.submit_team_shirt_photo(text,uuid,text,text) from public;
revoke all on function public.get_team_shirt_photo_status(text,uuid) from public;
revoke all on function public.admin_review_team_shirt_photo(uuid,uuid,text,text) from public;
grant execute on function public.create_team_shirt_upload_token(text,uuid,text) to anon,authenticated;
grant execute on function public.submit_team_shirt_photo(text,uuid,text,text) to anon,authenticated;
grant execute on function public.get_team_shirt_photo_status(text,uuid) to anon,authenticated;
grant execute on function public.admin_review_team_shirt_photo(uuid,uuid,text,text) to authenticated;

comment on column public.team_student_details.shirt_photo_path is 'Private Supabase Storage path for the team shirt image submitted by this student.';
