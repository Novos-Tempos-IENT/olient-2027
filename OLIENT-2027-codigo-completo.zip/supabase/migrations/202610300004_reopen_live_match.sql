create or replace function public.reopen_match_live(p_match_id uuid) returns jsonb
language plpgsql security definer set search_path=public as $$
declare v_data jsonb; m public.matches; result_row record;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 select * into m from matches where id=p_match_id and deleted_at is null for update;
 if m.id is null then raise exception 'Partida indisponível'; end if;
 select data into v_data from match_live_state where match_id=p_match_id for update;
 if v_data->>'finishedAt' is null then raise exception 'A partida não está finalizada'; end if;
 for result_row in select id from match_results where match_id=p_match_id and status in ('confirmed','published') loop
  update score_ledger set voided_at=now() where source_type='match_result' and source_id=result_row.id and voided_at is null;
 end loop;
 update match_results set status='provisional' where match_id=p_match_id and status in ('confirmed','published');
 update matches set home_score=null,away_score=null,status='confirmed',updated_at=now() where id=p_match_id;
 v_data := (v_data - 'finishedAt') || jsonb_build_object('runningSince',null);
 update match_live_state set data=v_data,updated_at=now() where match_id=p_match_id;
 insert into audit_logs(actor_id,action,table_name,record_id,new_data) values(auth.uid(),'reopen_match','matches',p_match_id::text,v_data);
 return v_data;
end $$;
revoke all on function public.reopen_match_live(uuid) from public;
grant execute on function public.reopen_match_live(uuid) to authenticated;
-- A reopened match needs a new result revision when finalized again.
do $migration$
declare definition text;
begin
 definition := pg_get_functiondef('public.finish_match_live(uuid,jsonb)'::regprocedure);
 definition := replace(definition,'''live-finish-''||p_match_id::text','''live-finish-''||p_match_id::text||''-''||gen_random_uuid()::text');
 execute definition;
end $migration$;
notify pgrst,'reload schema';

