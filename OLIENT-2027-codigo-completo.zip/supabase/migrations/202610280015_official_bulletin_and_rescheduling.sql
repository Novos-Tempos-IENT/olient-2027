-- Supports official bulletin printing and auditable match rescheduling.
alter table public.matches
  add column if not exists postponed boolean not null default false,
  add column if not exists postponement_reason text;

create table if not exists public.match_schedule_changes (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  previous_scheduled_at timestamptz,
  new_scheduled_at timestamptz not null,
  previous_court_name text,
  new_court_name text not null,
  reason text not null check(length(trim(reason)) between 3 and 1000),
  changed_by uuid not null references public.profiles(id),
  changed_at timestamptz not null default now()
);
create index if not exists match_schedule_changes_match_idx
  on public.match_schedule_changes(match_id,changed_at desc);
alter table public.match_schedule_changes enable row level security;
drop policy if exists "staff read match schedule changes" on public.match_schedule_changes;
drop policy if exists "admins manage match schedule changes" on public.match_schedule_changes;
create policy "staff read match schedule changes" on public.match_schedule_changes
  for select using(public.current_app_role() is not null);
create policy "admins manage match schedule changes" on public.match_schedule_changes
  for all using(public.is_admin()) with check(public.is_admin());
grant select on public.match_schedule_changes to authenticated;

create or replace function public.admin_reschedule_match(
  p_match_id uuid,
  p_new_scheduled_at timestamptz,
  p_new_court_name text,
  p_reason text
) returns void
language plpgsql security definer set search_path=public set row_security=off as $$
declare
  v_match public.matches;
  v_court text;
  v_day date;
  v_end timestamptz;
  v_gap integer:=0;
  v_rest integer:=0;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_new_scheduled_at is null or p_new_scheduled_at<=now() then
    raise exception 'A nova data e horário devem estar no futuro';
  end if;
  if length(trim(coalesce(p_reason,'')))<3 then
    raise exception 'Informe o motivo do adiamento com pelo menos 3 caracteres';
  end if;

  select * into v_match from public.matches where id=p_match_id and deleted_at is null for update;
  if not found then raise exception 'Partida não encontrada'; end if;
  if coalesce(v_match.schedule_status,'draft')<>'published' or v_match.status not in ('confirmed','published') then
    raise exception 'Somente partidas publicadas podem ser adiadas';
  end if;
  if v_match.home_score is not null or v_match.away_score is not null
     or exists(select 1 from public.match_results r where r.match_id=p_match_id) then
    raise exception 'Uma partida com resultado registrado não pode ser adiada';
  end if;

  v_court:=coalesce(nullif(trim(p_new_court_name),''),v_match.court_name,v_match.venue);
  if v_court not in ('Quadra 1','Quadra 2','Futmesa','Tênis de Mesa') then
    raise exception 'Selecione um local oficial válido';
  end if;
  v_day:=(p_new_scheduled_at at time zone 'America/Sao_Paulo')::date;
  v_end:=p_new_scheduled_at+make_interval(mins=>coalesce(v_match.duration_minutes,30));

  select coalesce((b.config->>'interval_minutes')::integer,0),
         coalesce((b.config->>'team_rest_minutes')::integer,0)
    into v_gap,v_rest
    from public.schedule_batches b where b.id=v_match.schedule_batch_id;
  v_gap:=coalesce(v_gap,0); v_rest:=coalesce(v_rest,0);

  if not exists(
    select 1 from public.court_availability ca
    where ca.court_name=v_court
      and (ca.available_from at time zone 'America/Sao_Paulo')::date=v_day
      and p_new_scheduled_at>=ca.available_from and v_end<=ca.available_until
      and not exists(
        select 1 from jsonb_array_elements(coalesce(ca.blocked_windows,'[]'::jsonb)||coalesce(ca.pause_windows,'[]'::jsonb)) w
        where p_new_scheduled_at < ((v_day::text||' '||(w->>'end'))::timestamp at time zone 'America/Sao_Paulo')
          and v_end > ((v_day::text||' '||(w->>'start'))::timestamp at time zone 'America/Sao_Paulo')
      )
  ) then raise exception 'O horário não está dentro de uma janela oficial disponível para esse local'; end if;

  if exists(
    select 1 from public.matches m
    where m.id<>p_match_id and m.deleted_at is null
      and coalesce(m.schedule_status,'draft')<>'cancelled'
      and m.court_name=v_court
      and m.scheduled_at < v_end+make_interval(mins=>v_gap)
      and m.scheduled_at+make_interval(mins=>coalesce(m.duration_minutes,30)) > p_new_scheduled_at-make_interval(mins=>v_gap)
  ) then raise exception 'Já existe uma partida nesse local e horário'; end if;

  if exists(
    select 1 from public.matches m
    where m.id<>p_match_id and m.deleted_at is null
      and coalesce(m.schedule_status,'draft')<>'cancelled'
      and (m.home_team_id in (v_match.home_team_id,v_match.away_team_id)
        or m.away_team_id in (v_match.home_team_id,v_match.away_team_id))
      and m.scheduled_at < v_end+make_interval(mins=>v_rest)
      and m.scheduled_at+make_interval(mins=>coalesce(m.duration_minutes,30)) > p_new_scheduled_at-make_interval(mins=>v_rest)
  ) then raise exception 'Uma das equipes já tem partida nesse horário ou período de descanso'; end if;

  insert into public.match_schedule_changes(match_id,previous_scheduled_at,new_scheduled_at,previous_court_name,new_court_name,reason,changed_by)
    values(p_match_id,v_match.scheduled_at,p_new_scheduled_at,coalesce(v_match.court_name,v_match.venue),v_court,left(trim(p_reason),1000),auth.uid());
  update public.matches set scheduled_at=p_new_scheduled_at,court_name=v_court,venue=v_court,
    postponed=true,postponement_reason=left(trim(p_reason),1000),updated_at=now()
    where id=p_match_id;
  insert into public.audit_logs(actor_id,action,table_name,record_id,old_data,new_data)
    values(auth.uid(),'reschedule_match','matches',p_match_id::text,
      jsonb_build_object('scheduled_at',v_match.scheduled_at,'court_name',v_match.court_name),
      jsonb_build_object('scheduled_at',p_new_scheduled_at,'court_name',v_court,'reason',left(trim(p_reason),1000)));
end $$;
revoke all on function public.admin_reschedule_match(uuid,timestamptz,text,text) from public;
grant execute on function public.admin_reschedule_match(uuid,timestamptz,text,text) to authenticated;

comment on column public.matches.postponed is 'True when the match has been rescheduled by the organization.';
