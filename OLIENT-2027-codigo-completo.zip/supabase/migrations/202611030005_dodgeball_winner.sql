-- Winner selection replaces the manual dodgeball score. 1–0 is an internal result marker.
do $migration$
declare definition text; start_at integer; end_at integer;
begin
 definition:=pg_get_functiondef('public.finish_match_live(uuid,jsonb)'::regprocedure);
 start_at:=position('if p_data->''finalScore''->>''home'' is null' in definition);
 if start_at=0 then raise exception 'Aplique primeiro 202611030004_dodgeball_final_score.sql'; end if;
 end_at:=position(' end if;' in substring(definition from start_at));
 -- Replace the entire final dodgeball branch up to the result confirmation.
 definition:=substring(definition for start_at-1)||$patch$
 if p_data->>'winnerTeamId' not in (m.home_team_id::text,m.away_team_id::text) or p_data->>'winnerTeamId' is null then raise exception 'Selecione a equipe vencedora'; end if;
 home_points:=case when p_data->>'winnerTeamId'=m.home_team_id::text then 1 else 0 end;
 away_points:=case when p_data->>'winnerTeamId'=m.away_team_id::text then 1 else 0 end;
 end if;
 $patch$||substring(definition from position('perform public.confirm_match_result' in definition));
 execute definition;
end $migration$;
notify pgrst,'reload schema';
