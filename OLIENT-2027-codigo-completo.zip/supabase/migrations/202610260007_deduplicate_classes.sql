-- Remove equivalently named classes while preserving student and team associations.
-- Covers legacy labels such as "6°A" and "6A".
create or replace function public.olient_normalize_name(p_value text)
returns text language sql immutable set search_path=public as $$
 select regexp_replace(regexp_replace(translate(lower(trim(coalesce(p_value,''))),'áàâãäéèêëíìîïóòôõöúùûüçñ','aaaaaeeeeiiiiooooouuuucn'),'[º°ª]','','g'),'\s+',' ','g')
$$;

do $$
declare duplicate_group record; keeper_id uuid; duplicate_ids uuid[];
begin
 for duplicate_group in
   select public.olient_normalize_name(name) as normalized_name
   from public.classes
   group by public.olient_normalize_name(name)
   having count(*) > 1
 loop
   select id into keeper_id
   from public.classes
   where public.olient_normalize_name(name) = duplicate_group.normalized_name
   order by active desc, created_at, id
   limit 1;

   select array_agg(id) into duplicate_ids
   from public.classes
   where public.olient_normalize_name(name) = duplicate_group.normalized_name
     and id <> keeper_id;

   update public.students
   set class_id = keeper_id, updated_at = now()
   where class_id = any(duplicate_ids);

   if to_regclass('public.team_classes') is not null then
     execute 'insert into public.team_classes(team_id,class_id,created_by,created_at)
       select tc.team_id,$1,tc.created_by,tc.created_at
       from public.team_classes tc where tc.class_id = any($2)
       on conflict (class_id) do nothing'
       using keeper_id, duplicate_ids;
     execute 'delete from public.team_classes where class_id = any($1)'
       using duplicate_ids;
   end if;

   delete from public.classes where id = any(duplicate_ids);
 end loop;
end $$;

create unique index if not exists classes_normalized_name_unique_idx
  on public.classes(public.olient_normalize_name(name));
