-- Per-event court windows, auditable fixture generation, and admin-only scheduling operations.
create table public.court_availability (
 id uuid primary key default gen_random_uuid(), court_name text not null check(court_name in ('Quadra 1','Quadra 2')),
 available_from timestamptz not null, available_until timestamptz not null, blocked_windows jsonb not null default '[]'::jsonb,
 pause_windows jsonb not null default '[]'::jsonb, created_by uuid not null references public.profiles(id), created_at timestamptz not null default now(),
 check(available_until>available_from), unique(court_name,available_from,available_until)
);
alter table public.matches add column court_name text check(court_name is null or court_name in ('Quadra 1','Quadra 2'));
alter table public.matches add column duration_minutes integer check(duration_minutes is null or duration_minutes>0);
alter table public.matches add column schedule_status text not null default 'draft' check(schedule_status in ('draft','published','cancelled'));
alter table public.matches add column generation_id uuid;
alter table public.matches add column fixture_key text;
create unique index uq_match_fixture_generation on public.matches(generation_id,fixture_key) where generation_id is not null and fixture_key is not null;
create table public.fixture_draws (
 id uuid primary key default gen_random_uuid(), sport_id uuid not null references public.sports(id), category text,
 format text not null check(format in ('single_elimination','third_place','round_robin')),
 seed bigint not null, fixtures jsonb not null, byes jsonb not null default '[]'::jsonb,
 created_by uuid not null references public.profiles(id), created_at timestamptz not null default now(), replaced_at timestamptz,
 idempotency_key text not null unique
);
create table public.schedule_generation (
 id uuid primary key default gen_random_uuid(), sport_id uuid not null references public.sports(id), category text,
 format text not null, config jsonb not null, capacity jsonb not null, result jsonb not null,
 status text not null default 'draft' check(status in ('draft','published','superseded')),
 created_by uuid not null references public.profiles(id), created_at timestamptz not null default now(), published_at timestamptz,
 idempotency_key text not null unique
);
alter table public.court_availability enable row level security;
alter table public.fixture_draws enable row level security;
alter table public.schedule_generation enable row level security;
create policy "court windows staff read" on public.court_availability for select using(public.current_app_role() is not null);
create policy "court windows admin manage" on public.court_availability for all using(public.is_admin()) with check(public.is_admin());
create policy "draws staff read" on public.fixture_draws for select using(public.current_app_role() is not null);
create policy "draws admin read write" on public.fixture_draws for all using(public.is_admin()) with check(public.is_admin());
create policy "schedules published public draft staff" on public.schedule_generation for select using(status='published' or public.current_app_role() is not null);
create policy "schedules admin manage" on public.schedule_generation for all using(public.is_admin()) with check(public.is_admin());
grant select on public.court_availability,public.fixture_draws,public.schedule_generation to authenticated;
grant select on public.schedule_generation to anon;
drop policy if exists "published or staff matches read" on public.matches;
create policy "published schedule matches public" on public.matches for select using(schedule_status='published' or public.current_app_role() is not null);
revoke insert,update,delete on public.matches from authenticated;
revoke insert,update,delete on public.registrations from authenticated;

-- Students can never create/alter official modality registrations or fixtures directly.
drop policy if exists "managers registrations manage" on public.registrations;
create policy "only administrators manage modality registrations" on public.registrations for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "managers matches manage" on public.matches;
create policy "only administrators manage matches" on public.matches for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "managers insert results" on public.match_results;
create policy "only administrators insert results" on public.match_results for insert with check(public.is_admin());
drop policy if exists "managers challenge results manage" on public.challenge_results;
create policy "only administrators manage challenge results" on public.challenge_results for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "managers registrations manage" on public.registrations;
create function public.set_modality_registrations(p_sport_id uuid,p_team_ids uuid[],p_category text default null) returns integer
language plpgsql security definer set search_path=public as $$
declare n integer;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if exists(select 1 from unnest(p_team_ids) u(id) left join teams t on t.id=u.id where t.id is null or not t.active or t.deleted_at is not null) then raise exception 'Unknown or inactive team in registration set'; end if;
 insert into registrations(team_id,sport_id,category,status,created_by)
 select distinct x,p_sport_id,p_category,'approved',auth.uid() from unnest(p_team_ids) x
 on conflict(team_id,sport_id,category) do update set status='approved',updated_at=now();
 get diagnostics n=row_count;
 update registrations set status='withdrawn',updated_at=now() where sport_id=p_sport_id and category is not distinct from p_category and status='approved' and not(team_id=any(coalesce(p_team_ids,'{}'::uuid[])));
 insert into audit_logs(actor_id,action,table_name,new_data) values(auth.uid(),'set_modality_registrations','registrations',jsonb_build_object('sport_id',p_sport_id,'category',p_category,'teams',p_team_ids));
 return n;
end $$;
revoke all on function public.set_modality_registrations(uuid,uuid[],text) from public;
grant execute on function public.set_modality_registrations(uuid,uuid[],text) to authenticated;

create function public.save_generated_schedule(p_generation_id uuid,p_sport_id uuid,p_category text,p_format text,p_config jsonb,p_capacity jsonb,p_result jsonb,p_idempotency_key text) returns uuid
language plpgsql security definer set search_path=public as $$
declare out_id uuid; item jsonb;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if exists(select 1 from schedule_generation where idempotency_key=p_idempotency_key) then select id into out_id from schedule_generation where idempotency_key=p_idempotency_key; return out_id; end if;
 if exists(select 1 from jsonb_array_elements(coalesce(p_result->'unscheduled','[]'::jsonb))) then raise exception 'Cannot save schedule while fixtures remain without times'; end if;
 insert into schedule_generation(sport_id,category,format,config,capacity,result,created_by,idempotency_key) values(p_sport_id,p_category,p_format,p_config,p_capacity,p_result,auth.uid(),p_idempotency_key) returning id into out_id;
 for item in select value from jsonb_array_elements(coalesce(p_result->'scheduled','[]'::jsonb)) loop
  if item->>'home' is null or item->>'away' is null or item->>'home' like 'A definir%' or item->>'away' like 'A definir%' then raise exception 'Unresolved fixture participants cannot be scheduled'; end if;
  if not exists(select 1 from registrations r where r.sport_id=p_sport_id and r.category is not distinct from p_category and r.team_id=(item->>'home')::uuid and r.status='approved') or not exists(select 1 from registrations r where r.sport_id=p_sport_id and r.category is not distinct from p_category and r.team_id=(item->>'away')::uuid and r.status='approved') then raise exception 'Fixture includes a team not officially approved for this sport and category'; end if;
  if not exists(select 1 from court_availability ca where ca.court_name=item->>'court' and ca.available_from::date=(p_config->>'event_date')::date and (p_config->>'event_date')::date+(item->>'start')::time>=ca.available_from and (p_config->>'event_date')::date+(item->>'end')::time<=ca.available_until and not exists(select 1 from jsonb_array_elements(ca.blocked_windows||ca.pause_windows) b where (p_config->>'event_date')::date+(item->>'start')::time < (b->>'end')::time and (p_config->>'event_date')::date+(item->>'end')::time > (b->>'start')::time)) then raise exception 'Fixture is outside official court availability or overlaps a blocked period'; end if;
  if exists(select 1 from matches where coalesce(schedule_status,'draft')<>'cancelled' and court_name=item->>'court' and scheduled_at < ((p_config->>'event_date')::date + (item->>'end')::time) and scheduled_at + make_interval(mins=>duration_minutes) > ((p_config->>'event_date')::date + (item->>'start')::time)) then raise exception 'Court time conflict'; end if;
  if exists(select 1 from matches where coalesce(schedule_status,'draft')<>'cancelled' and scheduled_at < ((p_config->>'event_date')::date + (item->>'end')::time) and scheduled_at + make_interval(mins=>duration_minutes) > ((p_config->>'event_date')::date + (item->>'start')::time) and (home_team_id in ((item->>'home')::uuid,(item->>'away')::uuid) or away_team_id in ((item->>'home')::uuid,(item->>'away')::uuid))) then raise exception 'Team is already scheduled at this time'; end if;
  insert into matches(sport_id,scheduled_at,venue,court_name,duration_minutes,round,status,schedule_status,home_team_id,away_team_id,created_by,generation_id,fixture_key)
  values(p_sport_id,(p_config->>'event_date')::date+(item->>'start')::time,item->>'court',item->>'court',(p_config->>'duration_minutes')::integer,item->>'round','draft','draft',(item->>'home')::uuid,(item->>'away')::uuid,auth.uid(),out_id,item->>'id');
 end loop;
 insert into audit_logs(actor_id,action,table_name,record_id,new_data) values(auth.uid(),'generate_schedule','schedule_generation',out_id::text,jsonb_build_object('format',p_format,'config',p_config,'capacity',p_capacity));
 return out_id;
end $$;
revoke all on function public.save_generated_schedule(uuid,uuid,text,text,jsonb,jsonb,jsonb,text) from public;
grant execute on function public.save_generated_schedule(uuid,uuid,text,text,jsonb,jsonb,jsonb,text) to authenticated;

create function public.publish_schedule(p_generation_id uuid) returns void language plpgsql security definer set search_path=public as $$
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if exists(select 1 from matches where generation_id=p_generation_id and (scheduled_at is null or court_name is null)) then raise exception 'Schedule has incomplete fixtures'; end if;
 update schedule_generation set status='published',published_at=now() where id=p_generation_id and status='draft';
 if not found then raise exception 'Draft schedule not found'; end if;
 update matches set schedule_status='published',status='confirmed' where generation_id=p_generation_id and schedule_status='draft';
 insert into audit_logs(actor_id,action,table_name,record_id) values(auth.uid(),'publish_schedule','schedule_generation',p_generation_id::text);
end $$;
revoke all on function public.publish_schedule(uuid) from public;
grant execute on function public.publish_schedule(uuid) to authenticated;
