-- Programa oficial da gincana OLIENT 2027. Pontuação fica em branco até ser
-- definida pela organização; isso não cria resultados nem lançamentos.
create table if not exists public.gincana_program_sections (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  sort_order integer not null unique,
  created_at timestamptz not null default now()
);
create table if not exists public.gincana_program_items (
  id uuid primary key default gen_random_uuid(),
  section_id uuid not null references public.gincana_program_sections(id) on delete cascade,
  event_date date,
  title text not null,
  sort_order integer not null,
  champion_points numeric(12,2) check(champion_points is null or champion_points>=0),
  runner_up_points numeric(12,2) check(runner_up_points is null or runner_up_points>=0),
  created_at timestamptz not null default now(),
  unique(section_id, sort_order)
);
alter table public.gincana_program_items add column if not exists champion_points numeric(12,2) check(champion_points is null or champion_points>=0);
alter table public.gincana_program_items add column if not exists runner_up_points numeric(12,2) check(runner_up_points is null or runner_up_points>=0);
alter table public.gincana_program_sections enable row level security;
alter table public.gincana_program_items enable row level security;
drop policy if exists "gincana program is publicly readable" on public.gincana_program_sections;
drop policy if exists "gincana program items are publicly readable" on public.gincana_program_items;
drop policy if exists "admins manage gincana sections" on public.gincana_program_sections;
drop policy if exists "admins manage gincana items" on public.gincana_program_items;
create policy "gincana program is publicly readable" on public.gincana_program_sections for select using (true);
create policy "gincana program items are publicly readable" on public.gincana_program_items for select using (true);
create policy "admins manage gincana sections" on public.gincana_program_sections for all using (public.is_admin()) with check (public.is_admin());
create policy "admins manage gincana items" on public.gincana_program_items for all using (public.is_admin()) with check (public.is_admin());
grant select on public.gincana_program_sections, public.gincana_program_items to anon, authenticated;

insert into public.gincana_program_sections(name,sort_order) values
 ('Gincanas',1),('Ação social',2),('Entrada',3),('Vídeos',4),('Esportes',5),('Cartões',6),('Punições',7)
on conflict(name) do update set sort_order=excluded.sort_order;

with seed(section_name,event_date,title,sort_order) as (values
 ('Gincanas','2027-09-30'::date,'Continue a música',1),
 ('Gincanas','2027-09-30'::date,'Embaixadinha feminina',2),
 ('Gincanas','2027-09-30'::date,'Batatinha frita 1, 2, 3',3),
 ('Gincanas','2027-09-30'::date,'Balde de água nos pés',4),
 ('Gincanas','2027-09-30'::date,'Trazer funcionários para dançar',5),
 ('Gincanas','2027-09-30'::date,'Itens aleatórios',6),
 ('Gincanas','2027-10-01'::date,'Batalha de robôs',7),
 ('Gincanas','2027-10-01'::date,'Karaokê / Videokê',8),
 ('Gincanas','2027-10-01'::date,'Guerra de cotonete',9),
 ('Gincanas','2027-10-01'::date,'Corrida do chinelão',10),
 ('Gincanas','2027-10-01'::date,'Twister',11),
 ('Gincanas','2027-10-01'::date,'Crossfit Betim',12),
 ('Gincanas','2027-10-01'::date,'Arco e flecha',13),
 ('Gincanas','2027-10-01'::date,'Itens aleatórios',14),
 ('Gincanas','2027-10-01'::date,'Embaixadinha masculina',15),
 ('Gincanas','2027-10-02'::date,'Cano furado',16),
 ('Gincanas','2027-10-02'::date,'Itens aleatórios',17),
 ('Gincanas','2027-10-02'::date,'Cabo de guerra',18),
 ('Gincanas','2027-10-02'::date,'Torta na cara',19),
 ('Gincanas','2027-10-02'::date,'Batalha dos robôs',20),
 ('Ação social','2027-09-30'::date,'Brinquedos',1),
 ('Ação social','2027-10-01'::date,'Higiene',2),
 ('Ação social','2027-10-02'::date,'1 kg de alimento',3),
 ('Entrada',null,'Camisa (entrada)',1),
 ('Entrada',null,'Camisa (criatividade)',2),
 ('Entrada',null,'Bandeira',3),
 ('Entrada',null,'Traje (criatividade)',4),
 ('Entrada',null,'Traje (entrada)',5),
 ('Vídeos',null,'Grito de guerra',1),
 ('Vídeos',null,'Origem do personagem',2),
 ('Vídeos',null,'Convite para abertura',3),
 ('Esportes',null,'Basquete masculino',1),
 ('Esportes',null,'Basquete feminino',2),
 ('Esportes',null,'Dodgeball',3),
 ('Esportes',null,'Futsal masculino',4),
 ('Esportes',null,'Futsal feminino',5),
 ('Esportes',null,'Handebol misto',6),
 ('Esportes',null,'Tênis de mesa masculino',7),
 ('Esportes',null,'Tênis de mesa feminino',8),
 ('Esportes',null,'Futmesa masculino',9),
 ('Esportes',null,'Futmesa feminino',10),
 ('Esportes',null,'Vôlei de mesa masculino',11),
 ('Esportes',null,'Vôlei de mesa feminino',12),
 ('Esportes',null,'Voleibol',13),
 ('Cartões',null,'Futsal masculino',1),
 ('Cartões',null,'Handebol masculino',2)
)
insert into public.gincana_program_items(section_id,event_date,title,sort_order)
select s.id,seed.event_date,seed.title,seed.sort_order
from seed join public.gincana_program_sections s on s.name=seed.section_name
on conflict(section_id,sort_order) do update set event_date=excluded.event_date,title=excluded.title;

-- The sports section shows final champion and runner-up awards. These are
-- program values only and are not awarded on every individual match.
update public.gincana_program_items i
set champion_points=15000,runner_up_points=5000
from public.gincana_program_sections s
where s.id=i.section_id and s.name='Esportes';
