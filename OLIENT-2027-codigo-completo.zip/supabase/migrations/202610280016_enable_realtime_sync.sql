-- Publish only application tables needed for live refreshes. Realtime still
-- applies each subscriber's SELECT grants and RLS policies.
do $$
declare
  v_table text;
  v_tables text[] := array[
    'classes','students','teams','team_classes','team_students','sports',
    'registrations','team_sports','team_student_details','team_student_sports',
    'matches','match_results','score_ledger','challenges','challenge_results',
    'gincana_program_sections','gincana_program_items','gincana_item_scores'
  ];
begin
  if not exists(select 1 from pg_publication where pubname='supabase_realtime') then
    raise notice 'Publication supabase_realtime not found; skipping realtime registration.';
    return;
  end if;

  if exists(select 1 from pg_publication where pubname='supabase_realtime' and puballtables) then
    return;
  end if;

  foreach v_table in array v_tables loop
    if to_regclass(format('public.%I',v_table)) is not null
      and not exists(
        select 1 from pg_publication_tables
        where pubname='supabase_realtime' and schemaname='public' and tablename=v_table
      ) then
      execute format('alter publication supabase_realtime add table public.%I',v_table);
    end if;
  end loop;
end $$;

create or replace function public.olient_realtime_is_ready()
returns boolean
language sql stable security definer set search_path=pg_catalog as $$
  select exists(select 1 from pg_publication where pubname='supabase_realtime' and puballtables)
    or (
      exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='matches')
      and exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='teams')
      and exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='sports')
      and exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='gincana_program_items')
      and exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='team_student_details')
    )
$$;
revoke all on function public.olient_realtime_is_ready() from public;
grant execute on function public.olient_realtime_is_ready() to anon,authenticated;
