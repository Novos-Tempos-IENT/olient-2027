-- Manual dodgeball final score; burned-player count remains a separate statistic.
do $migration$
declare definition text; marker text;
begin
 definition:=pg_get_functiondef('public.finish_match_live(uuid,jsonb)'::regprocedure);
 marker:=' perform public.confirm_match_result';
 if position(marker in definition)=0 then raise exception 'Função de finalização incompatível'; end if;
 definition:=replace(definition,marker,$patch$
 if exists(select 1 from sports where id=m.sport_id and upper(name) ~ 'QUEIMADA|DODGEBALL') then
  if p_data->'finalScore'->>'home' is null or p_data->'finalScore'->>'away' is null then raise exception 'Informe o placar final da queimada'; end if;
  home_points:=(p_data->'finalScore'->>'home')::integer;
  away_points:=(p_data->'finalScore'->>'away')::integer;
  if home_points<0 or away_points<0 or home_points=away_points then raise exception 'Informe um placar válido com uma equipe vencedora'; end if;
 end if;
 perform public.confirm_match_result
$patch$);
 execute definition;
end $migration$;
notify pgrst,'reload schema';
