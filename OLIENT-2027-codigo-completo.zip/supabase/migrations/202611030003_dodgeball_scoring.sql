do $migration$
declare definition text; marker text;
begin
 definition:=pg_get_functiondef('public.finish_match_live(uuid,jsonb)'::regprocedure);
 marker:=' perform public.confirm_match_result';
 if position(marker in definition)=0 then raise exception 'Função de finalização incompatível'; end if;
 definition:=replace(definition,marker,$patch$
 if exists(select 1 from sports where id=m.sport_id and upper(name) ~ 'QUEIMADA|DODGEBALL') then
  select count(distinct e->>'student') into home_points from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) e where e->>'kind'='Queimado' and e->>'team'=m.away_team_id::text;
  select count(distinct e->>'student') into away_points from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) e where e->>'kind'='Queimado' and e->>'team'=m.home_team_id::text;
 end if;
 perform public.confirm_match_result
$patch$);
 execute definition;
end $migration$;
notify pgrst,'reload schema';
