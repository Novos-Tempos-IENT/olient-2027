-- Public team editing uses a one-time share secret exchanged for a limited server session.
alter table public.teams add column if not exists slug text;
create table public.team_classes (
  team_id uuid not null references public.teams(id) on delete cascade,
  class_id uuid not null unique references public.classes(id) on delete cascade,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  primary key(team_id,class_id)
);
alter table public.team_classes enable row level security;
create policy "admins manage team class associations" on public.team_classes for all using(public.is_admin()) with check(public.is_admin());
grant select,insert,delete on public.team_classes to authenticated;

create function public.olient_slugify(p_value text)
returns text language sql immutable set search_path=public as $$
 select coalesce(nullif(trim(both '-' from regexp_replace(regexp_replace(translate(lower(trim(coalesce(p_value,''))),'áàâãäéèêëíìîïóòôõöúùûüçñ','aaaaaeeeeiiiiooooouuuucn'),'[º°ª]','','g'),'[^a-z0-9]+','-','g')),''),'equipe')
$$;
create function public.olient_normalize_name(p_value text)
returns text language sql immutable set search_path=public as $$
 select regexp_replace(regexp_replace(translate(lower(trim(coalesce(p_value,''))),'áàâãäéèêëíìîïóòôõöúùûüçñ','aaaaaeeeeiiiiooooouuuucn'),'[º°ª]','','g'),'\s+',' ','g')
$$;
do $$
declare duplicate_group record; keeper_id uuid;
begin
 for duplicate_group in
   select public.olient_normalize_name(name) as normalized_name
   from public.classes group by public.olient_normalize_name(name) having count(*)>1
 loop
   select id into keeper_id from public.classes
   where public.olient_normalize_name(name)=duplicate_group.normalized_name
   order by active desc,created_at,id limit 1;
   update public.students set class_id=keeper_id,updated_at=now()
   where class_id in(select id from public.classes where public.olient_normalize_name(name)=duplicate_group.normalized_name and id<>keeper_id);
   delete from public.classes
   where public.olient_normalize_name(name)=duplicate_group.normalized_name and id<>keeper_id;
 end loop;
end $$;
create unique index if not exists classes_normalized_name_unique_idx on public.classes(public.olient_normalize_name(name));

do $$ declare r record; base_slug text; chosen_slug text; n integer; begin
 for r in select id,name from public.teams order by name,id loop
   base_slug:=public.olient_slugify(r.name); chosen_slug:=base_slug; n:=2;
   while exists(select 1 from public.teams x where x.slug=chosen_slug and x.id<>r.id) loop chosen_slug:=base_slug||'-'||n::text; n:=n+1; end loop;
   update public.teams set slug=chosen_slug where id=r.id;
 end loop;
end $$;
alter table public.teams alter column slug set not null;
create unique index teams_slug_unique_idx on public.teams(slug);

create table public.team_access_links (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null unique references public.teams(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  edits_locked boolean not null default false,
  require_shirt_number boolean not null default true,
  shirt_number_min integer not null default 0,
  shirt_number_max integer not null default 99,
  unique_shirt_number boolean not null default false,
  last_used_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check(shirt_number_min >= 0 and shirt_number_max <= 999 and shirt_number_min <= shirt_number_max)
);

create table public.team_sports (
  team_id uuid not null references public.teams(id) on delete cascade,
  sport_id uuid not null references public.sports(id) on delete cascade,
  enabled boolean not null default true,
  lock_approved boolean not null default true,
  category text,
  updated_by uuid not null references public.profiles(id),
  updated_at timestamptz not null default now(),
  primary key(team_id,sport_id)
);

-- Ensure the official OLIENT 2027 modalities exist. Existing rules and categories
-- are preserved; only the requested active flags are enforced for these names.
do $$
declare sport_name text;
begin
 foreach sport_name in array array['FUTSAL','HANDEBOL','BASQUETE 3X3','VOLEIBOL','QUEIMADA','TÊNIS DE MESA','FUTMESA','VÔLEI DE MESA'] loop
   if exists(select 1 from public.sports where public.olient_normalize_name(name)=public.olient_normalize_name(sport_name)) then
     update public.sports set active=true,status='active',updated_at=now()
     where public.olient_normalize_name(name)=public.olient_normalize_name(sport_name);
   else
     insert into public.sports(name,status,active) values(sport_name,'active',true);
   end if;
 end loop;
end $$;

create table public.team_student_details (
  team_id uuid not null references public.teams(id) on delete cascade,
  student_id uuid not null references public.students(id),
  shirt_name text,
  shirt_number integer,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz,
  primary key(team_id,student_id),
  check(shirt_name is null or (length(trim(shirt_name)) between 1 and 30 and shirt_name !~ '[[:cntrl:]]')),
  check(shirt_number is null or shirt_number between 0 and 999)
);

create table public.team_student_sports (
  team_id uuid not null,
  student_id uuid not null,
  sport_id uuid not null,
  status text not null default 'pending' check(status in ('pending','approved','correction_requested','rejected','withdrawn')),
  review_note text,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now(),
  primary key(team_id,student_id,sport_id),
  foreign key(team_id,sport_id) references public.team_sports(team_id,sport_id) on delete cascade,
  foreign key(student_id) references public.students(id),
  check(status <> 'correction_requested' or length(trim(coalesce(review_note,''))) >= 3)
);

create table public.team_access_events (
  id bigint generated always as identity primary key,
  team_id uuid not null references public.teams(id) on delete cascade,
  student_id uuid references public.students(id),
  sport_id uuid references public.sports(id),
  actor_id uuid references public.profiles(id),
  link_id uuid references public.team_access_links(id) on delete set null,
  action text not null,
  old_data jsonb,
  new_data jsonb,
  created_at timestamptz not null default now()
);

create table public.team_access_requests (
  id bigint generated always as identity primary key,
  link_id uuid not null references public.team_access_links(id) on delete cascade,
  student_id uuid references public.students(id),
  action text not null check(action in ('exchange','read','save')),
  created_at timestamptz not null default now()
);
create index team_access_requests_window_idx on public.team_access_requests(link_id,action,created_at desc);

create table public.team_access_sessions (
  id uuid primary key default gen_random_uuid(),
  link_id uuid not null references public.team_access_links(id) on delete cascade,
  session_hash text not null unique,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  last_used_at timestamptz,
  created_at timestamptz not null default now()
);
create index team_access_sessions_link_idx on public.team_access_sessions(link_id,created_at desc) where revoked_at is null;
alter table public.team_access_events add column session_id uuid references public.team_access_sessions(id) on delete set null;

alter table public.team_access_links enable row level security;
alter table public.team_sports enable row level security;
alter table public.team_student_details enable row level security;
alter table public.team_student_sports enable row level security;
alter table public.team_access_events enable row level security;
alter table public.team_access_requests enable row level security;
alter table public.team_access_sessions enable row level security;

create policy "admins read team access links" on public.team_access_links for select using(public.is_admin());
create policy "admins manage enabled team sports" on public.team_sports for all using(public.is_admin()) with check(public.is_admin());
create policy "admins read participant details" on public.team_student_details for select using(public.is_admin());
create policy "admins manage participant modalities" on public.team_student_sports for all using(public.is_admin()) with check(public.is_admin());
create policy "admins read team access history" on public.team_access_events for select using(public.is_admin());
grant select on public.team_access_links,public.team_sports,public.team_student_details,public.team_student_sports,public.team_access_events to authenticated;
grant insert,update on public.team_sports to authenticated;

create function public.create_team_with_slug(p_name text,p_color text default null)
returns uuid language plpgsql security definer set search_path=public set row_security=off as $$
declare v_name text; v_base text; v_slug text; v_n integer:=2; v_id uuid;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 v_name:=trim(coalesce(p_name,''));
 if length(v_name) not between 1 and 80 then raise exception 'Team name must be between 1 and 80 characters'; end if;
 v_base:=public.olient_slugify(v_name); perform pg_advisory_xact_lock(hashtext(v_base)); v_slug:=v_base;
 while exists(select 1 from public.teams where slug=v_slug) loop v_slug:=v_base||'-'||v_n::text; v_n:=v_n+1; end loop;
 insert into public.teams(name,slug,color) values(v_name,v_slug,nullif(trim(coalesce(p_color,'')),'')) returning id into v_id;
 return v_id;
end $$;
revoke all on function public.create_team_with_slug(text,text) from public;
grant execute on function public.create_team_with_slug(text,text) to authenticated;

create function public.admin_create_class_group(p_name text,p_grade text default null,p_shift text default null)
returns jsonb language plpgsql security definer set search_path=public set row_security=off as $$
declare v_name text; v_class uuid; v_team uuid;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 v_name:=trim(coalesce(p_name,'')); if length(v_name) not between 1 and 80 then raise exception 'Class name must be between 1 and 80 characters'; end if;
 select id into v_class from public.classes where public.olient_normalize_name(name)=public.olient_normalize_name(v_name) and active;
 if v_class is not null then raise exception 'Class already exists'; end if;
 insert into public.classes(name,grade,shift) values(v_name,nullif(trim(coalesce(p_grade,'')),''),nullif(trim(coalesce(p_shift,'')),'')) returning id into v_class;
 select id into v_team from public.teams where name=v_name and active and deleted_at is null;
 if v_team is null then v_team:=public.create_team_with_slug(v_name,null); end if;
 insert into public.team_classes(team_id,class_id,created_by) values(v_team,v_class,auth.uid());
 insert into public.team_access_events(team_id,actor_id,action,new_data) values(v_team,auth.uid(),'class_group_created',jsonb_build_object('class_id',v_class,'class_name',v_name));
 return jsonb_build_object('class_id',v_class,'team_id',v_team);
end $$;
revoke all on function public.admin_create_class_group(text,text,text) from public;
grant execute on function public.admin_create_class_group(text,text,text) to authenticated;

create function public.admin_import_roster(p_rows jsonb,p_create_missing_classes boolean default true)
returns jsonb language plpgsql security definer set search_path=public set row_security=off as $$
declare r jsonb; v_class_id uuid; v_team_id uuid; v_student_id uuid; v_first text; v_last text; v_full text; v_class_name text; v_action text; v_matches integer; v_created_students integer:=0; v_reused_students integer:=0; v_linked integer:=0; v_created_classes integer:=0; v_created_teams integer:=0; v_skipped integer:=0; v_seen text[]:='{}'; v_key text; v_base text;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if jsonb_typeof(p_rows)<>'array' or jsonb_array_length(p_rows)>5000 then raise exception 'Upload must contain at most 5000 valid rows'; end if;
 for r in select value from jsonb_array_elements(p_rows) loop
   v_action:=coalesce(r->>'action','');
   if v_action='skip' then v_skipped:=v_skipped+1; continue; end if;
   if v_action not in ('create','reuse') then raise exception 'Each imported row needs an explicit create/reuse/skip decision'; end if;
   v_class_name:=trim(coalesce(r->>'class_name','')); v_full:=regexp_replace(trim(coalesce(r->>'full_name','')),'\s+',' ','g');
   if v_class_name='' or v_full='' or length(v_full)>240 or v_full~'[[:cntrl:]]' then raise exception 'Invalid class or student name in import'; end if;
   if nullif(r->>'class_id','') is not null then
     begin v_class_id:=(r->>'class_id')::uuid; exception when others then raise exception 'Invalid class selected for import'; end;
     if not exists(select 1 from public.classes where id=v_class_id and active) then raise exception 'Selected class is not active'; end if;
   else
     select count(*) into v_matches from public.classes where public.olient_normalize_name(name)=public.olient_normalize_name(v_class_name);
     if v_matches>0 then
       select id into v_class_id from public.classes
       where active and public.olient_normalize_name(name)=public.olient_normalize_name(v_class_name)
       order by created_at,id limit 1;
       if v_class_id is null then raise exception 'Class exists but is inactive: %',v_class_name; end if;
     end if;
     if v_matches=0 then
       if not p_create_missing_classes then raise exception 'Class does not exist: %',v_class_name; end if;
       insert into public.classes(name) values(v_class_name) on conflict ((public.olient_normalize_name(name))) do nothing returning id into v_class_id;
       if v_class_id is null then
         select id into v_class_id from public.classes where public.olient_normalize_name(name)=public.olient_normalize_name(v_class_name) and active;
       else
         v_created_classes:=v_created_classes+1;
       end if;
     end if;
   end if;
   select name into v_class_name from public.classes where id=v_class_id;
   v_key:=v_class_id::text||':'||public.olient_normalize_name(v_full);
   if v_key=any(v_seen) then v_skipped:=v_skipped+1; continue; end if;
   v_seen:=array_append(v_seen,v_key);
   v_first:=split_part(v_full,' ',1); v_last:=trim(substr(v_full,length(v_first)+1));
   if v_action='reuse' then
     begin v_student_id:=(r->>'student_id')::uuid; exception when others then raise exception 'Choose an existing student to reuse'; end;
     if not exists(select 1 from public.students s where s.id=v_student_id and s.class_id=v_class_id and s.active and s.deleted_at is null and public.olient_normalize_name(concat_ws(' ',s.first_name,s.last_name))=public.olient_normalize_name(v_full)) then raise exception 'Existing student does not match the selected name and class'; end if;
     v_reused_students:=v_reused_students+1;
   else
     select count(*) into v_matches from public.students s where s.class_id=v_class_id and s.deleted_at is null and public.olient_normalize_name(concat_ws(' ',s.first_name,s.last_name))=public.olient_normalize_name(v_full);
     if v_matches>0 and coalesce((r->>'allow_homonym')::boolean,false)=false then raise exception 'Student name became ambiguous in the selected class: %',v_full; end if;
     insert into public.students(class_id,first_name,last_name) values(v_class_id,v_first,v_last) returning id into v_student_id;
     v_created_students:=v_created_students+1;
   end if;
   perform pg_advisory_xact_lock(hashtext(v_class_id::text));
   select tc.team_id into v_team_id from public.team_classes tc where tc.class_id=v_class_id;
   if v_team_id is null then
     select id into v_team_id from public.teams where public.olient_normalize_name(name)=public.olient_normalize_name(v_class_name) and active and deleted_at is null order by created_at limit 1;
     if v_team_id is null then v_team_id:=public.create_team_with_slug(v_class_name,null); v_created_teams:=v_created_teams+1; end if;
     insert into public.team_classes(team_id,class_id,created_by) values(v_team_id,v_class_id,auth.uid()) on conflict(class_id) do nothing;
   end if;
   perform pg_advisory_xact_lock(hashtext(v_team_id::text||':'||v_student_id::text));
   if not exists(select 1 from public.team_students where team_id=v_team_id and student_id=v_student_id and left_at is null) then
     if exists(select 1 from public.team_students where team_id=v_team_id and student_id=v_student_id and joined_at=current_date) then
       update public.team_students set left_at=null where id=(select id from public.team_students where team_id=v_team_id and student_id=v_student_id order by joined_at desc limit 1);
     else insert into public.team_students(team_id,student_id) values(v_team_id,v_student_id); end if;
     v_linked:=v_linked+1;
   end if;
 end loop;
 insert into public.audit_logs(actor_id,action,table_name,new_data) values(auth.uid(),'roster_import','students',jsonb_build_object('created_students',v_created_students,'reused_students',v_reused_students,'linked',v_linked,'created_classes',v_created_classes,'created_teams',v_created_teams,'skipped',v_skipped));
 return jsonb_build_object('created_students',v_created_students,'reused_students',v_reused_students,'linked',v_linked,'created_classes',v_created_classes,'created_teams',v_created_teams,'skipped',v_skipped);
end $$;
revoke all on function public.admin_import_roster(jsonb,boolean) from public;
grant execute on function public.admin_import_roster(jsonb,boolean) to authenticated;

create function public.issue_team_access_link(p_team_id uuid,p_expires_at timestamptz,p_require_number boolean default true,p_number_min integer default 0,p_number_max integer default 99,p_unique_number boolean default false)
returns text language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_token text; v_link_id uuid;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null) then raise exception 'Active team not found'; end if;
 if p_expires_at is null or p_expires_at<=now() then raise exception 'Set an expiration date in the future'; end if;
 if p_number_min<0 or p_number_max>999 or p_number_min>p_number_max then raise exception 'Invalid shirt number range'; end if;
 v_token:=encode(gen_random_bytes(32),'hex');
 insert into public.team_access_links(team_id,token_hash,expires_at,revoked_at,edits_locked,require_shirt_number,shirt_number_min,shirt_number_max,unique_shirt_number,created_by)
 values(p_team_id,encode(digest(v_token,'sha256'),'hex'),p_expires_at,null,false,p_require_number,p_number_min,p_number_max,p_unique_number,auth.uid())
 on conflict(team_id) do update set token_hash=excluded.token_hash,expires_at=excluded.expires_at,revoked_at=null,edits_locked=false,require_shirt_number=excluded.require_shirt_number,shirt_number_min=excluded.shirt_number_min,shirt_number_max=excluded.shirt_number_max,unique_shirt_number=excluded.unique_shirt_number,created_by=auth.uid(),updated_at=now()
 returning id into v_link_id;
 update public.team_access_sessions set revoked_at=now() where link_id=v_link_id and revoked_at is null;
 insert into public.team_access_events(team_id,actor_id,link_id,action,new_data) values(p_team_id,auth.uid(),v_link_id,'link_issued',jsonb_build_object('expires_at',p_expires_at,'require_shirt_number',p_require_number,'shirt_number_min',p_number_min,'shirt_number_max',p_number_max,'unique_shirt_number',p_unique_number));
 return v_token;
end $$;
revoke all on function public.issue_team_access_link(uuid,timestamptz,boolean,integer,integer,boolean) from public;
grant execute on function public.issue_team_access_link(uuid,timestamptz,boolean,integer,integer,boolean) to authenticated;

create function public.admin_set_team_link(p_team_id uuid,p_expires_at timestamptz,p_locked boolean,p_require_number boolean,p_number_min integer,p_number_max integer,p_unique_number boolean)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_link public.team_access_links;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if p_expires_at is null or p_expires_at<=now() then raise exception 'Set an expiration date in the future'; end if;
 if p_number_min<0 or p_number_max>999 or p_number_min>p_number_max then raise exception 'Invalid shirt number range'; end if;
 select * into v_link from public.team_access_links where team_id=p_team_id for update;
 if not found then raise exception 'Issue an access link first'; end if;
 update public.team_access_links set expires_at=p_expires_at,edits_locked=p_locked,require_shirt_number=p_require_number,shirt_number_min=p_number_min,shirt_number_max=p_number_max,unique_shirt_number=p_unique_number,updated_at=now() where id=v_link.id;
 insert into public.team_access_events(team_id,actor_id,link_id,action,old_data,new_data) values(p_team_id,auth.uid(),v_link.id,'link_settings_changed',jsonb_build_object('expires_at',v_link.expires_at,'edits_locked',v_link.edits_locked),jsonb_build_object('expires_at',p_expires_at,'edits_locked',p_locked,'require_shirt_number',p_require_number,'shirt_number_min',p_number_min,'shirt_number_max',p_number_max,'unique_shirt_number',p_unique_number));
end $$;
revoke all on function public.admin_set_team_link(uuid,timestamptz,boolean,boolean,integer,integer,boolean) from public;
grant execute on function public.admin_set_team_link(uuid,timestamptz,boolean,boolean,integer,integer,boolean) to authenticated;

create function public.revoke_team_access_link(p_team_id uuid)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_link_id uuid;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 update public.team_access_links set revoked_at=now(),updated_at=now() where team_id=p_team_id returning id into v_link_id;
 if v_link_id is null then raise exception 'Access link not found'; end if;
 update public.team_access_sessions set revoked_at=now() where link_id=v_link_id and revoked_at is null;
 insert into public.team_access_events(team_id,actor_id,link_id,action) values(p_team_id,auth.uid(),v_link_id,'link_revoked');
end $$;
revoke all on function public.revoke_team_access_link(uuid) from public;
grant execute on function public.revoke_team_access_link(uuid) to authenticated;

create function public.admin_team_access_overview()
returns table(team_id uuid,expires_at timestamptz,revoked_at timestamptz,edits_locked boolean,require_shirt_number boolean,shirt_number_min integer,shirt_number_max integer,unique_shirt_number boolean,last_used_at timestamptz,created_at timestamptz)
language sql stable security definer set search_path=public set row_security=off as $$
 select l.team_id,l.expires_at,l.revoked_at,l.edits_locked,l.require_shirt_number,l.shirt_number_min,l.shirt_number_max,l.unique_shirt_number,l.last_used_at,l.created_at from public.team_access_links l where public.is_admin()
$$;
revoke all on function public.admin_team_access_overview() from public;
grant execute on function public.admin_team_access_overview() to authenticated;

create function public.admin_set_team_sports(p_team_id uuid,p_sport_ids uuid[],p_locked_sport_ids uuid[])
returns void language plpgsql security definer set search_path=public set row_security=off as $$
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null) then raise exception 'Active team not found'; end if;
 if p_sport_ids is null then p_sport_ids:='{}'::uuid[]; end if;
 if p_locked_sport_ids is null then p_locked_sport_ids:='{}'::uuid[]; end if;
 if cardinality(p_sport_ids)<>(select count(distinct x) from unnest(p_sport_ids) x) then raise exception 'Duplicate sport selection'; end if;
 if exists(select 1 from unnest(p_locked_sport_ids) u(id) where not(u.id=any(p_sport_ids))) then raise exception 'Lock rules can only be set for enabled team sports'; end if;
 if exists(select 1 from unnest(p_sport_ids) u(id) left join public.sports sp on sp.id=u.id and sp.active where sp.id is null) then raise exception 'Unknown or inactive sport'; end if;
 update public.team_sports set enabled=false,updated_by=auth.uid(),updated_at=now() where team_id=p_team_id and not(sport_id=any(p_sport_ids));
 insert into public.team_sports(team_id,sport_id,enabled,lock_approved,updated_by) select p_team_id,x,true,x=any(p_locked_sport_ids),auth.uid() from unnest(p_sport_ids) x
 on conflict(team_id,sport_id) do update set enabled=true,lock_approved=excluded.lock_approved,updated_by=auth.uid(),updated_at=now();
 insert into public.team_access_events(team_id,actor_id,action,new_data) values(p_team_id,auth.uid(),'team_sports_changed',jsonb_build_object('sport_ids',p_sport_ids,'locked_sport_ids',p_locked_sport_ids));
end $$;
revoke all on function public.admin_set_team_sports(uuid,uuid[],uuid[]) from public;
grant execute on function public.admin_set_team_sports(uuid,uuid[],uuid[]) to authenticated;

create function public.admin_save_team_student_info(p_team_id uuid,p_student_id uuid,p_shirt_name text,p_shirt_number integer,p_sport_ids uuid[])
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare l public.team_access_links; v_sport_id uuid; v_sport public.sports; v_limit integer; v_old jsonb; v_new jsonb;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null)
   or not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=p_team_id and ts.student_id=p_student_id and ts.left_at is null) then
   raise exception 'Student is not an active member of this team';
 end if;
 select * into l from public.team_access_links where team_id=p_team_id;
 if length(trim(coalesce(p_shirt_name,''))) not between 1 and 30 or p_shirt_name ~ '[[:cntrl:]]' then raise exception 'Shirt name must contain 1 to 30 valid characters'; end if;
 if coalesce(l.require_shirt_number,true) and p_shirt_number is null then raise exception 'Shirt number is required'; end if;
 if p_shirt_number is not null and p_shirt_number not between coalesce(l.shirt_number_min,0) and coalesce(l.shirt_number_max,99) then raise exception 'Shirt number is outside the configured range'; end if;
 if coalesce(l.unique_shirt_number,false) and p_shirt_number is not null and exists(select 1 from public.team_student_details d where d.team_id=p_team_id and d.student_id<>p_student_id and d.shirt_number=p_shirt_number) then raise exception 'Shirt number is already used by another team member'; end if;
 if p_sport_ids is null then p_sport_ids:='{}'::uuid[]; end if;
 if cardinality(p_sport_ids)<>(select count(distinct x) from unnest(p_sport_ids) x) then raise exception 'Duplicate sport selection'; end if;
 if exists(select 1 from unnest(p_sport_ids) u(id) left join public.team_sports ts on ts.team_id=p_team_id and ts.sport_id=u.id and ts.enabled left join public.sports sp on sp.id=u.id and sp.active where ts.sport_id is null or sp.id is null) then raise exception 'A selected sport is not enabled for this team'; end if;
 perform pg_advisory_xact_lock(hashtext(p_team_id::text||':'||p_student_id::text));
 for v_sport_id in select unnest(p_sport_ids) loop
   select * into v_sport from public.sports where id=v_sport_id;
   v_limit:=case when v_sport.rules->>'max_modalities_per_student' ~ '^[0-9]+$' then (v_sport.rules->>'max_modalities_per_student')::integer else null end;
   if v_limit is not null and cardinality(p_sport_ids)>v_limit then raise exception 'Selected sports exceed the participant limit'; end if;
 end loop;
 select jsonb_build_object('shirt_name',d.shirt_name,'shirt_number',d.shirt_number,'sports',coalesce((select jsonb_agg(jsonb_build_object('sport_id',ss.sport_id,'status',ss.status) order by ss.sport_id) from public.team_student_sports ss where ss.team_id=p_team_id and ss.student_id=p_student_id),'[]'::jsonb)) into v_old from public.team_student_details d where d.team_id=p_team_id and d.student_id=p_student_id;
 insert into public.team_student_details(team_id,student_id,shirt_name,shirt_number,updated_by,updated_at) values(p_team_id,p_student_id,trim(p_shirt_name),p_shirt_number,auth.uid(),now()) on conflict(team_id,student_id) do update set shirt_name=excluded.shirt_name,shirt_number=excluded.shirt_number,updated_by=auth.uid(),updated_at=now();
 update public.team_student_sports set status='withdrawn',review_note=null,updated_by=auth.uid(),updated_at=now() where team_id=p_team_id and student_id=p_student_id and status<>'withdrawn' and not(sport_id=any(p_sport_ids));
 foreach v_sport_id in array p_sport_ids loop
   insert into public.team_student_sports(team_id,student_id,sport_id,status,review_note,updated_by,updated_at) values(p_team_id,p_student_id,v_sport_id,'pending',null,auth.uid(),now()) on conflict(team_id,student_id,sport_id) do update set status=case when team_student_sports.status='approved' then 'approved' else 'pending' end,review_note=null,updated_by=auth.uid(),updated_at=now();
 end loop;
 select jsonb_build_object('shirt_name',d.shirt_name,'shirt_number',d.shirt_number,'sports',coalesce((select jsonb_agg(jsonb_build_object('sport_id',ss.sport_id,'status',ss.status) order by ss.sport_id) from public.team_student_sports ss where ss.team_id=p_team_id and ss.student_id=p_student_id),'[]'::jsonb)) into v_new from public.team_student_details d where d.team_id=p_team_id and d.student_id=p_student_id;
 insert into public.team_access_events(team_id,student_id,actor_id,action,old_data,new_data) values(p_team_id,p_student_id,auth.uid(),'admin_student_info_saved',v_old,v_new);
 return jsonb_build_object('ok',true);
end $$;
revoke all on function public.admin_save_team_student_info(uuid,uuid,text,integer,uuid[]) from public;
grant execute on function public.admin_save_team_student_info(uuid,uuid,text,integer,uuid[]) to authenticated;

create function public.admin_link_student_to_team(p_team_id uuid,p_student_id uuid,p_link boolean)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if p_link then
   if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null) or not exists(select 1 from public.students s join public.classes c on c.id=s.class_id and c.active where s.id=p_student_id and s.active and s.deleted_at is null) then raise exception 'Select an active team and student with an active class'; end if;
   perform pg_advisory_xact_lock(hashtext(p_team_id::text||':'||p_student_id::text));
   if not exists(select 1 from public.team_students where team_id=p_team_id and student_id=p_student_id and left_at is null) then
     if exists(select 1 from public.team_students where team_id=p_team_id and student_id=p_student_id and joined_at=current_date) then
       update public.team_students set left_at=null where id=(select id from public.team_students where team_id=p_team_id and student_id=p_student_id order by joined_at desc limit 1);
     else insert into public.team_students(team_id,student_id) values(p_team_id,p_student_id); end if;
   end if;
 else
   update public.team_students set left_at=current_date where team_id=p_team_id and student_id=p_student_id and left_at is null;
   update public.team_student_sports set status='withdrawn',review_note=null,updated_by=auth.uid(),updated_at=now() where team_id=p_team_id and student_id=p_student_id and status in ('pending','correction_requested','rejected');
 end if;
 insert into public.team_access_events(team_id,student_id,actor_id,action) values(p_team_id,p_student_id,auth.uid(),case when p_link then 'student_linked' else 'student_unlinked' end);
end $$;
revoke all on function public.admin_link_student_to_team(uuid,uuid,boolean) from public;
grant execute on function public.admin_link_student_to_team(uuid,uuid,boolean) to authenticated;

create function public.team_access_rate_limit(p_link_id uuid,p_student_id uuid,p_action text)
returns boolean language plpgsql security definer set search_path=public set row_security=off as $$
declare v_total integer; v_student integer; v_limit integer; v_window interval;
begin
 perform pg_advisory_xact_lock(hashtext(p_link_id::text));
 delete from public.team_access_requests where created_at<now()-interval '2 hours';
 if p_action='exchange' then v_window:=interval '5 minutes';v_limit:=12; else v_window:=interval '1 minute';v_limit:=case when p_action='read' then 90 else 45 end; end if;
 select count(*) into v_total from public.team_access_requests where link_id=p_link_id and action=p_action and created_at>now()-v_window;
 if v_total>=v_limit then return false; end if;
 if p_action='save' and p_student_id is not null then
   select count(*) into v_student from public.team_access_requests where link_id=p_link_id and student_id=p_student_id and action='save' and created_at>now()-interval '1 minute';
   if v_student>=8 then return false; end if;
 end if;
 insert into public.team_access_requests(link_id,student_id,action) values(p_link_id,p_student_id,p_action);
 return true;
end $$;
revoke all on function public.team_access_rate_limit(uuid,uuid,text) from public;

create function public.start_team_access_session(p_slug text,p_share_secret text)
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_team_id uuid; v_link public.team_access_links; v_session text; v_session_id uuid;
begin
 if p_slug is null or p_share_secret is null or length(p_share_secret)<>64 or p_share_secret!~'^[0-9a-f]{64}$' then return jsonb_build_object('error','link_unavailable'); end if;
 select id into v_team_id from public.teams where slug=p_slug and active and deleted_at is null;
 if v_team_id is null then return jsonb_build_object('error','link_unavailable'); end if;
 select * into v_link from public.team_access_links where team_id=v_team_id and token_hash=encode(digest(p_share_secret,'sha256'),'hex') and revoked_at is null and expires_at>now();
 if not found then return jsonb_build_object('error','link_unavailable'); end if;
 if not public.team_access_rate_limit(v_link.id,null,'exchange') then return jsonb_build_object('error','rate_limited'); end if;
 v_session:=encode(gen_random_bytes(32),'hex');
 insert into public.team_access_sessions(link_id,session_hash,expires_at) values(v_link.id,encode(digest(v_session,'sha256'),'hex'),now()+interval '4 hours') returning id into v_session_id;
 update public.team_access_links set last_used_at=now() where id=v_link.id;
 update public.team_access_sessions set revoked_at=now() where id in(select id from public.team_access_sessions where link_id=v_link.id and revoked_at is null and id<>v_session_id order by created_at desc offset 50);
 return jsonb_build_object('session_token',v_session,'expires_at',now()+interval '4 hours');
end $$;
revoke all on function public.start_team_access_session(text,text) from public;
grant execute on function public.start_team_access_session(text,text) to anon,authenticated;

create function public.validate_team_access_session(p_session_token text)
returns public.team_access_sessions language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions;
begin
 if p_session_token is null or length(p_session_token)<>64 or p_session_token!~'^[0-9a-f]{64}$' then return null; end if;
 select s.* into v_session from public.team_access_sessions s join public.team_access_links l on l.id=s.link_id where s.session_hash=encode(digest(p_session_token,'sha256'),'hex') and s.revoked_at is null and s.expires_at>now() and l.revoked_at is null and l.expires_at>now();
 if not found then return null; end if;
 update public.team_access_sessions set last_used_at=now() where id=v_session.id;
 return v_session;
end $$;
revoke all on function public.validate_team_access_session(text) from public;

create function public.get_team_access_page(p_session_token text)
returns jsonb language plpgsql security definer set search_path=public set row_security=off as $$
declare l public.team_access_links; v_session public.team_access_sessions; t public.teams; result jsonb; v_total integer; v_complete integer;
begin
 v_session:=public.validate_team_access_session(p_session_token);
 if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
 select * into l from public.team_access_links where id=v_session.link_id;
 if not found then return jsonb_build_object('error','link_unavailable'); end if;
 if not public.team_access_rate_limit(l.id,null,'read') then return jsonb_build_object('error','rate_limited'); end if;
 update public.team_access_links set last_used_at=now() where id=l.id;
 select * into t from public.teams where id=l.team_id and active and deleted_at is null;
 if not found then return jsonb_build_object('error','link_unavailable'); end if;
 select count(distinct s.id) into v_total from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=t.id and ts.left_at is null;
 select count(distinct s.id) into v_complete from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null join public.team_student_details d on d.team_id=ts.team_id and d.student_id=ts.student_id
 where ts.team_id=t.id and ts.left_at is null and nullif(trim(d.shirt_name),'') is not null and (not l.require_shirt_number or d.shirt_number is not null) and exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status in ('pending','approved','correction_requested'));
 select jsonb_build_object(
   'team',jsonb_build_object('name',t.name,'color',t.color,'logo_path',t.logo_path),
   'locked',l.edits_locked,'expires_at',l.expires_at,
   'number_rules',jsonb_build_object('required',l.require_shirt_number,'min',l.shirt_number_min,'max',l.shirt_number_max,'unique',l.unique_shirt_number),
   'progress',jsonb_build_object('complete',v_complete,'total',v_total),
   'sports',coalesce((select jsonb_agg(jsonb_build_object('id',sp.id,'name',sp.name,'category',coalesce(ts.category,sp.category),'lock_approved',ts.lock_approved) order by sp.name) from public.team_sports ts join public.sports sp on sp.id=ts.sport_id and sp.active where ts.team_id=t.id and ts.enabled),'[]'::jsonb),
     'students',coalesce((select jsonb_agg(jsonb_build_object(
      'id',s.id,'first_name',s.first_name,'last_name',s.last_name,'class_name',c.name,
      'shirt_name',d.shirt_name,'shirt_number',d.shirt_number,
      'completion_status',case when d.shirt_name is null or l.require_shirt_number and d.shirt_number is null or not exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status in ('pending','approved','correction_requested')) then 'pending' when exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status='correction_requested') then 'correction_requested' when exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status='pending') then 'awaiting_approval' when not exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status in ('pending','correction_requested')) and exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status='approved') then 'approved' else 'pending' end,
      'sports',coalesce((select jsonb_agg(jsonb_build_object('id',sp.id,'status',ss.status,'selected',ss.status in ('pending','approved','correction_requested'),'enabled',coalesce(ts.enabled,false),'name',sp.name,'review_note',ss.review_note) order by sp.name) from public.team_student_sports ss join public.sports sp on sp.id=ss.sport_id left join public.team_sports ts on ts.team_id=ss.team_id and ts.sport_id=ss.sport_id where ss.team_id=t.id and ss.student_id=s.id),'[]'::jsonb)
    ) order by c.name,s.last_name,s.first_name) from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null left join public.classes c on c.id=s.class_id where ts.team_id=t.id and ts.left_at is null),'[]'::jsonb)
 ) into result;
 return result;
end $$;
revoke all on function public.get_team_access_page(text) from public;
grant execute on function public.get_team_access_page(text) to anon,authenticated;

create function public.save_team_student_info(p_session_token text,p_student_id uuid,p_shirt_name text,p_shirt_number integer,p_sport_ids uuid[])
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare l public.team_access_links; v_session public.team_access_sessions; v_team public.teams; v_sport_id uuid; v_sport public.sports; v_limit integer; v_old jsonb; v_new jsonb;
begin
 v_session:=public.validate_team_access_session(p_session_token);
 if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
 select * into l from public.team_access_links where id=v_session.link_id;
 if not found then return jsonb_build_object('error','link_unavailable'); end if;
 if l.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
 if not public.team_access_rate_limit(l.id,p_student_id,'save') then return jsonb_build_object('error','rate_limited'); end if;
 select * into v_team from public.teams where id=l.team_id and active and deleted_at is null;
 if not found or not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=l.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
 if length(trim(coalesce(p_shirt_name,''))) not between 1 and 30 or p_shirt_name ~ '[[:cntrl:]]' then return jsonb_build_object('error','invalid_shirt_name'); end if;
 if l.require_shirt_number and p_shirt_number is null then return jsonb_build_object('error','shirt_number_required'); end if;
 if p_shirt_number is not null and p_shirt_number not between l.shirt_number_min and l.shirt_number_max then return jsonb_build_object('error','invalid_shirt_number'); end if;
 perform pg_advisory_xact_lock(hashtext(l.team_id::text));
 if p_sport_ids is null then p_sport_ids:='{}'::uuid[]; end if;
 if cardinality(p_sport_ids)<>(select count(distinct x) from unnest(p_sport_ids) x) then return jsonb_build_object('error','duplicate_sports'); end if;
 if exists(select 1 from unnest(p_sport_ids) u(id) left join public.team_sports ts on ts.team_id=l.team_id and ts.sport_id=u.id and ts.enabled left join public.sports sp on sp.id=u.id and sp.active where (ts.sport_id is null or sp.id is null) and not exists(select 1 from public.team_student_sports old where old.team_id=l.team_id and old.student_id=p_student_id and old.sport_id=u.id and old.status in ('pending','approved','correction_requested'))) then return jsonb_build_object('error','sport_unavailable'); end if;
 if l.unique_shirt_number and p_shirt_number is not null and exists(select 1 from public.team_student_details d where d.team_id=l.team_id and d.student_id<>p_student_id and d.shirt_number=p_shirt_number) then return jsonb_build_object('error','duplicate_shirt_number'); end if;
 for v_sport_id in select unnest(p_sport_ids) loop
   if exists(select 1 from public.team_student_sports old where old.team_id=l.team_id and old.student_id=p_student_id and old.sport_id=v_sport_id and old.status in ('pending','approved','correction_requested')) and not exists(select 1 from public.team_sports ts join public.sports sp on sp.id=ts.sport_id and sp.active where ts.team_id=l.team_id and ts.sport_id=v_sport_id and ts.enabled) then continue; end if;
   select sp.* into v_sport from public.sports sp join public.team_sports ts on ts.sport_id=sp.id and ts.team_id=l.team_id and ts.enabled where sp.id=v_sport_id and sp.active;
   v_limit:=case when v_sport.rules->>'max_modalities_per_student' ~ '^[0-9]+$' then (v_sport.rules->>'max_modalities_per_student')::integer else null end;
   if v_limit is not null and cardinality(p_sport_ids)>v_limit then return jsonb_build_object('error','modality_limit'); end if;
 end loop;
 if exists(select 1 from public.team_student_sports ss join public.team_sports ts on ts.team_id=ss.team_id and ts.sport_id=ss.sport_id where ss.team_id=l.team_id and ss.student_id=p_student_id and ss.status='approved' and ts.lock_approved and not(ss.sport_id=any(p_sport_ids))) then return jsonb_build_object('error','approved_sports_locked'); end if;
 select jsonb_build_object('shirt_name',d.shirt_name,'shirt_number',d.shirt_number,'sports',coalesce((select jsonb_agg(jsonb_build_object('sport_id',ss.sport_id,'status',ss.status) order by ss.sport_id) from public.team_student_sports ss where ss.team_id=l.team_id and ss.student_id=p_student_id),'[]'::jsonb)) into v_old from public.team_student_details d where d.team_id=l.team_id and d.student_id=p_student_id;
 insert into public.team_student_details(team_id,student_id,shirt_name,shirt_number,updated_at) values(l.team_id,p_student_id,trim(p_shirt_name),p_shirt_number,now()) on conflict(team_id,student_id) do update set shirt_name=excluded.shirt_name,shirt_number=excluded.shirt_number,updated_by=null,updated_at=now();
 update public.team_student_sports ss set status='withdrawn',review_note=null,updated_by=null,updated_at=now() where ss.team_id=l.team_id and ss.student_id=p_student_id and ss.status<>'withdrawn' and not(ss.sport_id=any(p_sport_ids)) and (ss.status<>'approved' or not exists(select 1 from public.team_sports ts where ts.team_id=ss.team_id and ts.sport_id=ss.sport_id and ts.lock_approved));
 foreach v_sport_id in array p_sport_ids loop
   insert into public.team_student_sports(team_id,student_id,sport_id,status,review_note,updated_by,updated_at) values(l.team_id,p_student_id,v_sport_id,'pending',null,null,now())
   on conflict(team_id,student_id,sport_id) do update set status=case when team_student_sports.status='approved' then 'approved' else 'pending' end,review_note=null,updated_by=null,updated_at=now();
 end loop;
 select jsonb_build_object('shirt_name',d.shirt_name,'shirt_number',d.shirt_number,'sports',coalesce((select jsonb_agg(jsonb_build_object('sport_id',ss.sport_id,'status',ss.status) order by ss.sport_id) from public.team_student_sports ss where ss.team_id=l.team_id and ss.student_id=p_student_id),'[]'::jsonb)) into v_new from public.team_student_details d where d.team_id=l.team_id and d.student_id=p_student_id;
 insert into public.team_access_events(team_id,student_id,link_id,session_id,action,old_data,new_data) values(l.team_id,p_student_id,l.id,v_session.id,'student_info_saved',v_old,v_new);
 return jsonb_build_object('ok',true,'message','Informações salvas com sucesso!');
end $$;
revoke all on function public.save_team_student_info(text,uuid,text,integer,uuid[]) from public;
grant execute on function public.save_team_student_info(text,uuid,text,integer,uuid[]) to anon,authenticated;

create function public.review_team_student_sport(p_team_id uuid,p_student_id uuid,p_sport_id uuid,p_decision text,p_note text default null)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_old text;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if p_decision not in ('approved','correction_requested','rejected') then raise exception 'Invalid decision'; end if;
 if p_decision in ('correction_requested','rejected') and length(trim(coalesce(p_note,'')))<3 then raise exception 'Provide a note for this decision'; end if;
 select status into v_old from public.team_student_sports where team_id=p_team_id and student_id=p_student_id and sport_id=p_sport_id for update;
 if not found or v_old not in ('pending','correction_requested') then raise exception 'Enrollment cannot be reviewed'; end if;
 update public.team_student_sports set status=p_decision,review_note=nullif(left(trim(coalesce(p_note,'')),1000),''),updated_by=auth.uid(),updated_at=now() where team_id=p_team_id and student_id=p_student_id and sport_id=p_sport_id;
 insert into public.team_access_events(team_id,student_id,sport_id,actor_id,action,old_data,new_data) values(p_team_id,p_student_id,p_sport_id,auth.uid(),'enrollment_reviewed',jsonb_build_object('status',v_old),jsonb_build_object('status',p_decision,'note',p_note));
end $$;
revoke all on function public.review_team_student_sport(uuid,uuid,uuid,text,text) from public;
grant execute on function public.review_team_student_sport(uuid,uuid,uuid,text,text) to authenticated;

