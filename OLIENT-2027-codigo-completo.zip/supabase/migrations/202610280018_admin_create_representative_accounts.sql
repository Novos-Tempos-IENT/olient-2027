-- Secure database half of direct student-representative account provisioning.
-- The Supabase Edge Function creates the Auth user with the service key and
-- calls this RPC only after validating an administrator/organizer session.

create or replace function public.admin_bind_team_representative_account(
  p_team_id uuid,
  p_slot smallint,
  p_student_id uuid,
  p_email text,
  p_user_id uuid,
  p_created_by uuid
) returns jsonb
language plpgsql security definer
set search_path=public,auth,extensions
set row_security=off
as $$
declare
  v_rep public.team_representatives;
  v_student public.students;
  v_email text:=lower(trim(coalesce(p_email,'')));
  v_old_user uuid;
  v_link public.team_access_links;
begin
  if coalesce(auth.role(),'')<>'service_role' then
    raise exception 'This operation is only available to the secured account provisioning service';
  end if;
  if p_slot not in (1,2) then raise exception 'O representante deve ocupar a vaga 1 ou 2'; end if;
  if v_email !~* '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$' then raise exception 'Informe um e-mail pessoal válido'; end if;
  if not exists(select 1 from auth.users u where u.id=p_user_id and lower(u.email)=v_email and u.email_confirmed_at is not null) then
    raise exception 'A conta autenticada não corresponde ao e-mail confirmado';
  end if;
  if not exists(select 1 from public.profiles p where p.id=p_created_by and p.active and p.role in ('administrator','organizer')) then
    raise exception 'A operação exige uma conta administrativa ativa';
  end if;
  if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null) then raise exception 'Turma/equipe ativa não encontrada'; end if;
  if not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id where ts.team_id=p_team_id and ts.student_id=p_student_id and ts.left_at is null and s.active and s.deleted_at is null) then
    raise exception 'O representante precisa ser aluno ativo desta turma';
  end if;

  perform pg_advisory_xact_lock(hashtext(p_team_id::text));
  select * into v_rep from public.team_representatives where team_id=p_team_id and slot=p_slot for update;
  if found and v_rep.active and v_rep.user_id is not null then raise exception 'Revogue a conta atual desta vaga antes de substituí-la'; end if;
  if exists(select 1 from public.team_representatives r where r.active and lower(r.email)=v_email and (r.team_id,r.slot) is distinct from (p_team_id,p_slot)) then
    raise exception 'Este e-mail já está vinculado a outro representante';
  end if;
  if exists(select 1 from public.team_representatives r where r.team_id=p_team_id and r.active and r.student_id=p_student_id and r.slot<>p_slot) then
    raise exception 'O mesmo aluno não pode ocupar as duas vagas de representante';
  end if;

  if v_rep.id is not null then
    v_old_user:=v_rep.user_id;
    update public.team_access_sessions set revoked_at=now() where representative_user_id=v_old_user and v_old_user is not null and revoked_at is null;
    update public.team_representative_invites set revoked_at=now() where representative_id=v_rep.id and revoked_at is null;
    update public.team_representatives
      set active=false,user_id=null,updated_at=now()
      where id=v_rep.id;
  end if;

  select * into v_link from public.team_access_links where team_id=p_team_id for update;
  if not found then
    insert into public.team_access_links(team_id,token_hash,expires_at,created_by)
    values(p_team_id,encode(digest(gen_random_bytes(32),'sha256'),'hex'),now()+interval '30 days',p_created_by);
  elsif v_link.revoked_at is not null or v_link.expires_at<=now() then
    update public.team_access_links set revoked_at=null,expires_at=now()+interval '30 days',updated_at=now() where id=v_link.id;
  end if;

  insert into public.profiles(id,display_name,role,active)
  select p_user_id,concat_ws(' ',s.first_name,s.last_name),'viewer',true
  from public.students s where s.id=p_student_id
  on conflict(id) do update set display_name=excluded.display_name,active=true
  where public.profiles.role='viewer';
  if not found then raise exception 'Não foi possível criar um perfil de representante sem privilégios'; end if;

  if v_rep.id is null then
    insert into public.team_representatives(team_id,slot,student_id,email,user_id,active,invited_at,accepted_at,created_by)
    values(p_team_id,p_slot,p_student_id,v_email,p_user_id,true,now(),now(),p_created_by);
  else
    update public.team_representatives set student_id=p_student_id,email=v_email,user_id=p_user_id,active=true,invited_at=now(),accepted_at=now(),created_by=p_created_by,updated_at=now()
    where id=v_rep.id;
  end if;

  insert into public.team_access_events(team_id,student_id,actor_id,action,new_data)
  values(p_team_id,p_student_id,p_created_by,'representative_account_created',jsonb_build_object('slot',p_slot,'email',v_email,'user_id',p_user_id));
  return jsonb_build_object('team_id',p_team_id,'student_id',p_student_id,'slot',p_slot,'email',v_email,'user_id',p_user_id);
end $$;
revoke all on function public.admin_bind_team_representative_account(uuid,smallint,uuid,text,uuid,uuid) from public,anon,authenticated;
grant execute on function public.admin_bind_team_representative_account(uuid,smallint,uuid,text,uuid,uuid) to service_role;

comment on function public.admin_bind_team_representative_account(uuid,smallint,uuid,text,uuid,uuid)
is 'Binds an Auth account created by the protected Edge Function to a student representative slot.';

create or replace function public.olient_representative_account_provisioning_is_ready()
returns boolean language sql stable security definer set search_path=pg_catalog as $$
  select to_regprocedure('public.admin_bind_team_representative_account(uuid,smallint,uuid,text,uuid,uuid)') is not null
$$;
revoke all on function public.olient_representative_account_provisioning_is_ready() from public;
grant execute on function public.olient_representative_account_provisioning_is_ready() to anon,authenticated;

create or replace function public.can_manage_team_representatives()
returns boolean language sql stable security definer set search_path=public set row_security=off as $$
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.active and p.role in ('administrator','organizer'))
$$;
revoke all on function public.can_manage_team_representatives() from public;
grant execute on function public.can_manage_team_representatives() to authenticated;

create or replace function public.admin_list_team_representatives(p_team_id uuid)
returns table(slot smallint,student_id uuid,student_name text,email text,status text,accepted_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  return query select r.slot,r.student_id,concat_ws(' ',s.first_name,s.last_name),r.email,
    case when not r.active then 'revoked' when r.user_id is not null then 'active'
      when exists(select 1 from public.team_representative_invites i where i.representative_id=r.id and i.accepted_at is null and i.revoked_at is null and i.expires_at>now()) then 'invite_pending'
      else 'expired' end,
    r.accepted_at
  from public.team_representatives r join public.students s on s.id=r.student_id
  where r.team_id=p_team_id order by r.slot;
end $$;
revoke all on function public.admin_list_team_representatives(uuid) from public;
grant execute on function public.admin_list_team_representatives(uuid) to authenticated;

create or replace function public.admin_revoke_team_representative(p_team_id uuid,p_slot smallint)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_rep_id uuid;v_student_id uuid;v_user_id uuid;
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  select id,student_id,user_id into v_rep_id,v_student_id,v_user_id from public.team_representatives where team_id=p_team_id and slot=p_slot for update;
  if v_rep_id is null then return; end if;
  update public.team_representatives set active=false,user_id=null,updated_at=now() where id=v_rep_id;
  update public.team_representative_invites set revoked_at=now() where representative_id=v_rep_id and accepted_at is null and revoked_at is null;
  update public.team_access_sessions set revoked_at=now() where representative_user_id=v_user_id and v_user_id is not null and revoked_at is null;
  insert into public.team_access_events(team_id,student_id,actor_id,action,new_data)
    values(p_team_id,v_student_id,auth.uid(),'representative_revoked',jsonb_build_object('slot',p_slot));
end $$;
revoke all on function public.admin_revoke_team_representative(uuid,smallint) from public;
grant execute on function public.admin_revoke_team_representative(uuid,smallint) to authenticated;

create or replace function public.admin_team_representative_audit(p_team_id uuid)
returns table(actor_name text,student_name text,action text,changed_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  return query select coalesce(p.display_name,(select concat_ws(' ',rs.first_name,rs.last_name) from public.team_representatives rr join public.students rs on rs.id=rr.student_id where rr.user_id=e.actor_id limit 1),'Acesso por link da equipe'),
    coalesce(concat_ws(' ',s.first_name,s.last_name),'Equipe'),e.action,e.created_at
  from public.team_access_events e left join public.profiles p on p.id=e.actor_id left join public.students s on s.id=e.student_id
  where e.team_id=p_team_id and e.action in ('student_info_saved','shirt_photo_submitted','shirt_photo_reviewed','representative_activated','representative_account_created')
  order by e.created_at desc limit 50;
end $$;
revoke all on function public.admin_team_representative_audit(uuid) from public;
grant execute on function public.admin_team_representative_audit(uuid) to authenticated;
