create function public.set_updated_at() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
do $$ declare t text; begin foreach t in array array['profiles','classes','teams','students','sports','regulations','scoring_rules','registrations','matches','challenges','challenge_results'] loop execute format('create trigger %I_updated_at before update on public.%I for each row execute function public.set_updated_at()',t,t); end loop; end $$;
create function public.current_app_role() returns public.app_role language sql stable security definer set search_path=public as $$ select role from profiles where id=auth.uid() and active $$;
create function public.can_manage() returns boolean language sql stable security definer set search_path=public as $$ select coalesce(current_app_role() in ('administrator','organizer'),false) $$;
create function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select coalesce(current_app_role()='administrator',false) $$;

-- Bootstrap is callable only while no active administrator exists.
create function public.setup_first_admin(display_name text) returns void language plpgsql security definer set search_path=public,auth set row_security=off as $$
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 perform pg_advisory_xact_lock(hashtext('olient-2027-first-admin'));
 if exists(select 1 from public.profiles where role='administrator' and active) then raise exception 'Initial administrator already configured'; end if;
 insert into public.profiles(id,display_name,role) values(auth.uid(),left(trim(display_name),120),'administrator')
 on conflict(id) do update set display_name=excluded.display_name,role='administrator',active=true;
 insert into public.audit_logs(actor_id,action,table_name,record_id,new_data) values(auth.uid(),'bootstrap_admin','profiles',auth.uid()::text,jsonb_build_object('role','administrator'));
end $$;
revoke all on function public.setup_first_admin(text) from public;
grant execute on function public.setup_first_admin(text) to authenticated;

create view public.public_standings with (security_invoker=true) as
select t.id team_id,t.name team_name,coalesce(sum(l.points),0)::numeric(14,2) total_points,dense_rank() over(order by coalesce(sum(l.points),0) desc)::bigint place
from public.teams t left join public.score_ledger l on l.team_id=t.id and l.voided_at is null
where t.active and t.deleted_at is null group by t.id,t.name;

create function public.record_manual_score(p_team_id uuid,p_points numeric,p_description text,p_rule_id uuid,p_source_type text default 'manual') returns uuid
language plpgsql security definer set search_path=public as $$
declare r public.scoring_rules; new_id uuid; idem text;
begin
 if not public.can_manage() then raise exception 'Permission denied'; end if;
 select * into r from scoring_rules where id=p_rule_id and active and p_points=points and regulation_id in(select id from regulations where status='approved');
 if not found then raise exception 'No approved scoring rule matches this entry'; end if;
 idem:='manual:'||p_team_id::text||':'||p_rule_id::text||':'||encode(digest(p_description,'sha256'),'hex');
 insert into score_ledger(team_id,source_type,points,rule_id,regulation_id,entry_type,description,created_by,idempotency_key,sport_id)
 values(p_team_id,p_source_type,p_points,p_rule_id,r.regulation_id,case when p_points<0 then 'penalty' else 'award' end,left(trim(p_description),1000),auth.uid(),idem,r.sport_id)
 on conflict(idempotency_key) do update set idempotency_key=excluded.idempotency_key returning id into new_id;
 return new_id;
end $$;
revoke all on function public.record_manual_score(uuid,numeric,text,uuid,text) from public;
grant execute on function public.record_manual_score(uuid,numeric,text,uuid,text) to authenticated;

create function public.confirm_match_result(p_match_id uuid,p_home_score numeric,p_away_score numeric,p_idempotency_key text) returns uuid
language plpgsql security definer set search_path=public as $$
declare m public.matches; old_result public.match_results; rev integer; res_id uuid; r public.scoring_rules; winner uuid; loser uuid;
begin
 if not public.can_manage() then raise exception 'Permission denied'; end if;
 select * into m from matches where id=p_match_id and deleted_at is null for update;
 if not found then raise exception 'Match not found'; end if;
 if exists(select 1 from match_results where idempotency_key=p_idempotency_key) then select id into res_id from match_results where idempotency_key=p_idempotency_key; return res_id; end if;
 if p_home_score=p_away_score and (select coalesce(rules->>'allow_draw','false')<>'true' from sports where id=m.sport_id) then raise exception 'Tie requires a configured sport rule'; end if;
 select * into old_result from match_results where match_id=m.id and status in ('confirmed','published') order by revision desc limit 1;
 rev:=coalesce((select max(revision) from match_results where match_id=m.id),0)+1;
 insert into match_results(match_id,revision,home_score,away_score,status,created_by,idempotency_key,supersedes_id) values(m.id,rev,p_home_score,p_away_score,'confirmed',auth.uid(),p_idempotency_key,old_result.id) returning id into res_id;
 if old_result.id is not null then
  insert into score_ledger(team_id,sport_id,match_id,source_type,source_id,points,regulation_id,entry_type,description,created_by,idempotency_key,reversal_of)
  select team_id,sport_id,match_id,'reversal',source_id,-points,regulation_id,'reversal','Reversão da revisão anterior',auth.uid(),'reversal:'||id::text,id from score_ledger where source_type='match_result' and source_id=old_result.id and reversal_of is null;
  update score_ledger set voided_at=now() where source_type='match_result' and source_id=old_result.id and voided_at is null;
 end if;
 if p_home_score<>p_away_score then
  winner:=case when p_home_score>p_away_score then m.home_team_id else m.away_team_id end;
  loser:=case when p_home_score>p_away_score then m.away_team_id else m.home_team_id end;
  select * into r from scoring_rules where sport_id=m.sport_id and source_type='placement' and placement=1 and active and regulation_id in(select id from regulations where status='approved') order by created_at desc limit 1;
  if not found then raise exception 'Configure approved winner scoring rule for this sport'; end if;
  insert into score_ledger(team_id,sport_id,match_id,source_type,source_id,points,rule_id,regulation_id,entry_type,description,created_by,idempotency_key) values(winner,m.sport_id,m.id,'match_result',res_id,r.points,r.id,r.regulation_id,'award','Vitória · resultado confirmado',auth.uid(),'match:'||res_id::text||':'||winner::text);
  select * into r from scoring_rules where sport_id=m.sport_id and source_type='placement' and placement=2 and active and regulation_id in(select id from regulations where status='approved') order by created_at desc limit 1;
  if found then insert into score_ledger(team_id,sport_id,match_id,source_type,source_id,points,rule_id,regulation_id,entry_type,description,created_by,idempotency_key) values(loser,m.sport_id,m.id,'match_result',res_id,r.points,r.id,r.regulation_id,'award','Segundo lugar · resultado confirmado',auth.uid(),'match:'||res_id::text||':'||loser::text); end if;
 end if;
 update matches set home_score=p_home_score,away_score=p_away_score,status='confirmed' where id=m.id;
 insert into audit_logs(actor_id,action,table_name,record_id,new_data) values(auth.uid(),'confirm_result','match_results',res_id::text,jsonb_build_object('home_score',p_home_score,'away_score',p_away_score,'revision',rev));
 return res_id;
end $$;
revoke all on function public.confirm_match_result(uuid,numeric,numeric,text) from public;
grant execute on function public.confirm_match_result(uuid,numeric,numeric,text) to authenticated;

create function public.publish_match_result(p_result_id uuid,p_title text default null,p_body text default null) returns uuid
language plpgsql security definer set search_path=public as $$
declare r public.match_results; pub uuid;
begin
 if not public.can_manage() then raise exception 'Permission denied'; end if;
 select * into r from match_results where id=p_result_id for update;
 if not found or r.status not in ('confirmed','published') then raise exception 'Only a confirmed result can be published'; end if;
 update match_results set status='published',published_at=coalesce(published_at,now()) where id=r.id;
 insert into publications(title,body,kind,match_result_id,created_by)
 values(coalesce(p_title,'Resultado oficial'),p_body,'match_result',r.id,auth.uid()) returning id into pub;
 insert into audit_logs(actor_id,action,table_name,record_id,new_data) values(auth.uid(),'publish_result','match_results',r.id::text,jsonb_build_object('publication_id',pub));
 return pub;
end $$;
revoke all on function public.publish_match_result(uuid,text,text) from public;
grant execute on function public.publish_match_result(uuid,text,text) to authenticated;

create function public.withdraw_publication(p_publication_id uuid,p_reason text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.can_manage() then raise exception 'Permission denied'; end if;
 if length(trim(p_reason))<5 then raise exception 'Withdrawal reason is required'; end if;
 update publications set withdrawn_at=now() where id=p_publication_id and withdrawn_at is null;
 if not found then raise exception 'Publication not found or already withdrawn'; end if;
 insert into audit_logs(actor_id,action,table_name,record_id,reason) values(auth.uid(),'withdraw_publication','publications',p_publication_id::text,trim(p_reason));
end $$;
revoke all on function public.withdraw_publication(uuid,text) from public;
grant execute on function public.withdraw_publication(uuid,text) to authenticated;

create function public.reverse_score_entry(p_entry_id uuid,p_reason text) returns uuid language plpgsql security definer set search_path=public as $$
declare e public.score_ledger; out_id uuid;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if length(trim(p_reason))<8 then raise exception 'Correction reason must have at least 8 characters'; end if;
 select * into e from score_ledger where id=p_entry_id for update;
 if not found then raise exception 'Score entry not found'; end if;
 if exists(select 1 from score_ledger where reversal_of=e.id) then select id into out_id from score_ledger where reversal_of=e.id; return out_id; end if;
 insert into score_ledger(team_id,sport_id,match_id,challenge_result_id,source_type,source_id,points,rule_id,regulation_id,entry_type,description,created_by,idempotency_key,reversal_of)
 values(e.team_id,e.sport_id,e.match_id,e.challenge_result_id,'reversal',e.source_id,-e.points,e.rule_id,e.regulation_id,'reversal',trim(p_reason),auth.uid(),'reversal:'||e.id::text,e.id) returning id into out_id;
 update score_ledger set voided_at=now() where id=e.id;
 insert into audit_logs(actor_id,action,table_name,record_id,old_data,new_data,reason) values(auth.uid(),'reverse_score','score_ledger',e.id::text,to_jsonb(e),jsonb_build_object('reversal_id',out_id),trim(p_reason));
 return out_id;
end $$;
revoke all on function public.reverse_score_entry(uuid,text) from public;
grant execute on function public.reverse_score_entry(uuid,text) to authenticated;
