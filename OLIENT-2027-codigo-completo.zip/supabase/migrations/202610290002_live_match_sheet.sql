create table if not exists public.match_live_state (
 match_id uuid primary key references public.matches(id), data jsonb not null default '{}'::jsonb, updated_at timestamptz not null default now()
);
alter table public.match_live_state enable row level security;
create policy "read match live state" on public.match_live_state for select to authenticated using(true);
grant select on public.match_live_state to authenticated;
create or replace function public.save_match_live_state(p_match_id uuid,p_data jsonb) returns void language plpgsql security definer set search_path=public as $$
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if not exists(select 1 from matches where id=p_match_id and deleted_at is null) then raise exception 'Partida indisponível'; end if;
 insert into match_live_state(match_id,data) values(p_match_id,p_data) on conflict(match_id) do update set data=excluded.data,updated_at=now();
 insert into audit_logs(actor_id,action,table_name,record_id,new_data) values(auth.uid(),'update_live_match','match_live_state',p_match_id::text,p_data);
end $$;
revoke all on function public.save_match_live_state(uuid,jsonb) from public;
grant execute on function public.save_match_live_state(uuid,jsonb) to authenticated;
notify pgrst,'reload schema';
