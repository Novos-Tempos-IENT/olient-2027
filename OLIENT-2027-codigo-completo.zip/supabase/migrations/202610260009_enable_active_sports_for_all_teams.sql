-- Enable every active catalog sport for every non-deleted team.
-- Existing approval locks and team-specific categories are preserved.
begin;

insert into public.team_sports(team_id, sport_id, enabled, lock_approved, updated_by)
select t.id, s.id, true, true,
       coalesce(auth.uid(), (
         select p.id from public.profiles p
         where p.active and p.role = 'administrator'
         order by p.created_at, p.id limit 1
       ))
from public.teams t
cross join public.sports s
where t.deleted_at is null
  and s.active
on conflict (team_id, sport_id) do update
set enabled = true,
    updated_at = now();

notify pgrst, 'reload schema';
commit;
