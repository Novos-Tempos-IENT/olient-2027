-- Preserve the current import implementation and add gender validation/storage atomically.
begin;
alter table public.students add column if not exists gender text check(gender in ('male','female'));
do $migration$
declare definition text;
begin
 definition := pg_get_functiondef('public.admin_import_roster(jsonb,boolean)'::regprocedure);
 definition := replace(definition,'public.admin_import_roster(', 'public.admin_import_roster_with_gender(');
 if position('perform pg_advisory_xact_lock(hashtext(v_class_id::text));' in definition)=0 then raise exception 'Importador incompatível: ponto de atualização não encontrado'; end if;
 definition := replace(definition,'perform pg_advisory_xact_lock(hashtext(v_class_id::text));', $patch$
 if r->>'gender' is null or r->>'gender' not in ('male','female') then raise exception 'Terceira coluna ausente ou inválida'; end if;
 update public.students set gender=r->>'gender' where id=v_student_id;
 perform pg_advisory_xact_lock(hashtext(v_class_id::text));
 $patch$);
 execute definition;
end $migration$;
revoke all on function public.admin_import_roster_with_gender(jsonb,boolean) from public;
grant execute on function public.admin_import_roster_with_gender(jsonb,boolean) to authenticated;
notify pgrst,'reload schema';
commit;
