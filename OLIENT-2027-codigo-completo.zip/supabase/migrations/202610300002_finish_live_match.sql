create or replace function public.finish_match_live(p_match_id uuid,p_data jsonb) returns void
language plpgsql security definer set search_path=public as $$
declare m public.matches; home_points integer; away_points integer;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 select * into m from matches where id=p_match_id and deleted_at is null for update;
 if m.id is null or m.home_team_id is null or m.away_team_id is null then raise exception 'Defina as equipes antes de finalizar'; end if;
 if exists(select 1 from match_live_state where match_id=p_match_id and data->>'finishedAt' is not null) then raise exception 'Partida já finalizada'; end if;
 select count(*) into home_points from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) e where e->>'kind'='Gol' and e->>'team'=m.home_team_id::text;
 select count(*) into away_points from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) e where e->>'kind'='Gol' and e->>'team'=m.away_team_id::text;
 perform public.confirm_match_result(p_match_id,home_points,away_points,'live-finish-'||p_match_id::text);
 perform public.save_match_live_state(p_match_id,p_data || jsonb_build_object('runningSince',null,'finishedAt',now()));
end $$;
revoke all on function public.finish_match_live(uuid,jsonb) from public;
grant execute on function public.finish_match_live(uuid,jsonb) to authenticated;
notify pgrst,'reload schema';
