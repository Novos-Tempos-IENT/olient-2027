do $migration$
declare definition text; marker text;
begin
 definition:=pg_get_functiondef('public.finish_match_live(uuid,jsonb)'::regprocedure);
 marker:=' perform public.confirm_match_result';
 if position(marker in definition)=0 then raise exception 'Função de finalização incompatível'; end if;
 definition:=replace(definition,marker,$patch$
 if exists(select 1 from sports where id=m.sport_id and upper(name) like '%BASQUETE%') then
  if jsonb_array_length(coalesce(p_data->'lineups'->m.home_team_id::text,'[]'::jsonb)) not between 1 and 4 or jsonb_array_length(coalesce(p_data->'lineups'->m.away_team_id::text,'[]'::jsonb)) not between 1 and 4 then raise exception 'Selecione de 1 a 4 jogadores por equipe'; end if;
  select coalesce(sum(case e->>'kind' when '2 pontos' then 2 when '3 pontos' then 3 else 0 end),0) into home_points from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) e where e->>'team'=m.home_team_id::text;
  select coalesce(sum(case e->>'kind' when '2 pontos' then 2 when '3 pontos' then 3 else 0 end),0) into away_points from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) e where e->>'team'=m.away_team_id::text;
 end if;
 perform public.confirm_match_result
$patch$);
 execute definition;
end $migration$;
notify pgrst,'reload schema';
