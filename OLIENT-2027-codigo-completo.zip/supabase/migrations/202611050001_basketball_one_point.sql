-- Inclui lances de um ponto no cálculo oficial do basquete.
begin;
do $$
declare
  fn record;
  definition text;
begin
  for fn in
    select p.oid from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and p.prokind = 'f'
      and p.prosrc like '%when ''2 pontos'' then 2%'
  loop
    definition := pg_get_functiondef(fn.oid);
    definition := replace(definition,
      'when ''2 pontos'' then 2',
      'when ''1 ponto'' then 1 when ''2 pontos'' then 2');
    execute definition;
  end loop;
end $$;
notify pgrst, 'reload schema';
commit;
