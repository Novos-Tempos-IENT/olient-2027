-- Apply after migrations finish_live_match and reopen_live_match.
do $migration$
declare definition text; marker text;
begin
 definition:=pg_get_functiondef('public.finish_match_live(uuid,jsonb)'::regprocedure);
 marker:=' perform public.confirm_match_result';
 if position(marker in definition)=0 then raise exception 'Função de finalização incompatível'; end if;
 definition:=replace(definition,marker,$patch$
 if exists(select 1 from sports where id=m.sport_id and upper(name) ~ 'TÊNIS DE MESA|TENIS DE MESA|VÔLEI|VOLEI|FUTMESA') then
  if jsonb_array_length(coalesce(p_data->'sets','[]'::jsonb))<>3 then raise exception 'Informe os três campos de sets'; end if;
  home_points:=0; away_points:=0;
  for set_row in select value from jsonb_array_elements(p_data->'sets') loop
   if home_points=2 or away_points=2 then
    if set_row->>'home' is not null or set_row->>'away' is not null then raise exception 'Não pode haver set após duas vitórias'; end if;
    continue;
   end if;
   if set_row->>'home' is null or set_row->>'away' is null or (set_row->>'home')::integer<0 or (set_row->>'away')::integer<0 or (set_row->>'home')::integer=(set_row->>'away')::integer then raise exception 'Set incompleto ou empatado'; end if;
   if (set_row->>'home')::integer>(set_row->>'away')::integer then home_points:=home_points+1; else away_points:=away_points+1; end if;
  end loop;
  if greatest(home_points,away_points)<>2 then raise exception 'Uma equipe deve vencer dois sets'; end if;
  limit_players:=case when exists(select 1 from sports where id=m.sport_id and upper(name) ~ 'TÊNIS DE MESA|TENIS DE MESA') then 1 else 2 end;
  if jsonb_array_length(coalesce(p_data->'lineups'->m.home_team_id::text,'[]'::jsonb))<>limit_players or jsonb_array_length(coalesce(p_data->'lineups'->m.away_team_id::text,'[]'::jsonb))<>limit_players then raise exception 'Quantidade de atletas selecionados inválida'; end if;
 end if;
 perform public.confirm_match_result
$patch$);
 definition:=replace(definition,'declare m public.matches;','declare set_row jsonb; limit_players integer; m public.matches;');
 execute definition;
end $migration$;
notify pgrst,'reload schema';
