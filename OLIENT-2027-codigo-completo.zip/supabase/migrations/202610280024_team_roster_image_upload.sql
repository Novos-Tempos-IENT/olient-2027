-- Allow roster submissions as images as well as PDF, spreadsheet, or CSV files.
create or replace function public.create_team_submission_upload_token(p_session_token text,p_kind text,p_content_type text)
returns jsonb language plpgsql security definer
set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_token text; v_extension text; v_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  if p_kind in ('shirt','flag') and p_content_type not in ('image/jpeg','image/png','image/webp') then
    return jsonb_build_object('error','invalid_image_file_type');
  end if;
  if p_kind='roster' and p_content_type not in (
    'application/pdf','text/csv','application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'image/jpeg','image/png','image/webp'
  ) then return jsonb_build_object('error','invalid_roster_file_type'); end if;
  if p_kind not in ('shirt','flag','roster') then return jsonb_build_object('error','invalid_submission_kind'); end if;
  v_extension:=case p_content_type
    when 'image/jpeg' then 'jpg'
    when 'image/png' then 'png'
    when 'image/webp' then 'webp'
    when 'application/pdf' then 'pdf'
    when 'application/vnd.ms-excel' then 'xls'
    when 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' then 'xlsx'
    else 'csv' end;
  v_token:=encode(gen_random_bytes(24),'hex');
  v_path:=v_link.team_id::text||'/'||p_kind||'/'||encode(digest(v_token,'sha256'),'hex')||'.'||v_extension;
  insert into public.team_submission_upload_tokens(token_hash,team_id,session_id,kind,content_type,expires_at)
  values(encode(digest(v_token,'sha256'),'hex'),v_link.team_id,v_session.id,p_kind,p_content_type,now()+interval '10 minutes');
  return jsonb_build_object('upload_token',v_token,'storage_path',v_path,'expires_at',now()+interval '10 minutes');
end $$;

revoke all on function public.create_team_submission_upload_token(text,text,text) from public;
grant execute on function public.create_team_submission_upload_token(text,text,text) to anon,authenticated;

create or replace function public.olient_roster_image_upload_is_ready()
returns boolean language sql stable security definer set search_path=pg_catalog,public as $$
  select position('image/png' in pg_get_functiondef('public.create_team_submission_upload_token(text,text,text)'::regprocedure))>0
    and exists(select 1 from storage.buckets where id='team-submissions' and allowed_mime_types @> array['image/png','image/jpeg']::text[])
$$;
revoke all on function public.olient_roster_image_upload_is_ready() from public;
grant execute on function public.olient_roster_image_upload_is_ready() to anon,authenticated;
