create or replace function public.admin_set_match_division(p_match_id uuid,p_division text) returns text
language plpgsql security definer set search_path=public as $$
declare m public.matches; base text; result text;
begin
 if not public.is_admin() then raise exception 'Administrator permission required'; end if;
 if p_division not in ('Masculino','Feminino') or p_division is null then raise exception 'Divisão inválida'; end if;
 select * into m from matches where id=p_match_id and deleted_at is null for update;
 if m.id is null then raise exception 'Partida indisponível'; end if;
 if exists(select 1 from match_live_state where match_id=p_match_id and (data->>'finishedAt' is not null or jsonb_array_length(coalesce(data->'events','[]'::jsonb))>0)) then raise exception 'Partida com lances ou finalizada: revise os registros antes de alterar a divisão'; end if;
 if exists(select 1 from match_results where match_id=p_match_id) then raise exception 'Partida com resultado registrado: a divisão exige revisão administrativa'; end if;
 base := case when (select name from teams where id=m.home_team_id) ~ '^\s*[67]' then '6º e 7º anos' when (select name from teams where id=m.home_team_id) ~ '^\s*[1289]' then '8º, 9º, 1º e 2º anos' else null end;
 if base is null then raise exception 'Não foi possível identificar a faixa de anos'; end if;
 result := base||' · '||p_division;
 update matches set category=result,updated_at=now() where id=p_match_id;
 insert into audit_logs(actor_id,action,table_name,record_id,old_data,new_data) values(auth.uid(),'set_match_division','matches',p_match_id::text,jsonb_build_object('category',m.category),jsonb_build_object('category',result));
 return result;
end $$;
revoke all on function public.admin_set_match_division(uuid,text) from public;
grant execute on function public.admin_set_match_division(uuid,text) to authenticated;
notify pgrst,'reload schema';
