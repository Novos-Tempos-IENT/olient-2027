-- OLIENT Supabase production updates, migrations 007 through 024.
-- Run once in the Supabase SQL Editor with database-owner privileges.
-- Includes the official Gincana program supplied by the organization; it does not create student, match, or score test data.

-- ===== BEGIN 202610270007_multi_sport_schedule.sql =====

-- Single atomic publication of a multi-sport schedule, preserving the existing
-- single-sport generator and its records.
alter table public.court_availability drop constraint if exists court_availability_court_name_check;
alter table public.court_availability add constraint court_availability_court_name_check
  check (court_name in ('Quadra 1','Quadra 2','Futmesa','Tênis de Mesa'));

alter table public.matches drop constraint if exists matches_court_name_check;
alter table public.matches add constraint matches_court_name_check
  check (court_name is null or court_name in ('Quadra 1','Quadra 2','Futmesa','Tênis de Mesa'));
alter table public.matches add column if not exists schedule_batch_id uuid;
alter table public.matches add column if not exists category text;

create table if not exists public.schedule_batches (
  id uuid primary key default gen_random_uuid(),
  config jsonb not null,
  result jsonb not null,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  published_at timestamptz not null default now(),
  idempotency_key text not null unique
);
alter table public.schedule_batches enable row level security;
drop policy if exists "published batches public or staff" on public.schedule_batches;
drop policy if exists "admins manage schedule batches" on public.schedule_batches;
create policy "published batches public or staff" on public.schedule_batches
  for select using (public.current_app_role() is not null);
create policy "admins manage schedule batches" on public.schedule_batches
  for all using (public.is_admin()) with check (public.is_admin());
grant select on public.schedule_batches to authenticated;
create unique index if not exists uq_match_fixture_batch
  on public.matches(schedule_batch_id,fixture_key)
  where schedule_batch_id is not null and fixture_key is not null;

create or replace function public.publish_multi_sport_schedule(
  p_idempotency_key text, p_config jsonb, p_result jsonb
) returns uuid
language plpgsql security definer set search_path=public as $$
declare
  batch_id uuid;
  item jsonb;
  sport_config jsonb;
  fixture_start timestamptz;
  fixture_end timestamptz;
  event_day date;
  duration_value integer;
  fixture_key_value text;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if nullif(trim(p_idempotency_key),'') is null then raise exception 'Idempotency key required'; end if;
  if exists(select 1 from jsonb_array_elements(coalesce(p_result->'unscheduled','[]'::jsonb))) then
    raise exception 'Cannot publish a schedule with fixtures without times';
  end if;
  if jsonb_array_length(coalesce(p_config->'sports','[]'::jsonb)) = 0
     or jsonb_array_length(coalesce(p_result->'scheduled','[]'::jsonb)) = 0 then
    raise exception 'No sports or fixtures were provided';
  end if;
  if coalesce((p_config->>'interval_minutes')::integer,0)<0 or coalesce((p_config->>'team_rest_minutes')::integer,0)<0 then
    raise exception 'Schedule intervals cannot be negative';
  end if;
  if exists(select 1 from sports s where s.active and s.status='active'
    and not exists(select 1 from jsonb_array_elements(p_config->'sports') c where c->>'sport_id'=s.id::text)) then
    raise exception 'Every active sport must be included in the batch configuration';
  end if;
  select id into batch_id from schedule_batches where idempotency_key=p_idempotency_key;
  if batch_id is not null then return batch_id; end if;

  insert into schedule_batches(config,result,created_by,idempotency_key)
    values(p_config,p_result,auth.uid(),p_idempotency_key) returning id into batch_id;

  for item in select value from jsonb_array_elements(p_result->'scheduled') loop
    if item->>'sport_id' is null or item->>'home' is null or item->>'away' is null
      or item->>'home' like 'A definir%' or item->>'away' like 'A definir%' then
      raise exception 'Fixture has unresolved participants or sport';
    end if;
    select value into sport_config from jsonb_array_elements(p_config->'sports') c(value)
      where c.value->>'sport_id'=item->>'sport_id';
    if sport_config is null then raise exception 'Fixture sport is absent from the batch configuration'; end if;
    if not exists(select 1 from sports s where s.id=(item->>'sport_id')::uuid and s.active and s.status='active') then
      raise exception 'Fixture sport is not active';
    end if;
    if sport_config->>'format' not in ('round_robin','knockout','groups') then raise exception 'Unsupported sport format'; end if;
    if sport_config->>'format'='groups' and (sport_config->>'advancing_per_group')::integer<>2 then
      raise exception 'Group format must advance the top two teams from each group';
    end if;
    if not (sport_config->'venues' ? (item->>'court')) then raise exception 'Fixture venue is not allowed for its sport'; end if;
    event_day := (item->>'date')::date;
    duration_value := (item->>'duration')::integer;
    if duration_value < 1 or (sport_config->>'duration')::integer <> duration_value
      or not (sport_config->'dates' ? event_day::text) then raise exception 'Fixture date or duration does not match its sport configuration'; end if;
    fixture_start := ((item->>'date') || ' ' || (item->>'start'))::timestamp at time zone 'America/Sao_Paulo';
    fixture_end := ((item->>'date') || ' ' || (item->>'end'))::timestamp at time zone 'America/Sao_Paulo';
    if fixture_end <= fixture_start or extract(epoch from (fixture_end-fixture_start))/60 <> duration_value then
      raise exception 'Fixture has an invalid time range';
    end if;
    if not exists(select 1 from registrations r where r.sport_id=(item->>'sport_id')::uuid
      and r.category is not distinct from nullif(item->>'category','')
      and r.team_id=(item->>'home')::uuid and r.status='approved')
      or not exists(select 1 from registrations r where r.sport_id=(item->>'sport_id')::uuid
      and r.category is not distinct from nullif(item->>'category','')
      and r.team_id=(item->>'away')::uuid and r.status='approved') then
      raise exception 'Fixture includes a team not approved for this sport and category';
    end if;
    if exists(select 1 from teams t where t.id in ((item->>'home')::uuid,(item->>'away')::uuid)
      and (not t.active or t.deleted_at is not null)) then raise exception 'Fixture includes an inactive team'; end if;
    if not exists(select 1 from court_availability ca where ca.court_name=item->>'court'
      and (ca.available_from at time zone 'America/Sao_Paulo')::date=event_day
      and fixture_start>=ca.available_from and fixture_end<=ca.available_until
      and not exists(select 1 from jsonb_array_elements(coalesce(ca.blocked_windows,'[]'::jsonb)||coalesce(ca.pause_windows,'[]'::jsonb)) b
        where fixture_start < ((event_day::text||' '||(b->>'end'))::timestamp at time zone 'America/Sao_Paulo')
          and fixture_end > ((event_day::text||' '||(b->>'start'))::timestamp at time zone 'America/Sao_Paulo')))
      then raise exception 'Fixture is outside official availability or overlaps a blocked period';
    end if;
    if exists(select 1 from matches m where m.deleted_at is null and coalesce(m.schedule_status,'draft')<>'cancelled'
      and m.court_name=item->>'court'
      and m.scheduled_at < fixture_end+make_interval(mins=>coalesce((p_config->>'interval_minutes')::integer,0))
      and m.scheduled_at+make_interval(mins=>coalesce(m.duration_minutes,0)) > fixture_start-make_interval(mins=>coalesce((p_config->>'interval_minutes')::integer,0))) then
      raise exception 'Court time conflict with an existing match';
    end if;
    if exists(select 1 from matches m where m.deleted_at is null and coalesce(m.schedule_status,'draft')<>'cancelled'
      and (m.home_team_id in ((item->>'home')::uuid,(item->>'away')::uuid)
        or m.away_team_id in ((item->>'home')::uuid,(item->>'away')::uuid))
      and m.scheduled_at < fixture_end + make_interval(mins=>coalesce((p_config->>'team_rest_minutes')::integer,0))
      and m.scheduled_at+make_interval(mins=>coalesce(m.duration_minutes,0)) > fixture_start-make_interval(mins=>coalesce((p_config->>'team_rest_minutes')::integer,0))) then
      raise exception 'Team rest conflict with an existing match';
    end if;
    fixture_key_value := (item->>'sport_id')||':'||coalesce(item->>'category','')||':'||(item->>'id');
    insert into matches(sport_id,scheduled_at,venue,court_name,duration_minutes,round,status,schedule_status,
      home_team_id,away_team_id,created_by,schedule_batch_id,fixture_key,category)
    values((item->>'sport_id')::uuid,fixture_start,item->>'court',item->>'court',duration_value,item->>'round',
      'confirmed','published',(item->>'home')::uuid,(item->>'away')::uuid,auth.uid(),batch_id,fixture_key_value,nullif(item->>'category',''));
  end loop;
  insert into audit_logs(actor_id,action,table_name,record_id,new_data)
    values(auth.uid(),'publish_multi_sport_schedule','schedule_batches',batch_id::text,
      jsonb_build_object('sports',p_config->'sports','fixtures',jsonb_array_length(p_result->'scheduled')));
  return batch_id;
end $$;
revoke all on function public.publish_multi_sport_schedule(text,jsonb,jsonb) from public;
grant execute on function public.publish_multi_sport_schedule(text,jsonb,jsonb) to authenticated;


-- ===== END 202610270007_multi_sport_schedule.sql =====


-- ===== BEGIN 202610270008_gincana_program.sql =====

-- Programa oficial da gincana OLIENT 2027. Pontuação fica em branco até ser
-- definida pela organização; isso não cria resultados nem lançamentos.
create table if not exists public.gincana_program_sections (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  sort_order integer not null unique,
  created_at timestamptz not null default now()
);
create table if not exists public.gincana_program_items (
  id uuid primary key default gen_random_uuid(),
  section_id uuid not null references public.gincana_program_sections(id) on delete cascade,
  event_date date,
  title text not null,
  sort_order integer not null,
  champion_points numeric(12,2) check(champion_points is null or champion_points>=0),
  runner_up_points numeric(12,2) check(runner_up_points is null or runner_up_points>=0),
  created_at timestamptz not null default now(),
  unique(section_id, sort_order)
);
alter table public.gincana_program_items add column if not exists champion_points numeric(12,2) check(champion_points is null or champion_points>=0);
alter table public.gincana_program_items add column if not exists runner_up_points numeric(12,2) check(runner_up_points is null or runner_up_points>=0);
alter table public.gincana_program_sections enable row level security;
alter table public.gincana_program_items enable row level security;
drop policy if exists "gincana program is publicly readable" on public.gincana_program_sections;
drop policy if exists "gincana program items are publicly readable" on public.gincana_program_items;
drop policy if exists "admins manage gincana sections" on public.gincana_program_sections;
drop policy if exists "admins manage gincana items" on public.gincana_program_items;
create policy "gincana program is publicly readable" on public.gincana_program_sections for select using (true);
create policy "gincana program items are publicly readable" on public.gincana_program_items for select using (true);
create policy "admins manage gincana sections" on public.gincana_program_sections for all using (public.is_admin()) with check (public.is_admin());
create policy "admins manage gincana items" on public.gincana_program_items for all using (public.is_admin()) with check (public.is_admin());
grant select on public.gincana_program_sections, public.gincana_program_items to anon, authenticated;

insert into public.gincana_program_sections(name,sort_order) values
 ('Gincanas',1),('Ação social',2),('Entrada',3),('Vídeos',4),('Esportes',5),('Cartões',6),('Punições',7)
on conflict(name) do update set sort_order=excluded.sort_order;

with seed(section_name,event_date,title,sort_order) as (values
 ('Gincanas','2027-09-30'::date,'Continue a música',1),
 ('Gincanas','2027-09-30'::date,'Embaixadinha feminina',2),
 ('Gincanas','2027-09-30'::date,'Batatinha frita 1, 2, 3',3),
 ('Gincanas','2027-09-30'::date,'Balde de água nos pés',4),
 ('Gincanas','2027-09-30'::date,'Trazer funcionários para dançar',5),
 ('Gincanas','2027-09-30'::date,'Itens aleatórios',6),
 ('Gincanas','2027-10-01'::date,'Batalha de robôs',7),
 ('Gincanas','2027-10-01'::date,'Karaokê / Videokê',8),
 ('Gincanas','2027-10-01'::date,'Guerra de cotonete',9),
 ('Gincanas','2027-10-01'::date,'Corrida do chinelão',10),
 ('Gincanas','2027-10-01'::date,'Twister',11),
 ('Gincanas','2027-10-01'::date,'Crossfit Betim',12),
 ('Gincanas','2027-10-01'::date,'Arco e flecha',13),
 ('Gincanas','2027-10-01'::date,'Itens aleatórios',14),
 ('Gincanas','2027-10-01'::date,'Embaixadinha masculina',15),
 ('Gincanas','2027-10-02'::date,'Cano furado',16),
 ('Gincanas','2027-10-02'::date,'Itens aleatórios',17),
 ('Gincanas','2027-10-02'::date,'Cabo de guerra',18),
 ('Gincanas','2027-10-02'::date,'Torta na cara',19),
 ('Gincanas','2027-10-02'::date,'Batalha dos robôs',20),
 ('Ação social','2027-09-30'::date,'Brinquedos',1),
 ('Ação social','2027-10-01'::date,'Higiene',2),
 ('Ação social','2027-10-02'::date,'1 kg de alimento',3),
 ('Entrada',null,'Camisa (entrada)',1),
 ('Entrada',null,'Camisa (criatividade)',2),
 ('Entrada',null,'Bandeira',3),
 ('Entrada',null,'Traje (criatividade)',4),
 ('Entrada',null,'Traje (entrada)',5),
 ('Vídeos',null,'Grito de guerra',1),
 ('Vídeos',null,'Origem do personagem',2),
 ('Vídeos',null,'Convite para abertura',3),
 ('Esportes',null,'Basquete masculino',1),
 ('Esportes',null,'Basquete feminino',2),
 ('Esportes',null,'Dodgeball',3),
 ('Esportes',null,'Futsal masculino',4),
 ('Esportes',null,'Futsal feminino',5),
 ('Esportes',null,'Handebol misto',6),
 ('Esportes',null,'Tênis de mesa masculino',7),
 ('Esportes',null,'Tênis de mesa feminino',8),
 ('Esportes',null,'Futmesa masculino',9),
 ('Esportes',null,'Futmesa feminino',10),
 ('Esportes',null,'Vôlei de mesa masculino',11),
 ('Esportes',null,'Vôlei de mesa feminino',12),
 ('Esportes',null,'Voleibol',13),
 ('Cartões',null,'Futsal masculino',1),
 ('Cartões',null,'Handebol masculino',2)
)
insert into public.gincana_program_items(section_id,event_date,title,sort_order)
select s.id,seed.event_date,seed.title,seed.sort_order
from seed join public.gincana_program_sections s on s.name=seed.section_name
on conflict(section_id,sort_order) do update set event_date=excluded.event_date,title=excluded.title;

-- The sports section shows final champion and runner-up awards. These are
-- program values only and are not awarded on every individual match.
update public.gincana_program_items i
set champion_points=15000,runner_up_points=5000
from public.gincana_program_sections s
where s.id=i.section_id and s.name='Esportes';


-- ===== END 202610270008_gincana_program.sql =====


-- ===== BEGIN 202610270009_sports_placement_points.sql =====

-- Official sports placement points requested for OLIENT 2027.
-- This does not create or approve a regulation and does not create results.
alter table public.gincana_program_items
  add column if not exists champion_points numeric(12,2) check(champion_points is null or champion_points>=0);
alter table public.gincana_program_items
  add column if not exists runner_up_points numeric(12,2) check(runner_up_points is null or runner_up_points>=0);

update public.gincana_program_items i
set champion_points=15000,runner_up_points=5000
from public.gincana_program_sections s
where s.id=i.section_id and s.name='Esportes';


-- ===== END 202610270009_sports_placement_points.sql =====


-- ===== BEGIN 202610270010_gincana_auto_results_and_totals.sql =====

-- Dynamic Gincana awards and final totals. These views read official score
-- ledger entries; placement bonuses are calculated in the summary only and
-- are never written as fabricated ledger transactions.
create or replace view public.public_gincana_sport_awards
with (security_barrier=true) as
with sport_points as (
  select l.sport_id,s.name sport_name,l.team_id,t.name team_name,sum(l.points)::numeric(14,2) points
  from public.score_ledger l
  join public.sports s on s.id=l.sport_id and s.active
  join public.teams t on t.id=l.team_id and t.active and t.deleted_at is null
  where l.voided_at is null
  group by l.sport_id,s.name,l.team_id,t.name
  having sum(l.points)<>0
), ranked as (
  select p.*,dense_rank() over(partition by p.sport_id order by p.points desc) place,
    count(*) over(partition by p.sport_id,p.points) same_points
  from sport_points p
), leader_summary as (
  select sport_id,
    count(*) filter(where place=1) first_count,
    string_agg(team_name,', ' order by team_name) filter(where place=1) first_names,
    (array_agg(team_id order by team_id) filter(where place=1 and same_points=1))[1] first_id,
    count(*) filter(where place=2) second_count,
    string_agg(team_name,', ' order by team_name) filter(where place=2) second_names,
    (array_agg(team_id order by team_id) filter(where place=2 and same_points=1))[1] second_id
  from ranked group by sport_id
), format_rows as (
  select g.created_at,g.sport_id::text,g.format from public.schedule_generation g
), latest_format as (
  select distinct on(sport_id) sport_id::uuid,format
  from format_rows order by sport_id,created_at desc
), match_progress as (
  select m.sport_id,count(*) match_count,
    bool_and(m.home_score is not null and m.away_score is not null and m.status in ('confirmed','published')) all_complete,
    bool_or(coalesce(m.round,'') ilike 'Grupo %') has_group,
    bool_or(coalesce(m.round,'') ilike '%Eliminatória%') has_knockout
  from public.matches m
  where m.deleted_at is null and coalesce(m.schedule_status,'draft')<>'cancelled'
  group by m.sport_id
), sport_formats as (
  select s.id sport_id,coalesce(lf.format,
    case when coalesce(mp.has_group,false) then 'groups'
      when coalesce(mp.has_knockout,false) then 'knockout'
      when lower(coalesce(s.format,'')) in ('knockout','single_elimination','third_place','groups') then lower(s.format)
      else 'round_robin' end) format
  from public.sports s left join latest_format lf on lf.sport_id=s.id
  left join match_progress mp on mp.sport_id=s.id
), final_rows as (
  select m.sport_id,
    case when m.home_score>m.away_score then m.home_team_id else m.away_team_id end champion_id,
    case when m.home_score>m.away_score then m.away_team_id else m.home_team_id end runner_up_id,
    row_number() over(partition by m.sport_id order by m.scheduled_at desc nulls last,m.created_at desc) rn
  from public.matches m
  where m.deleted_at is null and coalesce(m.schedule_status,'draft')<>'cancelled'
    and coalesce(m.round,'') ~* '(^|[^[:alpha:]])final([^[:alpha:]]|$)'
    and m.status in ('confirmed','published') and m.home_score is not null and m.away_score is not null
    and m.home_score<>m.away_score
), completed_final as (select * from final_rows where rn=1), resolved as (
  select s.id sport_id,s.name sport_name,
    case when f.sport_id is not null then ch.name
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 then ls.first_names
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and coalesce(ls.first_count,0)>1 then 'Empate: '||ls.first_names
      else null end champion_name,
    case when f.sport_id is not null then f.champion_id
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 then ls.first_id
      else null end champion_id,
    case when f.sport_id is not null then ru.name
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 and ls.second_count=1 then ls.second_names
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 and ls.second_count>1 then 'Empate: '||ls.second_names
      else null end runner_up_name,
    case when f.sport_id is not null then f.runner_up_id
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 and ls.second_count=1 then ls.second_id
      else null end runner_up_id,
    case when f.sport_id is not null then 'Definido pela final'
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and coalesce(ls.first_count,0)=1 then 'Definido pela classificação final'
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and coalesce(ls.first_count,0)>1 then 'Empate · desempate pendente'
      when coalesce(mp.match_count,0)=0 then 'Aguardando resultados'
      when sf.format in ('knockout','single_elimination','third_place','groups') then 'Aguardando final'
      else 'Aguardando conclusão da tabela' end champion_status,
    case when f.sport_id is not null then 'Definido pela final'
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 and ls.second_count=1 then 'Definido pela classificação final'
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 and ls.second_count>1 then 'Empate · desempate pendente'
      when sf.format='round_robin' and coalesce(mp.all_complete,false) and ls.first_count=1 then 'Vice ainda não definido'
      when coalesce(mp.match_count,0)=0 then 'Aguardando resultados'
      when sf.format in ('knockout','single_elimination','third_place','groups') then 'Aguardando final'
      else 'Aguardando conclusão da tabela' end runner_up_status
  from public.sports s
  left join leader_summary ls on ls.sport_id=s.id
  left join sport_formats sf on sf.sport_id=s.id
  left join match_progress mp on mp.sport_id=s.id
  left join completed_final f on f.sport_id=s.id
  left join public.teams ch on ch.id=f.champion_id
  left join public.teams ru on ru.id=f.runner_up_id
  where s.active
)
select sport_id,sport_name,champion_name,champion_id,
  case when champion_id is not null then 15000::numeric(12,2) else null end champion_points,
  champion_status,runner_up_name,runner_up_id,
  case when runner_up_id is not null then 5000::numeric(12,2) else null end runner_up_points,
  runner_up_status
from resolved;

create or replace view public.public_gincana_totals
with (security_barrier=true) as
with ledger_totals as (
  select t.id team_id,t.name team_name,
    coalesce(sum(l.points) filter(where l.sport_id is not null),0)::numeric(14,2) sports_points,
    coalesce(sum(l.points) filter(where l.sport_id is null),0)::numeric(14,2) other_points,
    coalesce(sum(l.points),0)::numeric(14,2) ledger_total
  from public.teams t left join public.score_ledger l on l.team_id=t.id and l.voided_at is null
  where t.active and t.deleted_at is null group by t.id,t.name
), placement_bonuses as (
  select t.id team_id,
    coalesce(sum(case when a.champion_id=t.id then a.champion_points else 0 end),0)::numeric(14,2) champion_bonus,
    coalesce(sum(case when a.runner_up_id=t.id then a.runner_up_points else 0 end),0)::numeric(14,2) runner_up_bonus
  from public.teams t cross join public.public_gincana_sport_awards a
  where t.active and t.deleted_at is null group by t.id
), totals as (
  select l.team_id,l.team_name,l.sports_points,l.other_points,
    coalesce(b.champion_bonus,0)::numeric(14,2) champion_bonus,
    coalesce(b.runner_up_bonus,0)::numeric(14,2) runner_up_bonus,
    (l.ledger_total+coalesce(b.champion_bonus,0)+coalesce(b.runner_up_bonus,0))::numeric(14,2) final_points
  from ledger_totals l left join placement_bonuses b using(team_id)
)
select team_id,team_name,sports_points,other_points,champion_bonus,runner_up_bonus,final_points,
  dense_rank() over(order by final_points desc)::bigint place
from totals;

grant select on public.public_gincana_sport_awards,public.public_gincana_totals to anon,authenticated;
comment on view public.public_gincana_sport_awards is 'Per-sport champion and vice from a confirmed final, or completed round-robin tables; ties remain unresolved.';
comment on view public.public_gincana_totals is 'Per-team official ledger totals plus dynamic champion and vice bonuses for the Gincana final table.';


-- ===== END 202610270010_gincana_auto_results_and_totals.sql =====


-- ===== BEGIN 202610270011_gincana_item_points.sql =====

-- Configurable point value for each Gincana program activity.
alter table public.gincana_program_items
  add column if not exists points_value numeric(12,2)
  check(points_value is null or points_value between 0 and 1000000000);

comment on column public.gincana_program_items.points_value is
  'Maximum/configured value of this Gincana activity. It is not an awarded team score until a result is entered.';

create or replace function public.set_gincana_program_item_points(p_item_id uuid,p_points numeric)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_points is not null and (p_points<0 or p_points>1000000000) then
    raise exception 'Activity points must be between 0 and 1000000000';
  end if;
  update public.gincana_program_items set points_value=p_points where id=p_item_id;
  if not found then raise exception 'Gincana activity not found'; end if;
  insert into public.audit_logs(actor_id,action,table_name,record_id,new_data)
    values(auth.uid(),'set_gincana_activity_points','gincana_program_items',p_item_id::text,
      jsonb_build_object('points_value',p_points));
end $$;
revoke all on function public.set_gincana_program_item_points(uuid,numeric) from public;
grant execute on function public.set_gincana_program_item_points(uuid,numeric) to authenticated;


-- ===== END 202610270011_gincana_item_points.sql =====


-- ===== BEGIN 202610270012_gincana_item_scores.sql =====

-- Points awarded to a team for one non-sports Gincana activity.
-- Sports results continue to come from the official score ledger and standings.
create table if not exists public.gincana_item_scores (
  item_id uuid not null references public.gincana_program_items(id) on delete cascade,
  team_id uuid not null references public.teams(id) on delete cascade,
  score_type text not null check (score_type in ('standard','variable')),
  points numeric(12,2) not null check (points between 0 and 1000000000),
  created_by uuid references public.profiles(id),
  updated_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (item_id,team_id)
);

alter table public.gincana_item_scores enable row level security;
drop policy if exists "gincana item scores are publicly readable" on public.gincana_item_scores;
create policy "gincana item scores are publicly readable"
  on public.gincana_item_scores for select using (true);
grant select on public.gincana_item_scores to anon,authenticated;
revoke insert,update,delete on public.gincana_item_scores from anon,authenticated;

create or replace function public.set_gincana_item_result(
  p_item_id uuid,p_team_id uuid,p_score_type text,p_points numeric
) returns void language plpgsql security definer set search_path=public as $$
declare
  v_points numeric(12,2);
  v_sport_section boolean;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_score_type not in ('standard','variable') then raise exception 'Invalid score type'; end if;
  if p_points is null or p_points<0 or p_points>1000000000 then
    raise exception 'Activity points must be between 0 and 1000000000';
  end if;
  select (s.name='Esportes'),i.points_value into v_sport_section,v_points
  from public.gincana_program_items i
  join public.gincana_program_sections s on s.id=i.section_id
  where i.id=p_item_id;
  if not found then raise exception 'Gincana activity not found'; end if;
  if v_sport_section then raise exception 'Sports placements are awarded automatically from the final standings'; end if;
  if p_score_type='standard' and (v_points is null or p_points<>v_points) then
    raise exception 'Standard points must match the configured activity value';
  end if;
  if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null) then
    raise exception 'Active team not found';
  end if;
  insert into public.gincana_item_scores(item_id,team_id,score_type,points,created_by,updated_by)
  values(p_item_id,p_team_id,p_score_type,p_points,auth.uid(),auth.uid())
  on conflict(item_id,team_id) do update set score_type=excluded.score_type,points=excluded.points,
    updated_by=auth.uid(),updated_at=now();
  insert into public.audit_logs(actor_id,action,table_name,record_id,new_data)
  values(auth.uid(),'set_gincana_activity_result','gincana_item_scores',p_item_id::text||':'||p_team_id::text,
    jsonb_build_object('item_id',p_item_id,'team_id',p_team_id,'score_type',p_score_type,'points',p_points));
end $$;

create or replace function public.remove_gincana_item_result(p_item_id uuid,p_team_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare v_old public.gincana_item_scores%rowtype;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  delete from public.gincana_item_scores where item_id=p_item_id and team_id=p_team_id returning * into v_old;
  if not found then return; end if;
  insert into public.audit_logs(actor_id,action,table_name,record_id,old_data)
  values(auth.uid(),'remove_gincana_activity_result','gincana_item_scores',p_item_id::text||':'||p_team_id::text,
    jsonb_build_object('item_id',v_old.item_id,'team_id',v_old.team_id,'score_type',v_old.score_type,'points',v_old.points));
end $$;

revoke all on function public.set_gincana_item_result(uuid,uuid,text,numeric) from public;
revoke all on function public.remove_gincana_item_result(uuid,uuid) from public;
grant execute on function public.set_gincana_item_result(uuid,uuid,text,numeric) to authenticated;
grant execute on function public.remove_gincana_item_result(uuid,uuid) to authenticated;

create or replace view public.public_gincana_totals
with (security_barrier=true) as
with ledger_totals as (
  select t.id team_id,t.name team_name,
    coalesce(sum(l.points) filter(where l.sport_id is not null),0)::numeric(14,2) sports_points,
    coalesce(sum(l.points) filter(where l.sport_id is null),0)::numeric(14,2) ledger_other_points,
    coalesce(sum(l.points),0)::numeric(14,2) ledger_total
  from public.teams t left join public.score_ledger l on l.team_id=t.id and l.voided_at is null
  where t.active and t.deleted_at is null group by t.id,t.name
), activity_totals as (
  select team_id,coalesce(sum(points),0)::numeric(14,2) activity_points
  from public.gincana_item_scores group by team_id
), placement_bonuses as (
  select t.id team_id,
    coalesce(sum(case when a.champion_id=t.id then a.champion_points else 0 end),0)::numeric(14,2) champion_bonus,
    coalesce(sum(case when a.runner_up_id=t.id then a.runner_up_points else 0 end),0)::numeric(14,2) runner_up_bonus
  from public.teams t cross join public.public_gincana_sport_awards a
  where t.active and t.deleted_at is null group by t.id
), totals as (
  select l.team_id,l.team_name,l.sports_points,
    (l.ledger_other_points+coalesce(a.activity_points,0))::numeric(14,2) other_points,
    coalesce(b.champion_bonus,0)::numeric(14,2) champion_bonus,
    coalesce(b.runner_up_bonus,0)::numeric(14,2) runner_up_bonus,
    (l.ledger_total+coalesce(a.activity_points,0)+coalesce(b.champion_bonus,0)+coalesce(b.runner_up_bonus,0))::numeric(14,2) final_points
  from ledger_totals l left join activity_totals a using(team_id) left join placement_bonuses b using(team_id)
)
select team_id,team_name,sports_points,other_points,champion_bonus,runner_up_bonus,final_points,
  dense_rank() over(order by final_points desc)::bigint place
from totals;

grant select on public.public_gincana_totals to anon,authenticated;
comment on table public.gincana_item_scores is 'Official Gincana event scores by team. Sports champion and runner-up points are calculated separately.';


-- ===== END 202610270012_gincana_item_scores.sql =====


-- ===== BEGIN 202610270013_court_availability_management.sql =====

-- Admin-only API for creating official event availability windows.
-- Direct table writes remain unavailable to application clients.
create or replace function public.admin_create_court_availability(
  p_court_name text,
  p_event_date date,
  p_start_time time,
  p_end_time time
) returns uuid language plpgsql security definer set search_path=public as $$
declare
  v_id uuid;
  v_from timestamptz;
  v_until timestamptz;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_court_name not in ('Quadra 1','Quadra 2','Futmesa','Tênis de Mesa') then
    raise exception 'Invalid official venue';
  end if;
  if p_event_date is null or p_start_time is null or p_end_time is null or p_end_time<=p_start_time then
    raise exception 'Availability must have a date and end after start';
  end if;
  v_from := (p_event_date+p_start_time) at time zone 'America/Sao_Paulo';
  v_until := (p_event_date+p_end_time) at time zone 'America/Sao_Paulo';
  insert into public.court_availability(court_name,available_from,available_until,created_by)
  values(p_court_name,v_from,v_until,auth.uid())
  on conflict(court_name,available_from,available_until) do nothing
  returning id into v_id;
  if v_id is null then raise exception 'Esta janela já está cadastrada para o local e horário informados.'; end if;
  insert into public.audit_logs(actor_id,action,table_name,record_id,new_data)
  values(auth.uid(),'create_court_availability','court_availability',v_id::text,
    jsonb_build_object('court_name',p_court_name,'available_from',v_from,'available_until',v_until));
  return v_id;
end $$;

revoke all on function public.admin_create_court_availability(text,date,time,time) from public;
grant execute on function public.admin_create_court_availability(text,date,time,time) to authenticated;


-- ===== END 202610270013_court_availability_management.sql =====


-- ===== BEGIN 202610270014_team_shirt_photo_review.sql =====

-- Private shirt-photo submissions with team-link scoped upload/read policies.
alter table public.team_student_details
  add column if not exists shirt_photo_path text,
  add column if not exists shirt_photo_status text not null default 'not_submitted'
    check (shirt_photo_status in ('not_submitted','pending','approved','correction_requested')),
  add column if not exists shirt_photo_review_note text,
  add column if not exists shirt_photo_submitted_at timestamptz,
  add column if not exists shirt_photo_reviewed_at timestamptz,
  add column if not exists shirt_photo_reviewed_by uuid references public.profiles(id);

create table if not exists public.team_shirt_upload_tokens (
  id uuid primary key default gen_random_uuid(),
  token_hash text not null unique,
  team_id uuid not null references public.teams(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  session_id uuid not null references public.team_access_sessions(id) on delete cascade,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.team_shirt_upload_tokens enable row level security;
revoke all on public.team_shirt_upload_tokens from anon,authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('team-shirt-photos','team-shirt-photos',false,8388608,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

create or replace function public.authorize_team_shirt_photo_upload(p_name text,p_token text)
returns boolean language plpgsql stable security definer set search_path=public,storage,extensions set row_security=off as $$
declare v_team uuid; v_student uuid; v_token text;
begin
  if p_name !~ '^[0-9a-fA-F-]{36}/[0-9a-fA-F-]{36}/[0-9a-f]{64}\.(jpg|png|webp)$' or p_token is null then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid;
  v_student:=split_part(p_name,'/',2)::uuid;
  v_token:=split_part(split_part(p_name,'/',3),'.',1);
  return exists(
    select 1 from public.team_shirt_upload_tokens u
    join public.team_access_sessions s on s.id=u.session_id and s.revoked_at is null and s.expires_at>now()
    join public.team_access_links l on l.id=s.link_id and l.team_id=u.team_id and l.revoked_at is null and l.expires_at>now()
    join public.team_students ts on ts.team_id=u.team_id and ts.student_id=u.student_id and ts.left_at is null
    where u.token_hash=encode(digest(p_token,'sha256'),'hex') and u.team_id=v_team and u.student_id=v_student
      and u.expires_at>now() and u.used_at is null and v_token=encode(digest(p_token,'sha256'),'hex')
  );
exception when others then return false;
end $$;

create or replace function public.can_read_team_shirt_photo(p_name text)
returns boolean language plpgsql stable security definer set search_path=public,storage set row_security=off as $$
declare v_team uuid; v_student uuid;
begin
  if public.is_admin() then return true; end if;
  if p_name !~ '^[0-9a-fA-F-]{36}/[0-9a-fA-F-]{36}/[0-9a-f]{64}\.(jpg|png|webp)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid; v_student:=split_part(p_name,'/',2)::uuid;
  return exists(select 1 from public.team_access_links l
    join public.team_students ts on ts.team_id=l.team_id and ts.student_id=v_student and ts.left_at is null
    where l.team_id=v_team and l.revoked_at is null and l.expires_at>now());
exception when others then return false;
end $$;

create or replace function public.can_delete_team_shirt_photo(p_name text)
returns boolean language plpgsql stable security definer set search_path=public,storage set row_security=off as $$
declare v_team uuid; v_student uuid;
begin
  if public.is_admin() then return true; end if;
  if p_name !~ '^[0-9a-fA-F-]{36}/[0-9a-fA-F-]{36}/[0-9a-f]{64}\.(jpg|png|webp)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid; v_student:=split_part(p_name,'/',2)::uuid;
  -- Students replace an image by uploading a new object; only administrators
  -- may remove stored objects, preventing deletion of another student's photo.
  return false;
exception when others then return false;
end $$;

revoke all on function public.authorize_team_shirt_photo_upload(text,text) from public;
revoke all on function public.can_read_team_shirt_photo(text) from public;
revoke all on function public.can_delete_team_shirt_photo(text) from public;
grant execute on function public.authorize_team_shirt_photo_upload(text,text) to anon,authenticated;
grant execute on function public.can_read_team_shirt_photo(text) to anon,authenticated;
grant execute on function public.can_delete_team_shirt_photo(text) to anon,authenticated;

drop policy if exists "team shirt photos read" on storage.objects;
drop policy if exists "team shirt photos upload" on storage.objects;
drop policy if exists "team shirt photos replace" on storage.objects;
drop policy if exists "team shirt photos delete" on storage.objects;
create policy "team shirt photos read" on storage.objects for select
  using(bucket_id='team-shirt-photos' and public.can_read_team_shirt_photo(name));
create policy "team shirt photos upload" on storage.objects for insert
  with check(bucket_id='team-shirt-photos' and public.authorize_team_shirt_photo_upload(name,metadata->>'team_shirt_upload_token'));
create policy "team shirt photos replace" on storage.objects for update
  using(bucket_id='team-shirt-photos' and public.can_read_team_shirt_photo(name))
  with check(bucket_id='team-shirt-photos' and public.authorize_team_shirt_photo_upload(name,metadata->>'team_shirt_upload_token'));
create policy "team shirt photos delete" on storage.objects for delete
  using(bucket_id='team-shirt-photos' and public.can_delete_team_shirt_photo(name));

create or replace function public.create_team_shirt_upload_token(p_session_token text,p_student_id uuid,p_content_type text)
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_token text; v_extension text; v_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found or v_link.edits_locked then return jsonb_build_object('error',case when not found then 'link_unavailable' else 'edits_locked' end); end if;
  if not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=v_link.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
  if p_content_type not in ('image/jpeg','image/png','image/webp') then return jsonb_build_object('error','invalid_photo_type'); end if;
  if not public.team_access_rate_limit(v_link.id,p_student_id,'upload') then return jsonb_build_object('error','rate_limited'); end if;
  v_extension:=case p_content_type when 'image/jpeg' then 'jpg' when 'image/png' then 'png' else 'webp' end;
  v_token:=encode(gen_random_bytes(24),'hex');
  v_path:=v_link.team_id::text||'/'||p_student_id::text||'/'||encode(digest(v_token,'sha256'),'hex')||'.'||v_extension;
  insert into public.team_shirt_upload_tokens(token_hash,team_id,student_id,session_id,expires_at)
  values(encode(digest(v_token,'sha256'),'hex'),v_link.team_id,p_student_id,v_session.id,now()+interval '10 minutes');
  return jsonb_build_object('upload_token',v_token,'storage_path',v_path,'expires_at',now()+interval '10 minutes');
end $$;

create or replace function public.submit_team_shirt_photo(p_session_token text,p_student_id uuid,p_storage_path text,p_upload_token text)
returns jsonb language plpgsql security definer set search_path=public,storage,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_old_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  if not exists(select 1 from public.team_shirt_upload_tokens u where u.token_hash=encode(digest(p_upload_token,'sha256'),'hex') and u.team_id=v_link.team_id and u.student_id=p_student_id and u.session_id=v_session.id and u.expires_at>now() and u.used_at is null) then return jsonb_build_object('error','invalid_upload_token'); end if;
  if p_storage_path !~ ('^'||v_link.team_id::text||'/'||p_student_id::text||'/'||encode(digest(p_upload_token,'sha256'),'hex')||'\.(jpg|png|webp)$') then return jsonb_build_object('error','invalid_upload_path'); end if;
  if not exists(select 1 from storage.objects o where o.bucket_id='team-shirt-photos' and o.name=p_storage_path and o.metadata->>'team_shirt_upload_token'=p_upload_token) then return jsonb_build_object('error','photo_upload_missing'); end if;
  if not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=v_link.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
  select shirt_photo_path into v_old_path from public.team_student_details where team_id=v_link.team_id and student_id=p_student_id;
  insert into public.team_student_details(team_id,student_id,shirt_photo_path,shirt_photo_status,shirt_photo_review_note,shirt_photo_submitted_at,shirt_photo_reviewed_at,shirt_photo_reviewed_by,updated_at)
  values(v_link.team_id,p_student_id,p_storage_path,'pending',null,now(),null,null,now())
  on conflict(team_id,student_id) do update set shirt_photo_path=excluded.shirt_photo_path,shirt_photo_status='pending',shirt_photo_review_note=null,shirt_photo_submitted_at=now(),shirt_photo_reviewed_at=null,shirt_photo_reviewed_by=null,updated_at=now();
  update public.team_shirt_upload_tokens set used_at=now() where token_hash=encode(digest(p_upload_token,'sha256'),'hex');
  insert into public.team_access_events(team_id,student_id,link_id,session_id,action,old_data,new_data)
  values(v_link.team_id,p_student_id,v_link.id,v_session.id,'shirt_photo_submitted',jsonb_build_object('path',v_old_path),jsonb_build_object('path',p_storage_path,'status','pending'));
  return jsonb_build_object('ok',true,'message','Imagem da camisa enviada para análise.');
end $$;

create or replace function public.get_team_shirt_photo_status(p_session_token text,p_student_id uuid)
returns jsonb language plpgsql security definer set search_path=public set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_photo public.team_student_details;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found or not exists(select 1 from public.team_students ts where ts.team_id=v_link.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
  select * into v_photo from public.team_student_details where team_id=v_link.team_id and student_id=p_student_id;
  if not found then return jsonb_build_object('status','not_submitted','storage_path',null,'review_note',null); end if;
  return jsonb_build_object('status',v_photo.shirt_photo_status,'storage_path',v_photo.shirt_photo_path,'review_note',v_photo.shirt_photo_review_note,'submitted_at',v_photo.shirt_photo_submitted_at);
end $$;

create or replace function public.admin_review_team_shirt_photo(p_team_id uuid,p_student_id uuid,p_decision text,p_note text default null)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_old_status text; v_old_note text;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_decision not in ('approved','correction_requested') then raise exception 'Invalid decision'; end if;
  if p_decision='correction_requested' and length(trim(coalesce(p_note,'')))<3 then raise exception 'Informe o motivo da correção com pelo menos 3 caracteres'; end if;
  select shirt_photo_status,shirt_photo_review_note into v_old_status,v_old_note from public.team_student_details where team_id=p_team_id and student_id=p_student_id and shirt_photo_path is not null for update;
  if not found or v_old_status<>'pending' then raise exception 'A imagem não está aguardando análise'; end if;
  update public.team_student_details set shirt_photo_status=p_decision,shirt_photo_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) else null end,shirt_photo_reviewed_at=now(),shirt_photo_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id and student_id=p_student_id;
  insert into public.team_access_events(team_id,student_id,actor_id,action,old_data,new_data)
  values(p_team_id,p_student_id,auth.uid(),'shirt_photo_reviewed',jsonb_build_object('status',v_old_status,'note',v_old_note),jsonb_build_object('status',p_decision,'note',p_note));
end $$;

revoke all on function public.create_team_shirt_upload_token(text,uuid,text) from public;
revoke all on function public.submit_team_shirt_photo(text,uuid,text,text) from public;
revoke all on function public.get_team_shirt_photo_status(text,uuid) from public;
revoke all on function public.admin_review_team_shirt_photo(uuid,uuid,text,text) from public;
grant execute on function public.create_team_shirt_upload_token(text,uuid,text) to anon,authenticated;
grant execute on function public.submit_team_shirt_photo(text,uuid,text,text) to anon,authenticated;
grant execute on function public.get_team_shirt_photo_status(text,uuid) to anon,authenticated;
grant execute on function public.admin_review_team_shirt_photo(uuid,uuid,text,text) to authenticated;

comment on column public.team_student_details.shirt_photo_path is 'Private Supabase Storage path for the team shirt image submitted by this student.';


-- ===== END 202610270014_team_shirt_photo_review.sql =====


-- ===== BEGIN 202610280015_official_bulletin_and_rescheduling.sql =====

-- Supports official bulletin printing and auditable match rescheduling.
alter table public.matches
  add column if not exists postponed boolean not null default false,
  add column if not exists postponement_reason text;

create table if not exists public.match_schedule_changes (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  previous_scheduled_at timestamptz,
  new_scheduled_at timestamptz not null,
  previous_court_name text,
  new_court_name text not null,
  reason text not null check(length(trim(reason)) between 3 and 1000),
  changed_by uuid not null references public.profiles(id),
  changed_at timestamptz not null default now()
);
create index if not exists match_schedule_changes_match_idx
  on public.match_schedule_changes(match_id,changed_at desc);
alter table public.match_schedule_changes enable row level security;
drop policy if exists "staff read match schedule changes" on public.match_schedule_changes;
drop policy if exists "admins manage match schedule changes" on public.match_schedule_changes;
create policy "staff read match schedule changes" on public.match_schedule_changes
  for select using(public.current_app_role() is not null);
create policy "admins manage match schedule changes" on public.match_schedule_changes
  for all using(public.is_admin()) with check(public.is_admin());
grant select on public.match_schedule_changes to authenticated;

create or replace function public.admin_reschedule_match(
  p_match_id uuid,
  p_new_scheduled_at timestamptz,
  p_new_court_name text,
  p_reason text
) returns void
language plpgsql security definer set search_path=public set row_security=off as $$
declare
  v_match public.matches;
  v_court text;
  v_day date;
  v_end timestamptz;
  v_gap integer:=0;
  v_rest integer:=0;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_new_scheduled_at is null or p_new_scheduled_at<=now() then
    raise exception 'A nova data e horário devem estar no futuro';
  end if;
  if length(trim(coalesce(p_reason,'')))<3 then
    raise exception 'Informe o motivo do adiamento com pelo menos 3 caracteres';
  end if;

  select * into v_match from public.matches where id=p_match_id and deleted_at is null for update;
  if not found then raise exception 'Partida não encontrada'; end if;
  if coalesce(v_match.schedule_status,'draft')<>'published' or v_match.status not in ('confirmed','published') then
    raise exception 'Somente partidas publicadas podem ser adiadas';
  end if;
  if v_match.home_score is not null or v_match.away_score is not null
     or exists(select 1 from public.match_results r where r.match_id=p_match_id) then
    raise exception 'Uma partida com resultado registrado não pode ser adiada';
  end if;

  v_court:=coalesce(nullif(trim(p_new_court_name),''),v_match.court_name,v_match.venue);
  if v_court not in ('Quadra 1','Quadra 2','Futmesa','Tênis de Mesa') then
    raise exception 'Selecione um local oficial válido';
  end if;
  v_day:=(p_new_scheduled_at at time zone 'America/Sao_Paulo')::date;
  v_end:=p_new_scheduled_at+make_interval(mins=>coalesce(v_match.duration_minutes,30));

  select coalesce((b.config->>'interval_minutes')::integer,0),
         coalesce((b.config->>'team_rest_minutes')::integer,0)
    into v_gap,v_rest
    from public.schedule_batches b where b.id=v_match.schedule_batch_id;
  v_gap:=coalesce(v_gap,0); v_rest:=coalesce(v_rest,0);

  if not exists(
    select 1 from public.court_availability ca
    where ca.court_name=v_court
      and (ca.available_from at time zone 'America/Sao_Paulo')::date=v_day
      and p_new_scheduled_at>=ca.available_from and v_end<=ca.available_until
      and not exists(
        select 1 from jsonb_array_elements(coalesce(ca.blocked_windows,'[]'::jsonb)||coalesce(ca.pause_windows,'[]'::jsonb)) w
        where p_new_scheduled_at < ((v_day::text||' '||(w->>'end'))::timestamp at time zone 'America/Sao_Paulo')
          and v_end > ((v_day::text||' '||(w->>'start'))::timestamp at time zone 'America/Sao_Paulo')
      )
  ) then raise exception 'O horário não está dentro de uma janela oficial disponível para esse local'; end if;

  if exists(
    select 1 from public.matches m
    where m.id<>p_match_id and m.deleted_at is null
      and coalesce(m.schedule_status,'draft')<>'cancelled'
      and m.court_name=v_court
      and m.scheduled_at < v_end+make_interval(mins=>v_gap)
      and m.scheduled_at+make_interval(mins=>coalesce(m.duration_minutes,30)) > p_new_scheduled_at-make_interval(mins=>v_gap)
  ) then raise exception 'Já existe uma partida nesse local e horário'; end if;

  if exists(
    select 1 from public.matches m
    where m.id<>p_match_id and m.deleted_at is null
      and coalesce(m.schedule_status,'draft')<>'cancelled'
      and (m.home_team_id in (v_match.home_team_id,v_match.away_team_id)
        or m.away_team_id in (v_match.home_team_id,v_match.away_team_id))
      and m.scheduled_at < v_end+make_interval(mins=>v_rest)
      and m.scheduled_at+make_interval(mins=>coalesce(m.duration_minutes,30)) > p_new_scheduled_at-make_interval(mins=>v_rest)
  ) then raise exception 'Uma das equipes já tem partida nesse horário ou período de descanso'; end if;

  insert into public.match_schedule_changes(match_id,previous_scheduled_at,new_scheduled_at,previous_court_name,new_court_name,reason,changed_by)
    values(p_match_id,v_match.scheduled_at,p_new_scheduled_at,coalesce(v_match.court_name,v_match.venue),v_court,left(trim(p_reason),1000),auth.uid());
  update public.matches set scheduled_at=p_new_scheduled_at,court_name=v_court,venue=v_court,
    postponed=true,postponement_reason=left(trim(p_reason),1000),updated_at=now()
    where id=p_match_id;
  insert into public.audit_logs(actor_id,action,table_name,record_id,old_data,new_data)
    values(auth.uid(),'reschedule_match','matches',p_match_id::text,
      jsonb_build_object('scheduled_at',v_match.scheduled_at,'court_name',v_match.court_name),
      jsonb_build_object('scheduled_at',p_new_scheduled_at,'court_name',v_court,'reason',left(trim(p_reason),1000)));
end $$;
revoke all on function public.admin_reschedule_match(uuid,timestamptz,text,text) from public;
grant execute on function public.admin_reschedule_match(uuid,timestamptz,text,text) to authenticated;

comment on column public.matches.postponed is 'True when the match has been rescheduled by the organization.';


-- ===== END 202610280015_official_bulletin_and_rescheduling.sql =====


-- ===== BEGIN 202610280016_enable_realtime_sync.sql =====

-- Publish only application tables needed for live refreshes. Realtime still
-- applies each subscriber's SELECT grants and RLS policies.
do $$
declare
  v_table text;
  v_tables text[] := array[
    'classes','students','teams','team_classes','team_students','sports',
    'registrations','team_sports','team_student_details','team_student_sports',
    'matches','match_results','score_ledger','challenges','challenge_results',
    'gincana_program_sections','gincana_program_items','gincana_item_scores'
  ];
begin
  if not exists(select 1 from pg_publication where pubname='supabase_realtime') then
    raise notice 'Publication supabase_realtime not found; skipping realtime registration.';
    return;
  end if;

  if exists(select 1 from pg_publication where pubname='supabase_realtime' and puballtables) then
    return;
  end if;

  foreach v_table in array v_tables loop
    if to_regclass(format('public.%I',v_table)) is not null
      and not exists(
        select 1 from pg_publication_tables
        where pubname='supabase_realtime' and schemaname='public' and tablename=v_table
      ) then
      execute format('alter publication supabase_realtime add table public.%I',v_table);
    end if;
  end loop;
end $$;

create or replace function public.olient_realtime_is_ready()
returns boolean
language sql stable security definer set search_path=pg_catalog as $$
  select exists(select 1 from pg_publication where pubname='supabase_realtime' and puballtables)
    or (
      exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='matches')
      and exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='teams')
      and exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='sports')
      and exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='gincana_program_items')
      and exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='team_student_details')
    )
$$;
revoke all on function public.olient_realtime_is_ready() from public;
grant execute on function public.olient_realtime_is_ready() to anon,authenticated;


-- ===== END 202610280016_enable_realtime_sync.sql =====

-- ===== BEGIN 202610280017_student_team_representatives.sql =====
-- Two individually authenticated student representatives per school team.
-- Each representative signs up with their own personal email and a password
-- they choose; the invitation token is single-use and bound to that email.

alter table public.team_access_sessions
  add column if not exists representative_user_id uuid references auth.users(id) on delete cascade;

create table if not exists public.team_representatives (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  slot smallint not null check(slot in (1,2)),
  student_id uuid not null references public.students(id),
  email text not null check(email=lower(trim(email))),
  user_id uuid unique references auth.users(id) on delete set null,
  active boolean not null default true,
  invited_at timestamptz,
  accepted_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(team_id,slot),
  check(email ~* '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$')
);
create unique index if not exists team_representatives_email_unique_idx
  on public.team_representatives(lower(email)) where active;
create index if not exists team_representatives_team_idx
  on public.team_representatives(team_id,slot) where active;
create unique index if not exists team_representatives_student_active_idx
  on public.team_representatives(team_id,student_id) where active;

create table if not exists public.team_representative_invites (
  id uuid primary key default gen_random_uuid(),
  representative_id uuid not null references public.team_representatives(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  accepted_at timestamptz,
  revoked_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);
create index if not exists team_representative_invites_pending_idx
  on public.team_representative_invites(representative_id,expires_at desc)
  where accepted_at is null and revoked_at is null;
alter table public.team_representatives enable row level security;
alter table public.team_representative_invites enable row level security;
revoke all on public.team_representatives,public.team_representative_invites from anon,authenticated;

create or replace function public.admin_issue_team_representative_invite(
  p_team_id uuid,p_slot smallint,p_student_id uuid,p_email text
) returns jsonb
language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare
  v_rep public.team_representatives;
  v_email text:=lower(trim(coalesce(p_email,'')));
  v_token text:=encode(gen_random_bytes(32),'hex');
  v_user_id uuid;
  v_link public.team_access_links;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_slot not in (1,2) then raise exception 'Representative slot must be 1 or 2'; end if;
  if v_email !~* '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$' then raise exception 'Informe um e-mail pessoal válido'; end if;
  if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null) then raise exception 'Equipe ativa não encontrada'; end if;
  if not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id where ts.team_id=p_team_id and ts.student_id=p_student_id and ts.left_at is null and s.active and s.deleted_at is null) then raise exception 'O representante precisa ser um aluno ativo desta turma'; end if;

  perform pg_advisory_xact_lock(hashtext(p_team_id::text));
  select * into v_rep from public.team_representatives where team_id=p_team_id and slot=p_slot for update;
  if found and v_rep.user_id is not null and v_rep.active then raise exception 'Desative o representante atual antes de substituí-lo'; end if;
  if exists(select 1 from public.team_representatives r where r.active and lower(r.email)=v_email and (r.team_id,r.slot) is distinct from (p_team_id,p_slot)) then raise exception 'Este e-mail já está vinculado a outro representante'; end if;
  if exists(select 1 from public.team_representatives r where r.team_id=p_team_id and r.active and r.student_id=p_student_id and r.slot<>p_slot) then raise exception 'O mesmo aluno não pode ocupar os dois lugares de representante'; end if;

  select * into v_link from public.team_access_links where team_id=p_team_id for update;
  if not found then
    insert into public.team_access_links(team_id,token_hash,expires_at,created_by)
    values(p_team_id,encode(digest(gen_random_bytes(32),'sha256'),'hex'),now()+interval '30 days',auth.uid());
  elsif v_link.revoked_at is not null or v_link.expires_at<=now() then
    update public.team_access_links set revoked_at=null,expires_at=now()+interval '30 days',updated_at=now() where id=v_link.id;
  end if;

  if v_rep.id is not null then
    v_user_id:=v_rep.user_id;
    update public.team_representatives set active=false,user_id=null,updated_at=now() where id=v_rep.id;
    update public.team_access_sessions set revoked_at=now() where representative_user_id=v_user_id and revoked_at is null;
  end if;

  if v_rep.id is null then
    insert into public.team_representatives(team_id,slot,student_id,email,active,invited_at,created_by)
    values(p_team_id,p_slot,p_student_id,v_email,true,now(),auth.uid()) returning * into v_rep;
  else
    update public.team_representatives set student_id=p_student_id,email=v_email,active=true,invited_at=now(),accepted_at=null,updated_at=now()
      where id=v_rep.id returning * into v_rep;
  end if;
  update public.team_representative_invites set revoked_at=now()
    where representative_id=v_rep.id and revoked_at is null;
  insert into public.team_representative_invites(representative_id,token_hash,expires_at,created_by)
    values(v_rep.id,encode(digest(v_token,'sha256'),'hex'),now()+interval '30 days',auth.uid());
  insert into public.team_access_events(team_id,student_id,actor_id,action,new_data)
    values(p_team_id,p_student_id,auth.uid(),'representative_invited',jsonb_build_object('slot',p_slot,'email',v_email));
  return jsonb_build_object('invite_token',v_token,'expires_at',now()+interval '30 days','slot',p_slot,'email',v_email);
end $$;
revoke all on function public.admin_issue_team_representative_invite(uuid,smallint,uuid,text) from public;
grant execute on function public.admin_issue_team_representative_invite(uuid,smallint,uuid,text) to authenticated;

create or replace function public.get_my_profile()
returns public.profiles language sql stable security definer set search_path=public set row_security=off as $$
  select p.* from public.profiles p where p.id=auth.uid() and (p.active or exists(select 1 from public.team_representatives r where r.user_id=auth.uid() and r.active))
$$;
revoke all on function public.get_my_profile() from public;
grant execute on function public.get_my_profile() to authenticated;

create or replace function public.admin_list_team_representatives(p_team_id uuid)
returns table(slot smallint,student_id uuid,student_name text,email text,status text,accepted_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  return query
  select r.slot,r.student_id,concat_ws(' ',s.first_name,s.last_name),r.email,
    case when not r.active then 'revoked' when r.user_id is not null then 'active'
      when exists(select 1 from public.team_representative_invites i where i.representative_id=r.id and i.accepted_at is null and i.revoked_at is null and i.expires_at>now()) then 'invite_pending'
      else 'expired' end,
    r.accepted_at
  from public.team_representatives r join public.students s on s.id=r.student_id
  where r.team_id=p_team_id order by r.slot;
end $$;
revoke all on function public.admin_list_team_representatives(uuid) from public;
grant execute on function public.admin_list_team_representatives(uuid) to authenticated;

create or replace function public.admin_revoke_team_representative(p_team_id uuid,p_slot smallint)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_rep_id uuid; v_student_id uuid; v_user_id uuid;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  select id,student_id,user_id into v_rep_id,v_student_id,v_user_id
    from public.team_representatives where team_id=p_team_id and slot=p_slot for update;
  if v_rep_id is null then return; end if;
  update public.team_representatives set active=false,user_id=null,updated_at=now() where id=v_rep_id;
  update public.team_representative_invites set revoked_at=now() where representative_id=v_rep_id and accepted_at is null and revoked_at is null;
  update public.team_access_sessions set revoked_at=now() where representative_user_id=v_user_id and revoked_at is null;
  insert into public.team_access_events(team_id,student_id,actor_id,action,new_data)
    values(p_team_id,v_student_id,auth.uid(),'representative_revoked',jsonb_build_object('slot',p_slot));
end $$;
revoke all on function public.admin_revoke_team_representative(uuid,smallint) from public;
grant execute on function public.admin_revoke_team_representative(uuid,smallint) to authenticated;

create or replace function public.accept_team_representative_invite(p_invite_token text)
returns jsonb language plpgsql security definer set search_path=public,auth set row_security=off as $$
declare v_invite public.team_representative_invites; v_rep public.team_representatives; v_student public.students; v_email text;
begin
  if auth.uid() is null then raise exception 'Entre ou crie sua conta antes de aceitar o convite'; end if;
  select lower(u.email) into v_email from auth.users u where u.id=auth.uid() and u.email_confirmed_at is not null;
  if v_email is null then raise exception 'Confirme seu e-mail antes de ativar o acesso'; end if;
  if p_invite_token is null or length(p_invite_token)<>64 then raise exception 'Convite inválido ou expirado'; end if;
  select * into v_invite from public.team_representative_invites where token_hash=encode(digest(p_invite_token,'sha256'),'hex') and accepted_at is null and revoked_at is null and expires_at>now() for update;
  if not found then raise exception 'Convite inválido, expirado ou já utilizado'; end if;
  select * into v_rep from public.team_representatives where id=v_invite.representative_id and active for update;
  if not found or lower(v_rep.email)<>v_email then raise exception 'Use o e-mail pessoal para o qual este convite foi criado'; end if;
  if v_rep.user_id is not null and v_rep.user_id<>auth.uid() then raise exception 'Este lugar de representante já está ativado'; end if;
  select * into v_student from public.students where id=v_rep.student_id and active and deleted_at is null;
  if not found then raise exception 'O cadastro do estudante não está mais ativo'; end if;
  insert into public.profiles(id,display_name,role,active)
    values(auth.uid(),concat_ws(' ',v_student.first_name,v_student.last_name),'viewer',true)
    on conflict(id) do update set display_name=excluded.display_name,active=true;
  update public.team_representatives set user_id=auth.uid(),accepted_at=now(),updated_at=now() where id=v_rep.id;
  update public.team_representative_invites set accepted_at=now() where id=v_invite.id;
  insert into public.team_access_events(team_id,student_id,actor_id,action,new_data)
    values(v_rep.team_id,v_rep.student_id,auth.uid(),'representative_activated',jsonb_build_object('slot',v_rep.slot,'email',v_email));
  return jsonb_build_object('team_id',v_rep.team_id,'team_slug',(select slug from public.teams where id=v_rep.team_id),
    'team_name',(select name from public.teams where id=v_rep.team_id),'student_id',v_rep.student_id,
    'student_name',concat_ws(' ',v_student.first_name,v_student.last_name),'slot',v_rep.slot);
end $$;
revoke all on function public.accept_team_representative_invite(text) from public;
grant execute on function public.accept_team_representative_invite(text) to authenticated;

create or replace function public.get_my_team_representative()
returns jsonb language sql stable security definer set search_path=public set row_security=off as $$
  select jsonb_build_object('team_id',r.team_id,'team_slug',t.slug,'team_name',t.name,
    'student_id',r.student_id,'student_name',concat_ws(' ',s.first_name,s.last_name),'slot',r.slot)
  from public.team_representatives r
  join public.teams t on t.id=r.team_id and t.active and t.deleted_at is null
  join public.students s on s.id=r.student_id and s.active and s.deleted_at is null
  where r.user_id=auth.uid() and r.active
  limit 1
$$;
revoke all on function public.get_my_team_representative() from public;
grant execute on function public.get_my_team_representative() to authenticated;

create or replace function public.start_team_representative_session()
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_rep public.team_representatives; v_link public.team_access_links; v_token text; v_session_id uuid;
begin
  if auth.uid() is null then raise exception 'Representative authentication required'; end if;
  select * into v_rep from public.team_representatives where user_id=auth.uid() and active for update;
  if not found then return jsonb_build_object('error','representative_not_found'); end if;
  select * into v_link from public.team_access_links where team_id=v_rep.team_id for update;
  if not found then raise exception 'O acesso da equipe precisa ser configurado pela organização'; end if;
  update public.team_access_sessions set revoked_at=now() where representative_user_id=auth.uid() and revoked_at is null;
  v_token:=encode(gen_random_bytes(32),'hex');
  insert into public.team_access_sessions(link_id,session_hash,expires_at,representative_user_id)
    values(v_link.id,encode(digest(v_token,'sha256'),'hex'),now()+interval '4 hours',auth.uid()) returning id into v_session_id;
  insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action)
    values(v_rep.team_id,v_rep.student_id,auth.uid(),v_link.id,v_session_id,'representative_session_started');
  return jsonb_build_object('session_token',v_token,'slug',(select slug from public.teams where id=v_rep.team_id),
    'team_name',(select name from public.teams where id=v_rep.team_id),'representative_name',(select concat_ws(' ',first_name,last_name) from public.students where id=v_rep.student_id));
end $$;
revoke all on function public.start_team_representative_session() from public;
grant execute on function public.start_team_representative_session() to authenticated;

-- The shared roster editor records authenticated representative identity.
create or replace function public.save_team_student_info(p_session_token text,p_student_id uuid,p_shirt_name text,p_shirt_number integer,p_sport_ids uuid[])
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare l public.team_access_links; v_session public.team_access_sessions; v_team public.teams; v_sport_id uuid; v_sport public.sports; v_limit integer; v_old jsonb; v_new jsonb;
begin
 v_session:=public.validate_team_access_session(p_session_token);
 if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
 select * into l from public.team_access_links where id=v_session.link_id;
 if not found then return jsonb_build_object('error','link_unavailable'); end if;
 if l.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
 if not public.team_access_rate_limit(l.id,p_student_id,'save') then return jsonb_build_object('error','rate_limited'); end if;
 select * into v_team from public.teams where id=l.team_id and active and deleted_at is null;
 if not found or not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=l.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
 if length(trim(coalesce(p_shirt_name,''))) not between 1 and 30 or p_shirt_name ~ '[[:cntrl:]]' then return jsonb_build_object('error','invalid_shirt_name'); end if;
 if l.require_shirt_number and p_shirt_number is null then return jsonb_build_object('error','shirt_number_required'); end if;
 if p_shirt_number is not null and p_shirt_number not between l.shirt_number_min and l.shirt_number_max then return jsonb_build_object('error','invalid_shirt_number'); end if;
 perform pg_advisory_xact_lock(hashtext(l.team_id::text));
 if p_sport_ids is null then p_sport_ids:='{}'::uuid[]; end if;
 if cardinality(p_sport_ids)<>(select count(distinct x) from unnest(p_sport_ids) x) then return jsonb_build_object('error','duplicate_sports'); end if;
 if exists(select 1 from unnest(p_sport_ids) u(id) left join public.team_sports ts on ts.team_id=l.team_id and ts.sport_id=u.id and ts.enabled left join public.sports sp on sp.id=u.id and sp.active where (ts.sport_id is null or sp.id is null) and not exists(select 1 from public.team_student_sports old where old.team_id=l.team_id and old.student_id=p_student_id and old.sport_id=u.id and old.status in ('pending','approved','correction_requested'))) then return jsonb_build_object('error','sport_unavailable'); end if;
 if l.unique_shirt_number and p_shirt_number is not null and exists(select 1 from public.team_student_details d where d.team_id=l.team_id and d.student_id<>p_student_id and d.shirt_number=p_shirt_number) then return jsonb_build_object('error','duplicate_shirt_number'); end if;
 for v_sport_id in select unnest(p_sport_ids) loop
   if exists(select 1 from public.team_student_sports old where old.team_id=l.team_id and old.student_id=p_student_id and old.sport_id=v_sport_id and old.status in ('pending','approved','correction_requested')) and not exists(select 1 from public.team_sports ts join public.sports sp on sp.id=ts.sport_id and sp.active where ts.team_id=l.team_id and ts.sport_id=v_sport_id and ts.enabled) then continue; end if;
   select sp.* into v_sport from public.sports sp join public.team_sports ts on ts.sport_id=sp.id and ts.team_id=l.team_id and ts.enabled where sp.id=v_sport_id and sp.active;
   v_limit:=case when v_sport.rules->>'max_modalities_per_student' ~ '^[0-9]+$' then (v_sport.rules->>'max_modalities_per_student')::integer else null end;
   if v_limit is not null and cardinality(p_sport_ids)>v_limit then return jsonb_build_object('error','modality_limit'); end if;
 end loop;
 if exists(select 1 from public.team_student_sports ss join public.team_sports ts on ts.team_id=ss.team_id and ts.sport_id=ss.sport_id where ss.team_id=l.team_id and ss.student_id=p_student_id and ss.status='approved' and ts.lock_approved and not(ss.sport_id=any(p_sport_ids))) then return jsonb_build_object('error','approved_sports_locked'); end if;
 select jsonb_build_object('shirt_name',d.shirt_name,'shirt_number',d.shirt_number,'sports',coalesce((select jsonb_agg(jsonb_build_object('sport_id',ss.sport_id,'status',ss.status) order by ss.sport_id) from public.team_student_sports ss where ss.team_id=l.team_id and ss.student_id=p_student_id),'[]'::jsonb)) into v_old from public.team_student_details d where d.team_id=l.team_id and d.student_id=p_student_id;
 insert into public.team_student_details(team_id,student_id,shirt_name,shirt_number,updated_by,updated_at) values(l.team_id,p_student_id,trim(p_shirt_name),p_shirt_number,v_session.representative_user_id,now()) on conflict(team_id,student_id) do update set shirt_name=excluded.shirt_name,shirt_number=excluded.shirt_number,updated_by=coalesce(v_session.representative_user_id,public.team_student_details.updated_by),updated_at=now();
 update public.team_student_sports ss set status='withdrawn',review_note=null,updated_by=coalesce(v_session.representative_user_id,ss.updated_by),updated_at=now() where ss.team_id=l.team_id and ss.student_id=p_student_id and ss.status<>'withdrawn' and not(ss.sport_id=any(p_sport_ids)) and (ss.status<>'approved' or not exists(select 1 from public.team_sports ts where ts.team_id=ss.team_id and ts.sport_id=ss.sport_id and ts.lock_approved));
 foreach v_sport_id in array p_sport_ids loop
   insert into public.team_student_sports(team_id,student_id,sport_id,status,review_note,updated_by,updated_at) values(l.team_id,p_student_id,v_sport_id,'pending',null,v_session.representative_user_id,now())
   on conflict(team_id,student_id,sport_id) do update set status=case when team_student_sports.status='approved' then 'approved' else 'pending' end,review_note=null,updated_by=coalesce(v_session.representative_user_id,team_student_sports.updated_by),updated_at=now();
 end loop;
 select jsonb_build_object('shirt_name',d.shirt_name,'shirt_number',d.shirt_number,'sports',coalesce((select jsonb_agg(jsonb_build_object('sport_id',ss.sport_id,'status',ss.status) order by ss.sport_id) from public.team_student_sports ss where ss.team_id=l.team_id and ss.student_id=p_student_id),'[]'::jsonb)) into v_new from public.team_student_details d where d.team_id=l.team_id and d.student_id=p_student_id;
 insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action,old_data,new_data) values(l.team_id,p_student_id,coalesce(v_session.representative_user_id,auth.uid()),l.id,v_session.id,'student_info_saved',v_old,v_new);
 return jsonb_build_object('ok',true,'message','Informações salvas com sucesso!');
end $$;
revoke all on function public.save_team_student_info(text,uuid,text,integer,uuid[]) from public;
grant execute on function public.save_team_student_info(text,uuid,text,integer,uuid[]) to anon,authenticated;

create or replace function public.admin_team_representative_audit(p_team_id uuid)
returns table(actor_name text,student_name text,action text,changed_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  return query select coalesce(p.display_name,(select concat_ws(' ',rs.first_name,rs.last_name) from public.team_representatives rr join public.students rs on rs.id=rr.student_id where rr.user_id=e.actor_id limit 1),'Acesso por link da equipe'),
    coalesce(concat_ws(' ',s.first_name,s.last_name),'Equipe'),e.action,e.created_at
  from public.team_access_events e
  left join public.profiles p on p.id=e.actor_id
  left join public.students s on s.id=e.student_id
  where e.team_id=p_team_id and e.action in ('student_info_saved','shirt_photo_submitted','shirt_photo_reviewed','representative_activated','representative_account_created')
  order by e.created_at desc limit 50;
end $$;
revoke all on function public.admin_team_representative_audit(uuid) from public;
grant execute on function public.admin_team_representative_audit(uuid) to authenticated;

create or replace function public.validate_team_access_session(p_session_token text)
returns public.team_access_sessions language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions;
begin
  if p_session_token is null or length(p_session_token)<>64 or p_session_token!~'^[0-9a-f]{64}$' then return null; end if;
  select s.* into v_session from public.team_access_sessions s join public.team_access_links l on l.id=s.link_id
  where s.session_hash=encode(digest(p_session_token,'sha256'),'hex') and s.revoked_at is null and s.expires_at>now()
    and ((s.representative_user_id is not null and s.representative_user_id=auth.uid()
       and exists(select 1 from public.team_representatives r where r.user_id=auth.uid() and r.team_id=l.team_id and r.active))
      or (s.representative_user_id is null and l.revoked_at is null and l.expires_at>now()));
  if not found then return null; end if;
  update public.team_access_sessions set last_used_at=now() where id=v_session.id;
  return v_session;
end $$;
revoke all on function public.validate_team_access_session(text) from public;
grant execute on function public.validate_team_access_session(text) to anon,authenticated;

comment on table public.team_representatives is 'Up to two individually authenticated student representatives for each school team.';
comment on table public.team_representative_invites is 'Single-use email-bound invitations for student representative account activation.';

create or replace function public.submit_team_shirt_photo(p_session_token text,p_student_id uuid,p_storage_path text,p_upload_token text)
returns jsonb language plpgsql security definer set search_path=public,storage,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_old_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  if not exists(select 1 from public.team_shirt_upload_tokens u where u.token_hash=encode(digest(p_upload_token,'sha256'),'hex') and u.team_id=v_link.team_id and u.student_id=p_student_id and u.session_id=v_session.id and u.expires_at>now() and u.used_at is null) then return jsonb_build_object('error','invalid_upload_token'); end if;
  if p_storage_path !~ ('^'||v_link.team_id::text||'/'||p_student_id::text||'/'||encode(digest(p_upload_token,'sha256'),'hex')||'\.(jpg|png|webp)$') then return jsonb_build_object('error','invalid_upload_path'); end if;
  if not exists(select 1 from storage.objects o where o.bucket_id='team-shirt-photos' and o.name=p_storage_path and o.metadata->>'team_shirt_upload_token'=p_upload_token) then return jsonb_build_object('error','photo_upload_missing'); end if;
  if not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=v_link.team_id and ts.student_id=p_student_id and ts.left_at is null) then return jsonb_build_object('error','student_unavailable'); end if;
  select shirt_photo_path into v_old_path from public.team_student_details where team_id=v_link.team_id and student_id=p_student_id;
  insert into public.team_student_details(team_id,student_id,shirt_photo_path,shirt_photo_status,shirt_photo_review_note,shirt_photo_submitted_at,shirt_photo_reviewed_at,shirt_photo_reviewed_by,updated_at)
  values(v_link.team_id,p_student_id,p_storage_path,'pending',null,now(),null,null,now()) on conflict(team_id,student_id) do update set shirt_photo_path=excluded.shirt_photo_path,shirt_photo_status='pending',shirt_photo_review_note=null,shirt_photo_submitted_at=now(),shirt_photo_reviewed_at=null,shirt_photo_reviewed_by=null,updated_at=now();
  update public.team_shirt_upload_tokens set used_at=now() where token_hash=encode(digest(p_upload_token,'sha256'),'hex');
  insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action,old_data,new_data)
  values(v_link.team_id,p_student_id,coalesce(v_session.representative_user_id,auth.uid()),v_link.id,v_session.id,'shirt_photo_submitted',jsonb_build_object('path',v_old_path),jsonb_build_object('path',p_storage_path,'status','pending'));
  return jsonb_build_object('ok',true,'message','Imagem da camisa enviada para análise.');
end $$;
revoke all on function public.submit_team_shirt_photo(text,uuid,text,text) from public;
grant execute on function public.submit_team_shirt_photo(text,uuid,text,text) to anon,authenticated;

create or replace function public.start_team_access_session(p_slug text,p_share_secret text)
returns jsonb language plpgsql security definer set search_path=public,extensions set row_security=off as $$
declare v_link public.team_access_links;v_token text;v_session uuid;
begin
 select l.* into v_link from public.team_access_links l join public.teams t on t.id=l.team_id where t.slug=p_slug and t.active and t.deleted_at is null and l.token_hash=encode(digest(p_share_secret,'sha256'),'hex') and l.revoked_at is null and l.expires_at>now() for update;
 if not found then return jsonb_build_object('error','link_unavailable');end if;
 v_token:=encode(gen_random_bytes(32),'hex');
 insert into public.team_access_sessions(link_id,session_hash,expires_at) values(v_link.id,encode(digest(v_token,'sha256'),'hex'),least(v_link.expires_at,now()+interval '8 hours')) returning id into v_session;
 update public.team_access_links set last_used_at=now() where id=v_link.id;
 return jsonb_build_object('session_token',v_token);
end $$;
revoke all on function public.start_team_access_session(text,text) from public;
grant execute on function public.start_team_access_session(text,text) to anon,authenticated;

-- ===== END 202610280017_student_team_representatives.sql =====

-- ===== BEGIN 202610280018_admin_create_representative_accounts.sql =====
-- Secure database half of direct student-representative account provisioning.
-- The Supabase Edge Function creates the Auth user with the service key and
-- calls this RPC only after validating an administrator/organizer session.

create or replace function public.admin_bind_team_representative_account(
  p_team_id uuid,
  p_slot smallint,
  p_student_id uuid,
  p_email text,
  p_user_id uuid,
  p_created_by uuid
) returns jsonb
language plpgsql security definer
set search_path=public,auth,extensions
set row_security=off
as $$
declare
  v_rep public.team_representatives;
  v_student public.students;
  v_email text:=lower(trim(coalesce(p_email,'')));
  v_old_user uuid;
  v_link public.team_access_links;
begin
  if coalesce(auth.role(),'')<>'service_role' then
    raise exception 'This operation is only available to the secured account provisioning service';
  end if;
  if p_slot not in (1,2) then raise exception 'O representante deve ocupar a vaga 1 ou 2'; end if;
  if v_email !~* '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$' then raise exception 'Informe um e-mail pessoal válido'; end if;
  if not exists(select 1 from auth.users u where u.id=p_user_id and lower(u.email)=v_email and u.email_confirmed_at is not null) then
    raise exception 'A conta autenticada não corresponde ao e-mail confirmado';
  end if;
  if not exists(select 1 from public.profiles p where p.id=p_created_by and p.active and p.role in ('administrator','organizer')) then
    raise exception 'A operação exige uma conta administrativa ativa';
  end if;
  if not exists(select 1 from public.teams where id=p_team_id and active and deleted_at is null) then raise exception 'Turma/equipe ativa não encontrada'; end if;
  if not exists(select 1 from public.team_students ts join public.students s on s.id=ts.student_id where ts.team_id=p_team_id and ts.student_id=p_student_id and ts.left_at is null and s.active and s.deleted_at is null) then
    raise exception 'O representante precisa ser aluno ativo desta turma';
  end if;

  perform pg_advisory_xact_lock(hashtext(p_team_id::text));
  select * into v_rep from public.team_representatives where team_id=p_team_id and slot=p_slot for update;
  if found and v_rep.active and v_rep.user_id is not null then raise exception 'Revogue a conta atual desta vaga antes de substituí-la'; end if;
  if exists(select 1 from public.team_representatives r where r.active and lower(r.email)=v_email and (r.team_id,r.slot) is distinct from (p_team_id,p_slot)) then
    raise exception 'Este e-mail já está vinculado a outro representante';
  end if;
  if exists(select 1 from public.team_representatives r where r.team_id=p_team_id and r.active and r.student_id=p_student_id and r.slot<>p_slot) then
    raise exception 'O mesmo aluno não pode ocupar as duas vagas de representante';
  end if;

  if v_rep.id is not null then
    v_old_user:=v_rep.user_id;
    update public.team_access_sessions set revoked_at=now() where representative_user_id=v_old_user and v_old_user is not null and revoked_at is null;
    update public.team_representative_invites set revoked_at=now() where representative_id=v_rep.id and revoked_at is null;
    update public.team_representatives
      set active=false,user_id=null,updated_at=now()
      where id=v_rep.id;
  end if;

  select * into v_link from public.team_access_links where team_id=p_team_id for update;
  if not found then
    insert into public.team_access_links(team_id,token_hash,expires_at,created_by)
    values(p_team_id,encode(digest(gen_random_bytes(32),'sha256'),'hex'),now()+interval '30 days',p_created_by);
  elsif v_link.revoked_at is not null or v_link.expires_at<=now() then
    update public.team_access_links set revoked_at=null,expires_at=now()+interval '30 days',updated_at=now() where id=v_link.id;
  end if;

  insert into public.profiles(id,display_name,role,active)
  select p_user_id,concat_ws(' ',s.first_name,s.last_name),'viewer',true
  from public.students s where s.id=p_student_id
  on conflict(id) do update set display_name=excluded.display_name,active=true
  where public.profiles.role='viewer';
  if not found then raise exception 'Não foi possível criar um perfil de representante sem privilégios'; end if;

  if v_rep.id is null then
    insert into public.team_representatives(team_id,slot,student_id,email,user_id,active,invited_at,accepted_at,created_by)
    values(p_team_id,p_slot,p_student_id,v_email,p_user_id,true,now(),now(),p_created_by);
  else
    update public.team_representatives set student_id=p_student_id,email=v_email,user_id=p_user_id,active=true,invited_at=now(),accepted_at=now(),created_by=p_created_by,updated_at=now()
    where id=v_rep.id;
  end if;

  insert into public.team_access_events(team_id,student_id,actor_id,action,new_data)
  values(p_team_id,p_student_id,p_created_by,'representative_account_created',jsonb_build_object('slot',p_slot,'email',v_email,'user_id',p_user_id));
  return jsonb_build_object('team_id',p_team_id,'student_id',p_student_id,'slot',p_slot,'email',v_email,'user_id',p_user_id);
end $$;
revoke all on function public.admin_bind_team_representative_account(uuid,smallint,uuid,text,uuid,uuid) from public,anon,authenticated;
grant execute on function public.admin_bind_team_representative_account(uuid,smallint,uuid,text,uuid,uuid) to service_role;

comment on function public.admin_bind_team_representative_account(uuid,smallint,uuid,text,uuid,uuid)
is 'Binds an Auth account created by the protected Edge Function to a student representative slot.';

create or replace function public.olient_representative_account_provisioning_is_ready()
returns boolean language sql stable security definer set search_path=pg_catalog as $$
  select to_regprocedure('public.admin_bind_team_representative_account(uuid,smallint,uuid,text,uuid,uuid)') is not null
$$;
revoke all on function public.olient_representative_account_provisioning_is_ready() from public;
grant execute on function public.olient_representative_account_provisioning_is_ready() to anon,authenticated;

create or replace function public.can_manage_team_representatives()
returns boolean language sql stable security definer set search_path=public set row_security=off as $$
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.active and p.role in ('administrator','organizer'))
$$;
revoke all on function public.can_manage_team_representatives() from public;
grant execute on function public.can_manage_team_representatives() to authenticated;

create or replace function public.admin_list_team_representatives(p_team_id uuid)
returns table(slot smallint,student_id uuid,student_name text,email text,status text,accepted_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  return query select r.slot,r.student_id,concat_ws(' ',s.first_name,s.last_name),r.email,
    case when not r.active then 'revoked' when r.user_id is not null then 'active'
      when exists(select 1 from public.team_representative_invites i where i.representative_id=r.id and i.accepted_at is null and i.revoked_at is null and i.expires_at>now()) then 'invite_pending'
      else 'expired' end,
    r.accepted_at
  from public.team_representatives r join public.students s on s.id=r.student_id
  where r.team_id=p_team_id order by r.slot;
end $$;
revoke all on function public.admin_list_team_representatives(uuid) from public;
grant execute on function public.admin_list_team_representatives(uuid) to authenticated;

create or replace function public.admin_revoke_team_representative(p_team_id uuid,p_slot smallint)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_rep_id uuid;v_student_id uuid;v_user_id uuid;
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  select id,student_id,user_id into v_rep_id,v_student_id,v_user_id from public.team_representatives where team_id=p_team_id and slot=p_slot for update;
  if v_rep_id is null then return; end if;
  update public.team_representatives set active=false,user_id=null,updated_at=now() where id=v_rep_id;
  update public.team_representative_invites set revoked_at=now() where representative_id=v_rep_id and accepted_at is null and revoked_at is null;
  update public.team_access_sessions set revoked_at=now() where representative_user_id=v_user_id and v_user_id is not null and revoked_at is null;
  insert into public.team_access_events(team_id,student_id,actor_id,action,new_data)
    values(p_team_id,v_student_id,auth.uid(),'representative_revoked',jsonb_build_object('slot',p_slot));
end $$;
revoke all on function public.admin_revoke_team_representative(uuid,smallint) from public;
grant execute on function public.admin_revoke_team_representative(uuid,smallint) to authenticated;

create or replace function public.admin_team_representative_audit(p_team_id uuid)
returns table(actor_name text,student_name text,action text,changed_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  return query select coalesce(p.display_name,(select concat_ws(' ',rs.first_name,rs.last_name) from public.team_representatives rr join public.students rs on rs.id=rr.student_id where rr.user_id=e.actor_id limit 1),'Acesso por link da equipe'),
    coalesce(concat_ws(' ',s.first_name,s.last_name),'Equipe'),e.action,e.created_at
  from public.team_access_events e left join public.profiles p on p.id=e.actor_id left join public.students s on s.id=e.student_id
  where e.team_id=p_team_id and e.action in ('student_info_saved','shirt_photo_submitted','shirt_photo_reviewed','representative_activated','representative_account_created')
  order by e.created_at desc limit 50;
end $$;
revoke all on function public.admin_team_representative_audit(uuid) from public;
grant execute on function public.admin_team_representative_audit(uuid) to authenticated;

-- ===== END 202610280018_admin_create_representative_accounts.sql =====


-- ===== BEGIN 202610280019_fix_representative_pgcrypto_search_path.sql =====
-- The account-binding RPC uses pgcrypto to create a random team link token.
-- Supabase installs pgcrypto functions in the extensions schema.
alter function public.admin_bind_team_representative_account(uuid,smallint,uuid,text,uuid,uuid)
  set search_path = public, auth, extensions;

-- ===== END 202610280019_fix_representative_pgcrypto_search_path.sql =====


-- ===== BEGIN 202610280020_team_roster_submissions.sql =====
-- Team level submissions: shirt image and the complete shirt-name roster file.
create table if not exists public.team_submissions (
  team_id uuid primary key references public.teams(id) on delete cascade,
  shirt_path text,
  shirt_status text not null default 'not_submitted'
    check (shirt_status in ('not_submitted','pending','approved','correction_requested')),
  shirt_review_note text,
  shirt_submitted_at timestamptz,
  shirt_submitted_by uuid references auth.users(id) on delete set null,
  shirt_reviewed_at timestamptz,
  shirt_reviewed_by uuid references public.profiles(id) on delete set null,
  roster_path text,
  roster_status text not null default 'not_submitted'
    check (roster_status in ('not_submitted','pending','approved','correction_requested')),
  roster_review_note text,
  roster_submitted_at timestamptz,
  roster_submitted_by uuid references auth.users(id) on delete set null,
  roster_reviewed_at timestamptz,
  roster_reviewed_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);
alter table public.team_submissions enable row level security;
revoke all on public.team_submissions from anon, authenticated;
grant select on public.team_submissions to authenticated;
drop policy if exists "admins read team submissions" on public.team_submissions;
create policy "admins read team submissions" on public.team_submissions
  for select to authenticated using (public.is_admin());

create table if not exists public.team_submission_upload_tokens (
  token_hash text primary key,
  team_id uuid not null references public.teams(id) on delete cascade,
  session_id uuid not null references public.team_access_sessions(id) on delete cascade,
  kind text not null check (kind in ('shirt','roster')),
  content_type text not null,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.team_submission_upload_tokens enable row level security;
revoke all on public.team_submission_upload_tokens from anon, authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('team-submissions','team-submissions',false,10485760,array[
  'image/jpeg','image/png','image/webp','application/pdf','text/csv',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
])
on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

create or replace function public.authorize_team_submission_upload(p_name text,p_token text)
returns boolean language plpgsql stable security definer
set search_path=public,storage,extensions set row_security=off as $$
declare v_team uuid; v_kind text; v_hash text;
begin
  if p_name !~ '^[0-9a-fA-F-]{36}/(shirt|roster)/[0-9a-f]{64}\.(jpg|png|webp|pdf|csv|xls|xlsx)$'
     or p_token is null then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid;
  v_kind:=split_part(p_name,'/',2);
  v_hash:=split_part(split_part(p_name,'/',3),'.',1);
  return exists (
    select 1
    from public.team_submission_upload_tokens u
    join public.team_access_sessions s on s.id=u.session_id and s.revoked_at is null and s.expires_at>now()
    join public.team_access_links l on l.id=s.link_id and l.team_id=u.team_id
    where u.token_hash=encode(digest(p_token,'sha256'),'hex')
      and u.team_id=v_team and u.kind=v_kind and u.expires_at>now() and u.used_at is null
      and v_hash=u.token_hash
      and ((s.representative_user_id is not null and s.representative_user_id=auth.uid()
            and exists(select 1 from public.team_representatives r where r.user_id=auth.uid() and r.team_id=l.team_id and r.active))
        or (s.representative_user_id is null and l.revoked_at is null and l.expires_at>now()))
  );
exception when others then return false;
end $$;

create or replace function public.can_read_team_submission(p_name text)
returns boolean language plpgsql stable security definer
set search_path=public,storage set row_security=off as $$
declare v_team uuid;
begin
  if public.is_admin() then return true; end if;
  if p_name !~ '^[0-9a-fA-F-]{36}/(shirt|roster)/[0-9a-f]{64}\.(jpg|png|webp|pdf|csv|xls|xlsx)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid;
  return exists(select 1 from public.team_representatives r
    join public.teams t on t.id=r.team_id and t.active and t.deleted_at is null
    where r.team_id=v_team and r.user_id=auth.uid() and r.active);
exception when others then return false;
end $$;

revoke all on function public.authorize_team_submission_upload(text,text) from public;
revoke all on function public.can_read_team_submission(text) from public;
grant execute on function public.authorize_team_submission_upload(text,text) to anon,authenticated;
grant execute on function public.can_read_team_submission(text) to anon,authenticated;

drop policy if exists "team submissions read" on storage.objects;
drop policy if exists "team submissions upload" on storage.objects;
create policy "team submissions read" on storage.objects for select
  using(bucket_id='team-submissions' and public.can_read_team_submission(name));
create policy "team submissions upload" on storage.objects for insert
  with check(bucket_id='team-submissions' and public.authorize_team_submission_upload(name,metadata->>'team_submission_upload_token'));

create or replace function public.get_team_submission_status(p_session_token text)
returns jsonb language plpgsql security definer
set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_team_id uuid;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select team_id into v_team_id from public.team_access_links where id=v_session.link_id;
  if v_team_id is null then return jsonb_build_object('error','link_unavailable'); end if;
  return coalesce((select jsonb_agg(jsonb_build_object(
      'kind',kind,'status',status,'storage_path',storage_path,'review_note',review_note,'submitted_at',submitted_at)
    order by kind)
    from (
      select 'shirt'::text kind,shirt_status status,shirt_path storage_path,shirt_review_note review_note,shirt_submitted_at submitted_at
      from public.team_submissions where team_id=v_team_id
      union all
      select 'roster',roster_status,roster_path,roster_review_note,roster_submitted_at
      from public.team_submissions where team_id=v_team_id
    ) q), '[]'::jsonb);
end $$;

create or replace function public.create_team_submission_upload_token(p_session_token text,p_kind text,p_content_type text)
returns jsonb language plpgsql security definer
set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_token text; v_extension text; v_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  if p_kind='shirt' and p_content_type not in ('image/jpeg','image/png','image/webp') then
    return jsonb_build_object('error','invalid_shirt_file_type');
  end if;
  if p_kind='roster' and p_content_type not in ('application/pdf','text/csv','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') then
    return jsonb_build_object('error','invalid_roster_file_type');
  end if;
  if p_kind not in ('shirt','roster') then return jsonb_build_object('error','invalid_submission_kind'); end if;
  v_extension:=case p_content_type when 'image/jpeg' then 'jpg' when 'image/png' then 'png' when 'image/webp' then 'webp'
    when 'application/pdf' then 'pdf' when 'application/vnd.ms-excel' then 'xls'
    when 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' then 'xlsx' else 'csv' end;
  v_token:=encode(gen_random_bytes(24),'hex');
  v_path:=v_link.team_id::text||'/'||p_kind||'/'||encode(digest(v_token,'sha256'),'hex')||'.'||v_extension;
  insert into public.team_submission_upload_tokens(token_hash,team_id,session_id,kind,content_type,expires_at)
  values(encode(digest(v_token,'sha256'),'hex'),v_link.team_id,v_session.id,p_kind,p_content_type,now()+interval '10 minutes');
  return jsonb_build_object('upload_token',v_token,'storage_path',v_path,'expires_at',now()+interval '10 minutes');
end $$;

create or replace function public.submit_team_submission(p_session_token text,p_kind text,p_storage_path text,p_upload_token text)
returns jsonb language plpgsql security definer
set search_path=public,storage,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_upload public.team_submission_upload_tokens; v_old_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  select * into v_upload from public.team_submission_upload_tokens
    where token_hash=encode(digest(p_upload_token,'sha256'),'hex') and team_id=v_link.team_id
      and session_id=v_session.id and kind=p_kind and expires_at>now() and used_at is null for update;
  if not found then return jsonb_build_object('error','invalid_upload_token'); end if;
  if p_storage_path !~ ('^'||v_link.team_id::text||'/'||p_kind||'/'||v_upload.token_hash||'\.(jpg|png|webp|pdf|csv|xls|xlsx)$') then
    return jsonb_build_object('error','invalid_upload_path');
  end if;
  if not exists(select 1 from storage.objects where bucket_id='team-submissions' and name=p_storage_path
    and metadata->>'team_submission_upload_token'=p_upload_token) then
    return jsonb_build_object('error','submission_upload_missing');
  end if;
  insert into public.team_submissions(team_id,shirt_path,shirt_status,shirt_review_note,shirt_submitted_at,shirt_submitted_by,
    roster_path,roster_status,roster_review_note,roster_submitted_at,roster_submitted_by,updated_at)
  values(v_link.team_id,
    case when p_kind='shirt' then p_storage_path end,case when p_kind='shirt' then 'pending' else 'not_submitted' end,null,
    case when p_kind='shirt' then now() end,case when p_kind='shirt' then v_session.representative_user_id end,
    case when p_kind='roster' then p_storage_path end,case when p_kind='roster' then 'pending' else 'not_submitted' end,null,
    case when p_kind='roster' then now() end,case when p_kind='roster' then v_session.representative_user_id end,now())
  on conflict(team_id) do update set
    shirt_path=case when p_kind='shirt' then excluded.shirt_path else public.team_submissions.shirt_path end,
    shirt_status=case when p_kind='shirt' then 'pending' else public.team_submissions.shirt_status end,
    shirt_review_note=case when p_kind='shirt' then null else public.team_submissions.shirt_review_note end,
    shirt_submitted_at=case when p_kind='shirt' then now() else public.team_submissions.shirt_submitted_at end,
    shirt_submitted_by=case when p_kind='shirt' then v_session.representative_user_id else public.team_submissions.shirt_submitted_by end,
    shirt_reviewed_at=case when p_kind='shirt' then null else public.team_submissions.shirt_reviewed_at end,
    shirt_reviewed_by=case when p_kind='shirt' then null else public.team_submissions.shirt_reviewed_by end,
    roster_path=case when p_kind='roster' then excluded.roster_path else public.team_submissions.roster_path end,
    roster_status=case when p_kind='roster' then 'pending' else public.team_submissions.roster_status end,
    roster_review_note=case when p_kind='roster' then null else public.team_submissions.roster_review_note end,
    roster_submitted_at=case when p_kind='roster' then now() else public.team_submissions.roster_submitted_at end,
    roster_submitted_by=case when p_kind='roster' then v_session.representative_user_id else public.team_submissions.roster_submitted_by end,
    roster_reviewed_at=case when p_kind='roster' then null else public.team_submissions.roster_reviewed_at end,
    roster_reviewed_by=case when p_kind='roster' then null else public.team_submissions.roster_reviewed_by end,
    updated_at=now();
  update public.team_submission_upload_tokens set used_at=now() where token_hash=v_upload.token_hash;
  insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action,old_data,new_data)
  values(v_link.team_id,null,coalesce(v_session.representative_user_id,auth.uid()),v_link.id,v_session.id,
    case when p_kind='shirt' then 'team_shirt_submitted' else 'team_roster_submitted' end,
    jsonb_build_object('previous_path',v_old_path),jsonb_build_object('path',p_storage_path,'status','pending'));
  return jsonb_build_object('ok',true,'message','Arquivo enviado para aprovação da organização.');
end $$;

create or replace function public.admin_review_team_submission(p_team_id uuid,p_kind text,p_decision text,p_note text default null)
returns void language plpgsql security definer
set search_path=public set row_security=off as $$
declare v_old_status text; v_old_note text;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_kind not in ('shirt','roster') then raise exception 'Tipo de envio inválido'; end if;
  if p_decision not in ('approved','correction_requested') then raise exception 'Decisão inválida'; end if;
  if p_decision='correction_requested' and length(trim(coalesce(p_note,'')))<3 then raise exception 'Informe o motivo da correção'; end if;
  if p_kind='shirt' then
    select shirt_status,shirt_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and shirt_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A foto da camisa não está aguardando aprovação'; end if;
    update public.team_submissions set shirt_status=p_decision,shirt_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,
      shirt_reviewed_at=now(),shirt_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  else
    select roster_status,roster_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and roster_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A lista de nomes não está aguardando aprovação'; end if;
    update public.team_submissions set roster_status=p_decision,roster_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,
      roster_reviewed_at=now(),roster_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  end if;
  insert into public.team_access_events(team_id,student_id,actor_id,action,old_data,new_data)
  values(p_team_id,null,auth.uid(),case when p_kind='shirt' then 'team_shirt_reviewed' else 'team_roster_reviewed' end,
    jsonb_build_object('status',v_old_status,'note',v_old_note),jsonb_build_object('status',p_decision,'note',p_note));
end $$;

-- Include team level uploads in the representative activity log and identify
-- the signed-in student who submitted them.
create or replace function public.admin_team_representative_audit(p_team_id uuid)
returns table(actor_name text,student_name text,action text,changed_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  return query select coalesce(p.display_name,(select concat_ws(' ',rs.first_name,rs.last_name) from public.team_representatives rr join public.students rs on rs.id=rr.student_id where rr.user_id=e.actor_id limit 1),'Acesso por link da equipe'),
    coalesce(concat_ws(' ',s.first_name,s.last_name),'Equipe'),e.action,e.created_at
  from public.team_access_events e left join public.profiles p on p.id=e.actor_id left join public.students s on s.id=e.student_id
  where e.team_id=p_team_id and e.action in ('student_info_saved','shirt_photo_submitted','shirt_photo_reviewed','team_shirt_submitted','team_roster_submitted','team_shirt_reviewed','team_roster_reviewed','representative_activated','representative_account_created')
  order by e.created_at desc limit 50;
end $$;
revoke all on function public.admin_team_representative_audit(uuid) from public;
grant execute on function public.admin_team_representative_audit(uuid) to authenticated;

revoke all on function public.get_team_submission_status(text) from public;
revoke all on function public.create_team_submission_upload_token(text,text,text) from public;
revoke all on function public.submit_team_submission(text,text,text,text) from public;
revoke all on function public.admin_review_team_submission(uuid,text,text,text) from public,anon;
grant execute on function public.get_team_submission_status(text) to anon,authenticated;
grant execute on function public.create_team_submission_upload_token(text,text,text) to anon,authenticated;
grant execute on function public.submit_team_submission(text,text,text,text) to anon,authenticated;
grant execute on function public.admin_review_team_submission(uuid,text,text,text) to authenticated;

-- ===== END 202610280020_team_roster_submissions.sql =====


-- ===== BEGIN 202610280021_fix_team_access_student_details_join.sql =====
-- Fix the missing student-details join used by get_team_access_page.
create or replace function public.get_team_access_page(p_session_token text)
returns jsonb language plpgsql security definer set search_path=public set row_security=off as $$
declare l public.team_access_links; v_session public.team_access_sessions; t public.teams; result jsonb; v_total integer; v_complete integer;
begin
 v_session:=public.validate_team_access_session(p_session_token);
 if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
 select * into l from public.team_access_links where id=v_session.link_id;
 if not found then return jsonb_build_object('error','link_unavailable'); end if;
 if not public.team_access_rate_limit(l.id,null,'read') then return jsonb_build_object('error','rate_limited'); end if;
 update public.team_access_links set last_used_at=now() where id=l.id;
 select * into t from public.teams where id=l.team_id and active and deleted_at is null;
 if not found then return jsonb_build_object('error','link_unavailable'); end if;
 select count(distinct s.id) into v_total from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null where ts.team_id=t.id and ts.left_at is null;
 select count(distinct s.id) into v_complete from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null join public.team_student_details d on d.team_id=ts.team_id and d.student_id=ts.student_id
 where ts.team_id=t.id and ts.left_at is null and nullif(trim(d.shirt_name),'') is not null and (not l.require_shirt_number or d.shirt_number is not null) and exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status in ('pending','approved','correction_requested'));
 select jsonb_build_object(
   'team',jsonb_build_object('name',t.name,'color',t.color,'logo_path',t.logo_path),
   'locked',l.edits_locked,'expires_at',l.expires_at,
   'number_rules',jsonb_build_object('required',l.require_shirt_number,'min',l.shirt_number_min,'max',l.shirt_number_max,'unique',l.unique_shirt_number),
   'progress',jsonb_build_object('complete',v_complete,'total',v_total),
   'sports',coalesce((select jsonb_agg(jsonb_build_object('id',sp.id,'name',sp.name,'category',coalesce(ts.category,sp.category),'lock_approved',ts.lock_approved) order by sp.name) from public.team_sports ts join public.sports sp on sp.id=ts.sport_id and sp.active where ts.team_id=t.id and ts.enabled),'[]'::jsonb),
     'students',coalesce((select jsonb_agg(jsonb_build_object(
      'id',s.id,'first_name',s.first_name,'last_name',s.last_name,'class_name',c.name,
      'shirt_name',d.shirt_name,'shirt_number',d.shirt_number,
      'completion_status',case when d.shirt_name is null or l.require_shirt_number and d.shirt_number is null or not exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status in ('pending','approved','correction_requested')) then 'pending' when exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status='correction_requested') then 'correction_requested' when exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status='pending') then 'awaiting_approval' when not exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status in ('pending','correction_requested')) and exists(select 1 from public.team_student_sports ss where ss.team_id=t.id and ss.student_id=s.id and ss.status='approved') then 'approved' else 'pending' end,
      'sports',coalesce((select jsonb_agg(jsonb_build_object('id',sp.id,'status',ss.status,'selected',ss.status in ('pending','approved','correction_requested'),'enabled',coalesce(ts.enabled,false),'name',sp.name,'review_note',ss.review_note) order by sp.name) from public.team_student_sports ss join public.sports sp on sp.id=ss.sport_id left join public.team_sports ts on ts.team_id=ss.team_id and ts.sport_id=ss.sport_id where ss.team_id=t.id and ss.student_id=s.id),'[]'::jsonb)
    ) order by c.name,s.last_name,s.first_name) from public.team_students ts join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null left join public.classes c on c.id=s.class_id left join public.team_student_details d on d.team_id=ts.team_id and d.student_id=s.id where ts.team_id=t.id and ts.left_at is null),'[]'::jsonb)
 ) into result;
 return result;
end $$;
revoke all on function public.get_team_access_page(text) from public;
grant execute on function public.get_team_access_page(text) to anon,authenticated;
-- Readiness probe used by the client to detect this specific correction.
create or replace function public.olient_team_access_roster_is_ready()
returns boolean language sql stable security definer set search_path=pg_catalog,public as $$
  select coalesce(pg_get_functiondef('public.get_team_access_page(text)'::regprocedure) ilike '%team_student_details d%',false)
$$;
revoke all on function public.olient_team_access_roster_is_ready() from public;
grant execute on function public.olient_team_access_roster_is_ready() to anon,authenticated;
-- ===== END 202610280021_fix_team_access_student_details_join.sql =====



-- ===== BEGIN 202610280022_fix_team_submission_storage_policy.sql =====
-- Storage policies now validate the unguessable path hash against a live upload token
-- and the session's team. This avoids depending on whether Storage puts custom metadata
-- in metadata or user_metadata on a particular Storage deployment.
create or replace function public.authorize_team_submission_upload(p_name text)
returns boolean language plpgsql stable security definer
set search_path=public,storage,extensions set row_security=off as $$
declare v_team uuid; v_kind text; v_hash text;
begin
  if p_name !~ '^[0-9a-fA-F-]{36}/(shirt|roster)/[0-9a-f]{64}\.(jpg|png|webp|pdf|csv|xls|xlsx)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid;
  v_kind:=split_part(p_name,'/',2);
  v_hash:=split_part(split_part(p_name,'/',3),'.',1);
  return exists(
    select 1 from public.team_submission_upload_tokens u
    join public.team_access_sessions s on s.id=u.session_id and s.revoked_at is null and s.expires_at>now()
    join public.team_access_links l on l.id=s.link_id and l.team_id=u.team_id
    where u.token_hash=v_hash and u.team_id=v_team and u.kind=v_kind
      and u.expires_at>now() and u.used_at is null
      and ((s.representative_user_id is not null and s.representative_user_id=auth.uid()
            and exists(select 1 from public.team_representatives r where r.user_id=auth.uid() and r.team_id=l.team_id and r.active))
        or (s.representative_user_id is null and l.revoked_at is null and l.expires_at>now()))
  );
exception when others then return false;
end $$;
revoke all on function public.authorize_team_submission_upload(text) from public;
grant execute on function public.authorize_team_submission_upload(text) to anon,authenticated;

drop policy if exists "team submissions upload" on storage.objects;
create policy "team submissions upload" on storage.objects for insert
  with check(bucket_id='team-submissions' and public.authorize_team_submission_upload(name));
create or replace function public.submit_team_submission(p_session_token text,p_kind text,p_storage_path text,p_upload_token text)
returns jsonb language plpgsql security definer
set search_path=public,storage,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_upload public.team_submission_upload_tokens; v_old_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  select * into v_upload from public.team_submission_upload_tokens
    where token_hash=encode(digest(p_upload_token,'sha256'),'hex') and team_id=v_link.team_id
      and session_id=v_session.id and kind=p_kind and expires_at>now() and used_at is null for update;
  if not found then return jsonb_build_object('error','invalid_upload_token'); end if;
  if p_storage_path !~ ('^'||v_link.team_id::text||'/'||p_kind||'/'||v_upload.token_hash||'\.(jpg|png|webp|pdf|csv|xls|xlsx)$') then
    return jsonb_build_object('error','invalid_upload_path');
  end if;
  if not exists(select 1 from storage.objects where bucket_id='team-submissions' and name=p_storage_path
    ) then
    return jsonb_build_object('error','submission_upload_missing');
  end if;
  insert into public.team_submissions(team_id,shirt_path,shirt_status,shirt_review_note,shirt_submitted_at,shirt_submitted_by,
    roster_path,roster_status,roster_review_note,roster_submitted_at,roster_submitted_by,updated_at)
  values(v_link.team_id,
    case when p_kind='shirt' then p_storage_path end,case when p_kind='shirt' then 'pending' else 'not_submitted' end,null,
    case when p_kind='shirt' then now() end,case when p_kind='shirt' then v_session.representative_user_id end,
    case when p_kind='roster' then p_storage_path end,case when p_kind='roster' then 'pending' else 'not_submitted' end,null,
    case when p_kind='roster' then now() end,case when p_kind='roster' then v_session.representative_user_id end,now())
  on conflict(team_id) do update set
    shirt_path=case when p_kind='shirt' then excluded.shirt_path else public.team_submissions.shirt_path end,
    shirt_status=case when p_kind='shirt' then 'pending' else public.team_submissions.shirt_status end,
    shirt_review_note=case when p_kind='shirt' then null else public.team_submissions.shirt_review_note end,
    shirt_submitted_at=case when p_kind='shirt' then now() else public.team_submissions.shirt_submitted_at end,
    shirt_submitted_by=case when p_kind='shirt' then v_session.representative_user_id else public.team_submissions.shirt_submitted_by end,
    shirt_reviewed_at=case when p_kind='shirt' then null else public.team_submissions.shirt_reviewed_at end,
    shirt_reviewed_by=case when p_kind='shirt' then null else public.team_submissions.shirt_reviewed_by end,
    roster_path=case when p_kind='roster' then excluded.roster_path else public.team_submissions.roster_path end,
    roster_status=case when p_kind='roster' then 'pending' else public.team_submissions.roster_status end,
    roster_review_note=case when p_kind='roster' then null else public.team_submissions.roster_review_note end,
    roster_submitted_at=case when p_kind='roster' then now() else public.team_submissions.roster_submitted_at end,
    roster_submitted_by=case when p_kind='roster' then v_session.representative_user_id else public.team_submissions.roster_submitted_by end,
    roster_reviewed_at=case when p_kind='roster' then null else public.team_submissions.roster_reviewed_at end,
    roster_reviewed_by=case when p_kind='roster' then null else public.team_submissions.roster_reviewed_by end,
    updated_at=now();
  update public.team_submission_upload_tokens set used_at=now() where token_hash=v_upload.token_hash;
  insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action,old_data,new_data)
  values(v_link.team_id,null,coalesce(v_session.representative_user_id,auth.uid()),v_link.id,v_session.id,
    case when p_kind='shirt' then 'team_shirt_submitted' else 'team_roster_submitted' end,
    jsonb_build_object('previous_path',v_old_path),jsonb_build_object('path',p_storage_path,'status','pending'));
  return jsonb_build_object('ok',true,'message','Arquivo enviado para aprovação da organização.');
end $$;

create or replace function public.admin_review_team_submission(p_team_id uuid,p_kind text,p_decision text,p_note text default null)
returns void language plpgsql security definer
set search_path=public set row_security=off as $$
declare v_old_status text; v_old_note text;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_kind not in ('shirt','roster') then raise exception 'Tipo de envio inválido'; end if;
  if p_decision not in ('approved','correction_requested') then raise exception 'Decisão inválida'; end if;
  if p_decision='correction_requested' and length(trim(coalesce(p_note,'')))<3 then raise exception 'Informe o motivo da correção'; end if;
  if p_kind='shirt' then
    select shirt_status,shirt_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and shirt_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A foto da camisa não está aguardando aprovação'; end if;
    update public.team_submissions set shirt_status=p_decision,shirt_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,
      shirt_reviewed_at=now(),shirt_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  else
    select roster_status,roster_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and roster_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A lista de nomes não está aguardando aprovação'; end if;
    update public.team_submissions set roster_status=p_decision,roster_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,
      roster_reviewed_at=now(),roster_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  end if;
  insert into public.team_access_events(team_id,student_id,actor_id,action,old_data,new_data)
  values(p_team_id,null,auth.uid(),case when p_kind='shirt' then 'team_shirt_reviewed' else 'team_roster_reviewed' end,
    jsonb_build_object('status',v_old_status,'note',v_old_note),jsonb_build_object('status',p_decision,'note',p_note));
end $$;

-- Include team level uploads in the representative activity log and identify
-- the signed-in student who submitted them.
create or replace function public.admin_team_representative_audit(p_team_id uuid)
returns table(actor_name text,student_name text,action text,changed_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  return query select coalesce(p.display_name,(select concat_ws(' ',rs.first_name,rs.last_name) from public.team_representatives rr join public.students rs on rs.id=rr.student_id where rr.user_id=e.actor_id limit 1),'Acesso por link da equipe'),
    coalesce(concat_ws(' ',s.first_name,s.last_name),'Equipe'),e.action,e.created_at
  from public.team_access_events e left join public.profiles p on p.id=e.actor_id left join public.students s on s.id=e.student_id
  where e.team_id=p_team_id and e.action in ('student_info_saved','shirt_photo_submitted','shirt_photo_reviewed','team_shirt_submitted','team_roster_submitted','team_shirt_reviewed','team_roster_reviewed','representative_activated','representative_account_created')
  order by e.created_at desc limit 50;
end $$;
revoke all on function public.admin_team_representative_audit(uuid) from public;
grant execute on function public.admin_team_representative_audit(uuid) to authenticated;

revoke all on function public.get_team_submission_status(text) from public;
revoke all on function public.create_team_submission_upload_token(text,text,text) from public;
revoke all on function public.submit_team_submission(text,text,text,text) from public;
revoke all on function public.admin_review_team_submission(uuid,text,text,text) from public,anon;
grant execute on function public.get_team_submission_status(text) to anon,authenticated;
grant execute on function public.create_team_submission_upload_token(text,text,text) to anon,authenticated;
grant execute on function public.submit_team_submission(text,text,text,text) to anon,authenticated;

create or replace function public.olient_team_submission_upload_is_ready()
returns boolean language sql stable security definer set search_path=pg_catalog,public as $$
  select to_regprocedure('public.authorize_team_submission_upload(text)') is not null
    and exists(select 1 from pg_policies where schemaname='storage' and tablename='objects'
      and policyname='team submissions upload' and qual ilike '%authorize_team_submission_upload(name)%')
$$;
revoke all on function public.olient_team_submission_upload_is_ready() from public;
grant execute on function public.olient_team_submission_upload_is_ready() to anon,authenticated;

-- ===== END 202610280022_fix_team_submission_storage_policy.sql =====



-- ===== BEGIN 202610280023_team_flag_submission.sql =====
-- Add team flag artwork to the existing submission and approval flow.
alter table public.team_submissions
  add column if not exists flag_path text,
  add column if not exists flag_status text not null default 'not_submitted'
    check (flag_status in ('not_submitted','pending','approved','correction_requested')),
  add column if not exists flag_review_note text,
  add column if not exists flag_submitted_at timestamptz,
  add column if not exists flag_submitted_by uuid references auth.users(id) on delete set null,
  add column if not exists flag_reviewed_at timestamptz,
  add column if not exists flag_reviewed_by uuid references public.profiles(id) on delete set null;

alter table public.team_submission_upload_tokens
  drop constraint if exists team_submission_upload_tokens_kind_check;
alter table public.team_submission_upload_tokens
  add constraint team_submission_upload_tokens_kind_check check (kind in ('shirt','flag','roster'));

create or replace function public.authorize_team_submission_upload(p_name text)
returns boolean language plpgsql stable security definer
set search_path=public,storage,extensions set row_security=off as $$
declare v_team uuid; v_kind text; v_hash text;
begin
  if p_name !~ '^[0-9a-fA-F-]{36}/(shirt|flag|roster)/[0-9a-f]{64}\.(jpg|png|webp|pdf|csv|xls|xlsx)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid;
  v_kind:=split_part(p_name,'/',2);
  v_hash:=split_part(split_part(p_name,'/',3),'.',1);
  return exists(select 1 from public.team_submission_upload_tokens u
    join public.team_access_sessions s on s.id=u.session_id and s.revoked_at is null and s.expires_at>now()
    join public.team_access_links l on l.id=s.link_id and l.team_id=u.team_id
    where u.token_hash=v_hash and u.team_id=v_team and u.kind=v_kind and u.expires_at>now() and u.used_at is null
      and ((s.representative_user_id is not null and s.representative_user_id=auth.uid()
            and exists(select 1 from public.team_representatives r where r.user_id=auth.uid() and r.team_id=l.team_id and r.active))
        or (s.representative_user_id is null and l.revoked_at is null and l.expires_at>now())));
exception when others then return false;
end $$;

create or replace function public.can_read_team_submission(p_name text)
returns boolean language plpgsql stable security definer
set search_path=public,storage set row_security=off as $$
declare v_team uuid;
begin
  if public.is_admin() then return true; end if;
  if p_name !~ '^[0-9a-fA-F-]{36}/(shirt|flag|roster)/[0-9a-f]{64}\.(jpg|png|webp|pdf|csv|xls|xlsx)$' then return false; end if;
  v_team:=split_part(p_name,'/',1)::uuid;
  return exists(select 1 from public.team_representatives r
    join public.teams t on t.id=r.team_id and t.active and t.deleted_at is null
    where r.team_id=v_team and r.user_id=auth.uid() and r.active);
exception when others then return false;
end $$;

revoke all on function public.authorize_team_submission_upload(text) from public;
revoke all on function public.can_read_team_submission(text) from public;
grant execute on function public.authorize_team_submission_upload(text) to anon,authenticated;
grant execute on function public.can_read_team_submission(text) to anon,authenticated;

drop policy if exists "team submissions upload" on storage.objects;
drop policy if exists "team submissions read" on storage.objects;
create policy "team submissions upload" on storage.objects for insert
  with check(bucket_id='team-submissions' and public.authorize_team_submission_upload(name));
create policy "team submissions read" on storage.objects for select
  using(bucket_id='team-submissions' and public.can_read_team_submission(name));

create or replace function public.get_team_submission_status(p_session_token text)
returns jsonb language plpgsql security definer
set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_team_id uuid;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select team_id into v_team_id from public.team_access_links where id=v_session.link_id;
  if v_team_id is null then return jsonb_build_object('error','link_unavailable'); end if;
  return coalesce((select jsonb_agg(jsonb_build_object('kind',kind,'status',status,'storage_path',storage_path,'review_note',review_note,'submitted_at',submitted_at) order by kind)
    from (
      select 'shirt'::text kind,shirt_status status,shirt_path storage_path,shirt_review_note review_note,shirt_submitted_at submitted_at from public.team_submissions where team_id=v_team_id
      union all
      select 'flag',flag_status,flag_path,flag_review_note,flag_submitted_at from public.team_submissions where team_id=v_team_id
      union all
      select 'roster',roster_status,roster_path,roster_review_note,roster_submitted_at from public.team_submissions where team_id=v_team_id
    ) q),'[]'::jsonb);
end $$;

create or replace function public.create_team_submission_upload_token(p_session_token text,p_kind text,p_content_type text)
returns jsonb language plpgsql security definer
set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_token text; v_extension text; v_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  if p_kind in ('shirt','flag') and p_content_type not in ('image/jpeg','image/png','image/webp') then return jsonb_build_object('error','invalid_image_file_type'); end if;
  if p_kind='roster' and p_content_type not in ('application/pdf','text/csv','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') then return jsonb_build_object('error','invalid_roster_file_type'); end if;
  if p_kind not in ('shirt','flag','roster') then return jsonb_build_object('error','invalid_submission_kind'); end if;
  v_extension:=case p_content_type when 'image/jpeg' then 'jpg' when 'image/png' then 'png' when 'image/webp' then 'webp' when 'application/pdf' then 'pdf' when 'application/vnd.ms-excel' then 'xls' when 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' then 'xlsx' else 'csv' end;
  v_token:=encode(gen_random_bytes(24),'hex');
  v_path:=v_link.team_id::text||'/'||p_kind||'/'||encode(digest(v_token,'sha256'),'hex')||'.'||v_extension;
  insert into public.team_submission_upload_tokens(token_hash,team_id,session_id,kind,content_type,expires_at)
  values(encode(digest(v_token,'sha256'),'hex'),v_link.team_id,v_session.id,p_kind,p_content_type,now()+interval '10 minutes');
  return jsonb_build_object('upload_token',v_token,'storage_path',v_path,'expires_at',now()+interval '10 minutes');
end $$;

create or replace function public.submit_team_submission(p_session_token text,p_kind text,p_storage_path text,p_upload_token text)
returns jsonb language plpgsql security definer
set search_path=public,storage,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_upload public.team_submission_upload_tokens;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  select * into v_upload from public.team_submission_upload_tokens where token_hash=encode(digest(p_upload_token,'sha256'),'hex') and team_id=v_link.team_id and session_id=v_session.id and kind=p_kind and expires_at>now() and used_at is null for update;
  if not found then return jsonb_build_object('error','invalid_upload_token'); end if;
  if p_kind not in ('shirt','flag','roster') or p_storage_path !~ ('^'||v_link.team_id::text||'/'||p_kind||'/'||v_upload.token_hash||'\.(jpg|png|webp|pdf|csv|xls|xlsx)$') then return jsonb_build_object('error','invalid_upload_path'); end if;
  if not exists(select 1 from storage.objects where bucket_id='team-submissions' and name=p_storage_path) then return jsonb_build_object('error','submission_upload_missing'); end if;
  insert into public.team_submissions(team_id) values(v_link.team_id) on conflict(team_id) do nothing;
  update public.team_submissions set
    shirt_path=case when p_kind='shirt' then p_storage_path else shirt_path end,
    shirt_status=case when p_kind='shirt' then 'pending' else shirt_status end,
    shirt_review_note=case when p_kind='shirt' then null else shirt_review_note end,
    shirt_submitted_at=case when p_kind='shirt' then now() else shirt_submitted_at end,
    shirt_submitted_by=case when p_kind='shirt' then v_session.representative_user_id else shirt_submitted_by end,
    shirt_reviewed_at=case when p_kind='shirt' then null else shirt_reviewed_at end,
    shirt_reviewed_by=case when p_kind='shirt' then null else shirt_reviewed_by end,
    flag_path=case when p_kind='flag' then p_storage_path else flag_path end,
    flag_status=case when p_kind='flag' then 'pending' else flag_status end,
    flag_review_note=case when p_kind='flag' then null else flag_review_note end,
    flag_submitted_at=case when p_kind='flag' then now() else flag_submitted_at end,
    flag_submitted_by=case when p_kind='flag' then v_session.representative_user_id else flag_submitted_by end,
    flag_reviewed_at=case when p_kind='flag' then null else flag_reviewed_at end,
    flag_reviewed_by=case when p_kind='flag' then null else flag_reviewed_by end,
    roster_path=case when p_kind='roster' then p_storage_path else roster_path end,
    roster_status=case when p_kind='roster' then 'pending' else roster_status end,
    roster_review_note=case when p_kind='roster' then null else roster_review_note end,
    roster_submitted_at=case when p_kind='roster' then now() else roster_submitted_at end,
    roster_submitted_by=case when p_kind='roster' then v_session.representative_user_id else roster_submitted_by end,
    roster_reviewed_at=case when p_kind='roster' then null else roster_reviewed_at end,
    roster_reviewed_by=case when p_kind='roster' then null else roster_reviewed_by end,
    updated_at=now() where team_id=v_link.team_id;
  update public.team_submission_upload_tokens set used_at=now() where token_hash=v_upload.token_hash;
  insert into public.team_access_events(team_id,student_id,actor_id,link_id,session_id,action,new_data)
  values(v_link.team_id,null,coalesce(v_session.representative_user_id,auth.uid()),v_link.id,v_session.id,
    case p_kind when 'shirt' then 'team_shirt_submitted' when 'flag' then 'team_flag_submitted' else 'team_roster_submitted' end,
    jsonb_build_object('path',p_storage_path,'status','pending'));
  return jsonb_build_object('ok',true,'message','Arquivo enviado para aprovação da organização.');
end $$;

create or replace function public.admin_review_team_submission(p_team_id uuid,p_kind text,p_decision text,p_note text default null)
returns void language plpgsql security definer set search_path=public set row_security=off as $$
declare v_old_status text; v_old_note text;
begin
  if not public.is_admin() then raise exception 'Administrator permission required'; end if;
  if p_kind not in ('shirt','flag','roster') then raise exception 'Tipo de envio inválido'; end if;
  if p_decision not in ('approved','correction_requested') then raise exception 'Decisão inválida'; end if;
  if p_decision='correction_requested' and length(trim(coalesce(p_note,'')))<3 then raise exception 'Informe o motivo da correção'; end if;
  if p_kind='shirt' then
    select shirt_status,shirt_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and shirt_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A foto da camisa não está aguardando aprovação'; end if;
    update public.team_submissions set shirt_status=p_decision,shirt_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,shirt_reviewed_at=now(),shirt_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  elsif p_kind='flag' then
    select flag_status,flag_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and flag_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A foto da bandeira não está aguardando aprovação'; end if;
    update public.team_submissions set flag_status=p_decision,flag_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,flag_reviewed_at=now(),flag_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  else
    select roster_status,roster_review_note into v_old_status,v_old_note from public.team_submissions where team_id=p_team_id and roster_path is not null for update;
    if not found or v_old_status<>'pending' then raise exception 'A lista de nomes não está aguardando aprovação'; end if;
    update public.team_submissions set roster_status=p_decision,roster_review_note=case when p_decision='correction_requested' then left(trim(p_note),1000) end,roster_reviewed_at=now(),roster_reviewed_by=auth.uid(),updated_at=now() where team_id=p_team_id;
  end if;
  insert into public.team_access_events(team_id,student_id,actor_id,action,old_data,new_data)
  values(p_team_id,null,auth.uid(),case p_kind when 'shirt' then 'team_shirt_reviewed' when 'flag' then 'team_flag_reviewed' else 'team_roster_reviewed' end,
    jsonb_build_object('status',v_old_status,'note',v_old_note),jsonb_build_object('status',p_decision,'note',p_note));
end $$;
revoke all on function public.admin_review_team_submission(uuid,text,text,text) from public,anon;
grant execute on function public.admin_review_team_submission(uuid,text,text,text) to authenticated;

create or replace function public.admin_team_representative_audit(p_team_id uuid)
returns table(actor_name text,student_name text,action text,changed_at timestamptz)
language plpgsql stable security definer set search_path=public set row_security=off as $$
begin
  if not public.can_manage_team_representatives() then raise exception 'Administrator permission required'; end if;
  return query select coalesce(p.display_name,(select concat_ws(' ',rs.first_name,rs.last_name) from public.team_representatives rr join public.students rs on rs.id=rr.student_id where rr.user_id=e.actor_id limit 1),'Acesso por link da equipe'),
    coalesce(concat_ws(' ',s.first_name,s.last_name),'Equipe'),e.action,e.created_at
  from public.team_access_events e left join public.profiles p on p.id=e.actor_id left join public.students s on s.id=e.student_id
  where e.team_id=p_team_id and e.action in ('student_info_saved','shirt_photo_submitted','shirt_photo_reviewed','team_shirt_submitted','team_roster_submitted','team_flag_submitted','team_shirt_reviewed','team_roster_reviewed','team_flag_reviewed','representative_activated','representative_account_created')
  order by e.created_at desc limit 50;
end $$;
revoke all on function public.admin_team_representative_audit(uuid) from public;
grant execute on function public.admin_team_representative_audit(uuid) to authenticated;

create or replace function public.olient_team_flag_submission_is_ready()
returns boolean language sql stable security definer set search_path=pg_catalog,public as $$
  select exists(select 1 from information_schema.columns where table_schema='public' and table_name='team_submissions' and column_name='flag_path')
    and exists(select 1 from information_schema.columns where table_schema='public' and table_name='team_submissions' and column_name='flag_status')
$$;
revoke all on function public.olient_team_flag_submission_is_ready() from public;
grant execute on function public.olient_team_flag_submission_is_ready() to anon,authenticated;

-- ===== END 202610280023_team_flag_submission.sql =====



-- ===== BEGIN 202610280024_team_roster_image_upload.sql =====
-- Allow roster submissions as images as well as PDF, spreadsheet, or CSV files.
create or replace function public.create_team_submission_upload_token(p_session_token text,p_kind text,p_content_type text)
returns jsonb language plpgsql security definer
set search_path=public,extensions set row_security=off as $$
declare v_session public.team_access_sessions; v_link public.team_access_links; v_token text; v_extension text; v_path text;
begin
  v_session:=public.validate_team_access_session(p_session_token);
  if v_session.id is null then return jsonb_build_object('error','session_expired'); end if;
  select * into v_link from public.team_access_links where id=v_session.link_id;
  if not found then return jsonb_build_object('error','link_unavailable'); end if;
  if v_link.edits_locked then return jsonb_build_object('error','edits_locked'); end if;
  if p_kind in ('shirt','flag') and p_content_type not in ('image/jpeg','image/png','image/webp') then
    return jsonb_build_object('error','invalid_image_file_type');
  end if;
  if p_kind='roster' and p_content_type not in (
    'application/pdf','text/csv','application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'image/jpeg','image/png','image/webp'
  ) then return jsonb_build_object('error','invalid_roster_file_type'); end if;
  if p_kind not in ('shirt','flag','roster') then return jsonb_build_object('error','invalid_submission_kind'); end if;
  v_extension:=case p_content_type
    when 'image/jpeg' then 'jpg'
    when 'image/png' then 'png'
    when 'image/webp' then 'webp'
    when 'application/pdf' then 'pdf'
    when 'application/vnd.ms-excel' then 'xls'
    when 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' then 'xlsx'
    else 'csv' end;
  v_token:=encode(gen_random_bytes(24),'hex');
  v_path:=v_link.team_id::text||'/'||p_kind||'/'||encode(digest(v_token,'sha256'),'hex')||'.'||v_extension;
  insert into public.team_submission_upload_tokens(token_hash,team_id,session_id,kind,content_type,expires_at)
  values(encode(digest(v_token,'sha256'),'hex'),v_link.team_id,v_session.id,p_kind,p_content_type,now()+interval '10 minutes');
  return jsonb_build_object('upload_token',v_token,'storage_path',v_path,'expires_at',now()+interval '10 minutes');
end $$;

revoke all on function public.create_team_submission_upload_token(text,text,text) from public;
grant execute on function public.create_team_submission_upload_token(text,text,text) to anon,authenticated;

create or replace function public.olient_roster_image_upload_is_ready()
returns boolean language sql stable security definer set search_path=pg_catalog,public as $$
  select position('image/png' in pg_get_functiondef('public.create_team_submission_upload_token(text,text,text)'::regprocedure))>0
    and exists(select 1 from storage.buckets where id='team-submissions' and allowed_mime_types @> array['image/png','image/jpeg']::text[])
$$;
revoke all on function public.olient_roster_image_upload_is_ready() from public;
grant execute on function public.olient_roster_image_upload_is_ready() to anon,authenticated;

-- ===== END 202610280024_team_roster_image_upload.sql =====
