-- Remove alunos, turmas e os dados diretamente vinculados a eles.
-- Preserva equipes, modalidades, partidas, gincana, pontuações e contas administrativas.
-- Antes de executar: apague os arquivos do bucket Storage "team-shirt-photos".
-- Execute o conteúdo inteiro como um único comando no SQL Editor.

do $olient$
declare
  v_student_ids uuid[];
  v_representative_user_ids uuid[];
begin
  select coalesce(array_agg(id), array[]::uuid[])
    into v_student_ids
  from public.students;

  select coalesce(array_agg(distinct user_id), array[]::uuid[])
    into v_representative_user_ids
  from public.team_representatives
  where user_id is not null;

  delete from public.team_access_events
  where student_id = any(v_student_ids)
     or actor_id = any(v_representative_user_ids);

  delete from public.team_access_requests
  where student_id = any(v_student_ids);

  delete from public.team_access_sessions
  where representative_user_id = any(v_representative_user_ids);

  delete from public.team_representatives
  where student_id = any(v_student_ids)
     or user_id = any(v_representative_user_ids);

  delete from auth.users
  where id = any(v_representative_user_ids);

  delete from public.team_student_sports
  where student_id = any(v_student_ids);

  delete from public.team_student_details
  where student_id = any(v_student_ids);

  delete from public.team_students
  where student_id = any(v_student_ids);

  delete from public.students
  where id = any(v_student_ids);

  delete from public.classes;
end;
$olient$;
