-- Dados de teste para fichas de alunos das turmas ativas.
-- Reexecutável: preserva dados preenchidos e não cria resultados nem pontuação.
-- O bloco DO é atômico e não depende de tabelas temporárias entre comandos.

do $olient_demo$
declare
  r record;
  v_slot integer;
  v_student_id uuid;
  v_code text;
begin
  for r in
    with class_team_map as (
      select c.id as class_id,c.name as class_name,
        coalesce((select active_team.id from public.teams active_team where active_team.id=tc.team_id and active_team.active and active_team.deleted_at is null),(
          select t.id from public.teams t
          where t.active and t.deleted_at is null
            and public.olient_normalize_name(t.name)=public.olient_normalize_name(c.name)
          order by t.created_at,t.id limit 1
        )) as team_id
      from public.classes c
      left join public.team_classes tc on tc.class_id=c.id
      where c.active
    )
    select * from class_team_map where team_id is not null order by class_name
  loop
    -- Vincula alunos já cadastrados pela turma; não cria vínculo duplicado.
    insert into public.team_students(team_id,student_id)
    select r.team_id,s.id
    from public.students s
    where s.class_id=r.class_id and s.active and s.deleted_at is null
      and not exists(select 1 from public.team_students ts where ts.student_id=s.id and ts.left_at is null)
    on conflict(team_id,student_id,joined_at) do nothing;

    -- Se a turma estiver realmente vazia, cria dois alunos claramente identificados como teste.
    if not exists(
      select 1 from public.team_students ts
      join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null
      where ts.team_id=r.team_id and ts.left_at is null
    ) then
      for v_slot in 1..2 loop
        v_code:='DEMO-OLIENT-'||left(replace(r.class_id::text,'-',''),10)||'-'||lpad(v_slot::text,2,'0');
        insert into public.students(class_id,first_name,last_name,student_code)
        values(r.class_id,'Teste '||left(r.class_name,24),'Aluno '||lpad(v_slot::text,2,'0'),v_code)
        on conflict(student_code) do nothing;
        select s.id into v_student_id from public.students s where s.student_code=v_code and s.active and s.deleted_at is null;
        if v_student_id is not null then
          insert into public.team_students(team_id,student_id)
          values(r.team_id,v_student_id)
          on conflict(team_id,student_id,joined_at) do nothing;
        end if;
        v_student_id:=null;
      end loop;
    end if;

    -- Preenche nomes na camisa e números ainda vazios, respeitando o intervalo da equipe.
    with team_rules as (
      select greatest(coalesce(l.shirt_number_min,1),1) as number_min,
        least(coalesce(l.shirt_number_max,99),99) as number_max
      from public.teams t left join public.team_access_links l on l.team_id=t.id
      where t.id=r.team_id
    ), active_members as (
      select distinct on (ts.team_id,ts.student_id) ts.team_id,ts.student_id
      from public.team_students ts
      join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null
      where ts.team_id=r.team_id and ts.left_at is null
      order by ts.team_id,ts.student_id,ts.joined_at desc
    ), free_numbers as (
      select n.number_value,row_number() over(order by n.number_value) as free_order
      from team_rules rules
      cross join lateral generate_series(rules.number_min,rules.number_max) as n(number_value)
      where not exists(select 1 from public.team_student_details d where d.team_id=r.team_id and d.shirt_number=n.number_value)
    ), students_needing_numbers as (
      select m.student_id,row_number() over(order by s.last_name,s.first_name,s.id) as missing_order
      from active_members m
      join public.students s on s.id=m.student_id
      left join public.team_student_details d on d.team_id=m.team_id and d.student_id=m.student_id
      where d.shirt_number is null
    ), number_assignments as (
      select s.student_id,f.number_value as shirt_number
      from students_needing_numbers s join free_numbers f on f.free_order=s.missing_order
    )
    insert into public.team_student_details as stored_detail(team_id,student_id,shirt_name,shirt_number,updated_at)
    select m.team_id,m.student_id,left(trim(s.first_name),30),a.shirt_number,now()
    from active_members m
    join public.students s on s.id=m.student_id
    left join public.team_student_details current_detail on current_detail.team_id=m.team_id and current_detail.student_id=m.student_id
    left join number_assignments a on a.student_id=m.student_id
    where current_detail.student_id is null or nullif(trim(current_detail.shirt_name),'') is null or current_detail.shirt_number is null
    on conflict(team_id,student_id) do update set
      shirt_name=coalesce(nullif(trim(stored_detail.shirt_name),''),excluded.shirt_name),
      shirt_number=coalesce(stored_detail.shirt_number,excluded.shirt_number),
      updated_at=now();

    -- Distribui até duas modalidades ativas por aluno sem inscrição atual.
    -- Novas inscrições ficam pendentes, nunca aprovadas automaticamente.
    with active_sports as (
      select ts.team_id,ts.sport_id,
        row_number() over(order by s.name,s.id) as sport_order,
        count(*) over() as sport_count
      from public.team_sports ts
      join public.sports s on s.id=ts.sport_id and s.active and s.status='active'
      where ts.team_id=r.team_id and ts.enabled
    ), active_members as (
      select distinct on (ts.team_id,ts.student_id) ts.team_id,ts.student_id
      from public.team_students ts
      join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null
      where ts.team_id=r.team_id and ts.left_at is null
      order by ts.team_id,ts.student_id,ts.joined_at desc
    ), students_needing_sports as (
      select m.team_id,m.student_id,
        row_number() over(order by s.last_name,s.first_name,s.id) as student_order
      from active_members m
      join public.students s on s.id=m.student_id
      where not exists(
        select 1 from public.team_student_sports existing
        where existing.team_id=m.team_id and existing.student_id=m.student_id
          and existing.status in ('pending','approved','correction_requested')
      )
    ), sport_positions as (
      select n.team_id,n.student_id,
        ((n.student_order-1)*2 % max(a.sport_count))+1 as first_order,
        case when max(a.sport_count)>1 then (((n.student_order-1)*2+1) % max(a.sport_count))+1 end as second_order
      from students_needing_sports n join active_sports a on a.team_id=n.team_id
      group by n.team_id,n.student_id,n.student_order
    ), selected_positions as (
      select p.team_id,p.student_id,v.sport_order
      from sport_positions p
      cross join lateral (values(p.first_order),(p.second_order)) as v(sport_order)
      where v.sport_order is not null
    )
    insert into public.team_student_sports as existing(team_id,student_id,sport_id,status,review_note,updated_at)
    select p.team_id,p.student_id,a.sport_id,'pending',null,now()
    from selected_positions p join active_sports a on a.team_id=p.team_id and a.sport_order=p.sport_order
    on conflict(team_id,student_id,sport_id) do update set
      status='pending',review_note=null,updated_by=null,updated_at=now()
    where existing.status in ('withdrawn','rejected');
  end loop;
end
$olient_demo$;

-- Resumo pós-execução; pode ser executado separadamente do bloco acima.
with class_team_map as (
  select c.id as class_id,c.name as class_name,
    coalesce((select active_team.id from public.teams active_team where active_team.id=tc.team_id and active_team.active and active_team.deleted_at is null),(
      select t.id from public.teams t
      where t.active and t.deleted_at is null
        and public.olient_normalize_name(t.name)=public.olient_normalize_name(c.name)
      order by t.created_at,t.id limit 1
    )) as team_id
  from public.classes c left join public.team_classes tc on tc.class_id=c.id
  where c.active
), active_members as (
  select distinct ts.team_id,ts.student_id
  from public.team_students ts
  join public.teams t on t.id=ts.team_id and t.active and t.deleted_at is null
  join public.students s on s.id=ts.student_id and s.active and s.deleted_at is null
  where ts.left_at is null
)
select
  (select count(distinct team_id) from active_members) as turmas_com_alunos,
  (select count(*) from active_members) as alunos_vinculados,
  (select count(*) from active_members m join public.team_student_details d on d.team_id=m.team_id and d.student_id=m.student_id where nullif(trim(d.shirt_name),'') is not null and d.shirt_number is not null) as fichas_com_nome_e_numero,
  (select count(*) from active_members m join public.team_student_sports ss on ss.team_id=m.team_id and ss.student_id=m.student_id and ss.status in ('pending','approved','correction_requested')) as inscricoes_ativas,
  (select count(*) from public.students s where s.student_code like 'DEMO-OLIENT-%' and s.active and s.deleted_at is null) as alunos_teste_identificados,
  (select string_agg(class_name,', ' order by class_name) from class_team_map where team_id is null) as turmas_sem_equipe_associada,
  (select string_agg(t.name,', ' order by t.name) from public.teams t where t.active and t.deleted_at is null and not exists(select 1 from active_members m where m.team_id=t.id)) as equipes_sem_alunos;

