import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (request.method !== 'POST') return response({ error: 'Método não permitido' }, 405);

  const authorization = request.headers.get('Authorization');
  const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return response({ error: 'Entre com uma conta administrativa para continuar' }, 401);

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !anonKey || !serviceRoleKey) return response({ error: 'A função de criação de contas não está configurada no servidor' }, 503);

  const callerClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const serviceClient = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: callerData, error: callerError } = await callerClient.auth.getUser(token);
  if (callerError || !callerData.user) return response({ error: 'Sessão inválida ou expirada' }, 401);

  const { data: profile, error: profileError } = await serviceClient
    .from('profiles')
    .select('role,active')
    .eq('id', callerData.user.id)
    .maybeSingle();
  if (profileError) return response({ error: 'Não foi possível verificar as permissões da conta' }, 500);
  if (!profile?.active || !['administrator', 'organizer'].includes(profile.role)) {
    return response({ error: 'Somente administradores e organizadores podem criar contas de representantes' }, 403);
  }

  let body: { team_id?: unknown; slot?: unknown; student_id?: unknown; email?: unknown; password?: unknown };
  try {
    body = await request.json();
  } catch {
    return response({ error: 'Dados de criação inválidos' }, 400);
  }

  const teamId = typeof body.team_id === 'string' ? body.team_id : '';
  const studentId = typeof body.student_id === 'string' ? body.student_id : '';
  const slot = Number(body.slot);
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  const password = typeof body.password === 'string' ? body.password : '';
  const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  if (!uuidPattern.test(teamId) || !uuidPattern.test(studentId) || ![1, 2].includes(slot)) {
    return response({ error: 'Selecione uma turma, aluno e vaga válidos' }, 400);
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return response({ error: 'Informe um e-mail pessoal válido' }, 400);
  if (password.length < 8 || password.length > 128) return response({ error: 'A senha deve ter entre 8 e 128 caracteres' }, 400);

  const { data: teamMember, error: memberError } = await serviceClient
    .from('team_students')
    .select('student_id,students!inner(active,deleted_at)')
    .eq('team_id', teamId)
    .eq('student_id', studentId)
    .is('left_at', null)
    .maybeSingle();
  if (memberError) return response({ error: 'Não foi possível verificar a matrícula do estudante' }, 500);
  if (!teamMember || !teamMember.students?.active || teamMember.students?.deleted_at) {
    return response({ error: 'O representante precisa ser um aluno ativo desta turma' }, 400);
  }

  const { data: team } = await serviceClient.from('teams').select('id').eq('id', teamId).eq('active', true).is('deleted_at', null).maybeSingle();
  if (!team) return response({ error: 'Turma/equipe ativa não encontrada' }, 400);

  const { data: currentSlot, error: slotError } = await serviceClient
    .from('team_representatives')
    .select('id,user_id,active')
    .eq('team_id', teamId)
    .eq('slot', slot)
    .maybeSingle();
  if (slotError) return response({ error: 'Não foi possível verificar esta vaga de representante' }, 500);
  if (currentSlot?.active && currentSlot.user_id) return response({ error: 'Revogue a conta atual desta vaga antes de substituí-la' }, 409);

  const { data: sameStudent } = await serviceClient
    .from('team_representatives')
    .select('id')
    .eq('team_id', teamId)
    .eq('student_id', studentId)
    .eq('active', true)
    .neq('slot', slot)
    .maybeSingle();
  if (sameStudent) return response({ error: 'O mesmo aluno não pode ocupar as duas vagas de representante' }, 409);

  const { data: sameEmail } = await serviceClient
    .from('team_representatives')
    .select('id')
    .eq('email', email)
    .eq('active', true)
    .neq('id', currentSlot?.id ?? '00000000-0000-0000-0000-000000000000')
    .maybeSingle();
  if (sameEmail) return response({ error: 'Este e-mail já está vinculado a outro representante' }, 409);

  const { data: authUser, error: createError } = await serviceClient.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    app_metadata: { account_type: 'team_representative' },
  });
  if (createError || !authUser.user) {
    const message = createError?.message ?? 'Não foi possível criar a conta do estudante';
    const isDuplicate = /already|registered|exists|duplicate/i.test(message);
    return response({ error: isDuplicate ? 'Este e-mail já tem uma conta no sistema. Use um e-mail diferente.' : message }, isDuplicate ? 409 : 400);
  }

  const { data: binding, error: bindError } = await serviceClient.rpc('admin_bind_team_representative_account', {
    p_team_id: teamId,
    p_slot: slot,
    p_student_id: studentId,
    p_email: email,
    p_user_id: authUser.user.id,
    p_created_by: callerData.user.id,
  });
  if (bindError) {
    await serviceClient.auth.admin.deleteUser(authUser.user.id);
    const conflict = /vinculado|duas vagas|substituí-la|representante/i.test(bindError.message);
    return response({ error: bindError.message }, conflict ? 409 : 400);
  }

  return response({ ok: true, representative: binding });
});
