-- OLIENT 2027: dados fictícios para ambiente de desenvolvimento/teste.
-- Execute somente em um projeto Supabase isolado de produção, após aplicar as migrations.
-- Os estudantes e equipes abaixo são demonstrativos, não representam pessoas ou inscrições reais.

begin;

insert into public.classes (name, grade)
values
  ('6°A', '6º ano'), ('6°B', '6º ano'), ('6°F', '6º ano'),
  ('7°A', '7º ano'), ('7°B', '7º ano'), ('7°F', '7º ano'),
  ('8°A', '8º ano'), ('8°B', '8º ano'), ('8°F', '8º ano'),
  ('9°A', '9º ano'),
  ('1°L', '1º ano do Ensino Médio'), ('2°L', '2º ano do Ensino Médio'), ('3°L', '3º ano do Ensino Médio')
on conflict (name) do nothing;

insert into public.teams (name, color)
select 'TESTE · Turma ' || c.name,
       case when row_number() over (order by c.name) % 2 = 0 then '#F5C542' else '#174A8B' end
from public.classes c
where c.name in ('6°A','6°B','6°F','7°A','7°B','7°F','8°A','8°B','8°F','9°A','1°L','2°L','3°L')
on conflict (name) do nothing;

insert into public.students (class_id, first_name, last_name, student_code)
select c.id, 'Aluno', 'Teste ' || replace(replace(c.name, '°', ''), 'º', ''), 'DEMO-' || replace(replace(c.name, '°', ''), 'º', '')
from public.classes c
where c.name in ('6°A','6°B','6°F','7°A','7°B','7°F','8°A','8°B','8°F','9°A','1°L','2°L','3°L')
on conflict (student_code) do update
set class_id = excluded.class_id,
    first_name = excluded.first_name,
    last_name = excluded.last_name,
    active = true,
    deleted_at = null;

insert into public.team_students (team_id, student_id)
select t.id, s.id
from public.classes c
join public.teams t on t.name = 'TESTE · Turma ' || c.name
join public.students s on s.class_id = c.id and s.student_code = 'DEMO-' || replace(replace(c.name, '°', ''), 'º', '')
where not exists (
  select 1 from public.team_students ts
  where ts.team_id = t.id and ts.student_id = s.id and ts.left_at is null
);

insert into public.sports (name, description, status, category)
values
  ('TESTE · Futsal', 'Modalidade demonstrativa para validação do ambiente.', 'active', 'Teste'),
  ('TESTE · Vôlei', 'Modalidade demonstrativa para validação do ambiente.', 'active', 'Teste'),
  ('TESTE · Basquete 3x3', 'Modalidade demonstrativa para validação do ambiente.', 'active', 'Teste'),
  ('TESTE · Tênis de mesa', 'Modalidade demonstrativa para validação do ambiente.', 'active', 'Teste')
on conflict (name) do update
set description = excluded.description,
    status = excluded.status,
    category = excluded.category,
    active = true;

insert into public.registrations (team_id, sport_id, category, status)
select t.id, s.id, 'Teste', 'approved'
from public.teams t
cross join public.sports s
where t.name like 'TESTE · Turma %'
  and s.name in ('TESTE · Futsal','TESTE · Vôlei','TESTE · Basquete 3x3','TESTE · Tênis de mesa')
on conflict (team_id, sport_id, category) do update
set status = 'approved';

commit;
