-- Limpa alunos, turmas, dados esportivos por aluno e contas de representantes.
-- Mantém: equipes, modalidades, partidas, gincana, pontuações e contas administrativas.
-- Antes de executar: em Storage > team-shirt-photos, apague os arquivos do bucket,
-- pois arquivos de Storage não devem ser removidos apagando storage.objects via SQL.

begin;

create temporary table _olient_reset_student_ids on commit drop as
select id from public.students;

create temporary table _olient_reset_representative_user_ids on commit drop as
select distinct user_id as id
from public.team_representatives
where user_id is not null;

-- Remover auditoria e sessões ligadas aos alunos/contas antigas.
delete from public.team_access_events
where student_id in (select id from _olient_reset_student_ids)
   or actor_id in (select id from _olient_reset_representative_user_ids);

delete from public.team_access_requests
where student_id in (select id from _olient_reset_student_ids);

delete from public.team_access_sessions
where representative_user_id in (select id from _olient_reset_representative_user_ids);

-- Convites são removidos em cascata ao apagar os representantes.
delete from public.team_representatives
where student_id in (select id from _olient_reset_student_ids)
   or user_id in (select id from _olient_reset_representative_user_ids);

-- Apagar apenas contas Auth referenciadas como contas de representantes.
delete from auth.users
where id in (select id from _olient_reset_representative_user_ids);

delete from public.team_student_sports
where student_id in (select id from _olient_reset_student_ids);

delete from public.team_student_details
where student_id in (select id from _olient_reset_student_ids);

delete from public.team_students
where student_id in (select id from _olient_reset_student_ids);

delete from public.students
where id in (select id from _olient_reset_student_ids);

-- team_classes é removida em cascata; equipes correspondentes permanecem.
delete from public.classes;

commit;
