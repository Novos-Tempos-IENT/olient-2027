Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @"
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections.Generic;
public static class LogoCutout {
 public static void Run(string source,string target) {
  using(var original=new Bitmap(source)) using(var image=new Bitmap(original.Width,original.Height,PixelFormat.Format32bppArgb)) {
   using(var g=Graphics.FromImage(image)) g.DrawImageUnscaled(original,0,0);
   int w=image.Width,h=image.Height;
   var lefts=new int[h]; var rights=new int[h];
   for(int y=0;y<h;y++) {
    lefts[y]=w;rights[y]=-1;
    for(int x=0;x<w;x++){var c=original.GetPixel(x,y);if(c.R<245||c.G<245||c.B<245){lefts[y]=Math.Min(lefts[y],x);rights[y]=x;}}
   }
   int border=16;
   for(int y=0;y<h;y++) {
    int left=w,right=-1;
    for(int dy=-border;dy<=border;dy++) {int yy=y+dy;if(yy<0||yy>=h||rights[yy]<0)continue;int dx=(int)Math.Sqrt(border*border-dy*dy);left=Math.Min(left,lefts[yy]-dx);right=Math.Max(right,rights[yy]+dx);}
    for(int x=0;x<w;x++){var c=original.GetPixel(x,y);image.SetPixel(x,y,(x<left||x>right)?Color.FromArgb(0,c.R,c.G,c.B):c);}
   }
   image.Save(target,ImageFormat.Png);
  }
 }
}
"@
[LogoCutout]::Run((Join-Path $PWD 'public/logo-novos-tempos.png'),(Join-Path $PWD 'public/logo-novos-tempos-transparente.png'))


