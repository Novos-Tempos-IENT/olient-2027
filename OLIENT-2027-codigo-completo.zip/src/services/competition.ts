import { supabase } from '../lib/supabase';
import type { SchoolClass, Sport, Standing, Student, Team } from '../types/database';

export async function getClasses(): Promise<SchoolClass[]> {
  if (!supabase) throw new Error('Configure o Supabase para consultar turmas.');
  const { data, error } = await supabase.from('classes').select('*').eq('active', true).order('name');
  if (error) throw error;
  return uniqueClasses(data ?? []);
}
export function uniqueClasses<T extends Pick<SchoolClass, 'name'>>(rows: T[]): T[] {
  const normalize = (name: string) => name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[º°ª]/g, '').trim().replace(/\s+/g, ' ').toLocaleLowerCase('pt-BR');
  const preferred = (name: string) => /[º°ª]/.test(name) ? 1 : 0;
  const byName = new Map<string, T>();
  for (const row of rows) {
    const key = normalize(row.name);
    const current = byName.get(key);
    if (!current || preferred(row.name) > preferred(current.name)) byName.set(key, row);
  }
  return [...byName.values()].sort((a, b) => a.name.localeCompare(b.name, 'pt-BR', { numeric: true }));
}
export async function getStudents(): Promise<Student[]> {
  if (!supabase) throw new Error('Configure o Supabase para consultar alunos.');
  const { data, error } = await supabase.from('students').select('*').is('deleted_at', null).order('last_name').order('first_name');
  if (error) throw error;
  return data ?? [];
}
export async function createClass(name: string, grade: string, shift: string) {
  if (!supabase) throw new Error('Configure o Supabase para cadastrar turmas.');
  const { error } = await supabase.from('classes').insert({ name, grade: grade || null, shift: shift || null });
  if (error) throw error;
}
export async function createStudent(classId: string, firstName: string, lastName: string, studentCode: string) {
  if (!supabase) throw new Error('Configure o Supabase para cadastrar alunos.');
  const { error } = await supabase.from('students').insert({ class_id: classId || null, first_name: firstName, last_name: lastName, student_code: studentCode || null });
  if (error) throw error;
}

export async function getStandings(): Promise<Standing[]> {
  if (!supabase) return [];
  const { data, error } = await supabase.from('public_standings').select('*').order('place');
  if (error) throw error;
  return data ?? [];
}
export async function getTeams(): Promise<Team[]> {
  if (!supabase) return [];
  const { data, error } = await supabase.from('teams').select('*').eq('active', true).order('name');
  if (error) throw error;
  return data ?? [];
}
export async function getSports(): Promise<Sport[]> {
  if (!supabase) return [];
  const { data, error } = await supabase.from('sports').select('*').order('name');
  if (error) throw error;
  return data ?? [];
}
export async function createTeam(name: string, color: string) {
  if (!supabase) throw new Error('Configure o Supabase para cadastrar equipes.');
  const { error } = await supabase.rpc('create_team_with_slug', { p_name: name, p_color: color || null });
  if (error) throw error;
}
export async function createClassTeam(name: string, grade: string, shift: string) {
  if (!supabase) throw new Error('Configure o Supabase para cadastrar turmas.');
  const { error } = await supabase.rpc('admin_create_class_group', { p_name: name, p_grade: grade || null, p_shift: shift || null });
  if (error) throw error;
}
export async function createSport(name: string, category: string) {
  if (!supabase) throw new Error('Configure o Supabase para cadastrar modalidades.');
  const { error } = await supabase.from('sports').insert({ name, category });
  if (error) throw error;
}
export async function signIn(email: string, password: string) {
  if (!supabase) throw new Error('Configure as variáveis de ambiente do Supabase.');
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
}
export async function sendPasswordReset(email: string) {
  if (!supabase) throw new Error('Configure as variáveis de ambiente do Supabase.');
  const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });
  if (error) throw error;
}
export async function signOut() { if (supabase) await supabase.auth.signOut(); }
