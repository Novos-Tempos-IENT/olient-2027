import { supabase } from '../lib/supabase';

const migrationNames = {
  schedule: '202610270007_multi_sport_schedule.sql',
  gincana: '202610270008_gincana_program.sql',
  placements: '202610270009_sports_placement_points.sql',
  awards: '202610270010_gincana_auto_results_and_totals.sql',
  points: '202610270011_gincana_item_points.sql',
  scores: '202610270012_gincana_item_scores.sql',
  availability: '202610270013_court_availability_management.sql',
  shirt: '202610270014_team_shirt_photo_review.sql',
  reschedule: '202610280015_official_bulletin_and_rescheduling.sql',
  realtime: '202610280016_enable_realtime_sync.sql',
  representatives: '202610280017_student_team_representatives.sql',
  representativeAccounts: '202610280018_admin_create_representative_accounts.sql',
  teamSubmissions: '202610280020_team_roster_submissions.sql',
  teamAccessJoin: '202610280021_fix_team_access_student_details_join.sql',
  storageUpload: '202610280022_fix_team_submission_storage_policy.sql',
  teamFlagSubmission: '202610280023_team_flag_submission.sql',
  rosterImageUpload: '202610280024_team_roster_image_upload.sql',
} as const;
let cachedMissing: string[] | null = null;
let checkedAt = 0;

export async function getMissingSupabaseMigrations(): Promise<string[]> {
  const client = supabase;
  if (!client) return [];
  if (cachedMissing && Date.now() - checkedAt < 30_000) return cachedMissing;
  const checks = [
    [migrationNames.schedule, async () => client.from('schedule_batches').select('id').limit(0)],
    [migrationNames.gincana, async () => client.from('gincana_program_sections').select('id').limit(0)],
    [migrationNames.placements, async () => client.from('gincana_program_items').select('champion_points,runner_up_points').limit(0)],
    [migrationNames.awards, async () => client.from('public_gincana_sport_awards').select('sport_id').limit(0)],
    [migrationNames.points, async () => client.from('gincana_program_items').select('points_value').limit(0)],
    [migrationNames.scores, async () => client.from('gincana_item_scores').select('item_id').limit(0)],
    [migrationNames.shirt, async () => client.from('team_student_details').select('shirt_photo_status').limit(0)],
    [migrationNames.teamSubmissions, async () => client.from('team_submissions').select('team_id').limit(0)],
    // Migration 017 intentionally revokes direct table reads for authenticated users.
    // Probe its SECURITY DEFINER RPC instead of treating the expected RLS denial as missing.
    [migrationNames.representatives, async () => client.rpc('get_my_team_representative')],
    [migrationNames.reschedule, async () => client.from('matches').select('postponed,postponement_reason').limit(0)],
  ] as const;
  const results = await Promise.all(checks.map(async ([migration, run]) => ({ migration, ...(await run()) })));
  const missing: string[] = results.filter(result => result.error).map(result => result.migration);
  const [availability, rescheduling, realtime, representativeAccounts, teamAccessJoin, storageUpload, teamFlagSubmission, rosterImageUpload] = await Promise.all([
    client.rpc('admin_create_court_availability', { p_court_name: null, p_event_date: null, p_start_time: null, p_end_time: null }),
    client.rpc('admin_reschedule_match', { p_match_id: null, p_new_scheduled_at: null, p_new_court_name: null, p_reason: null }),
    client.rpc('olient_realtime_is_ready'),
    client.rpc('olient_representative_account_provisioning_is_ready'),
    client.rpc('olient_team_access_roster_is_ready'),
    client.rpc('olient_team_submission_upload_is_ready'),
    client.rpc('olient_team_flag_submission_is_ready'),
    client.rpc('olient_roster_image_upload_is_ready'),
  ]);
  if (availability.error?.code === 'PGRST202') missing.push(migrationNames.availability);
  if (rescheduling.error?.code === 'PGRST202') missing.push(migrationNames.reschedule);
  if (realtime.error?.code === 'PGRST202' || realtime.data !== true) missing.push(migrationNames.realtime);
  if (representativeAccounts.error?.code === 'PGRST202' || representativeAccounts.data !== true) missing.push(migrationNames.representativeAccounts);
  if (teamAccessJoin.error?.code === 'PGRST202' || teamAccessJoin.data !== true) missing.push(migrationNames.teamAccessJoin);
  if (storageUpload.error?.code === 'PGRST202' || storageUpload.data !== true) missing.push(migrationNames.storageUpload);
  if (teamFlagSubmission.error?.code === 'PGRST202' || teamFlagSubmission.data !== true) missing.push(migrationNames.teamFlagSubmission);
  if (rosterImageUpload.error?.code === 'PGRST202' || rosterImageUpload.data !== true) missing.push(migrationNames.rosterImageUpload);
  cachedMissing = [...new Set(missing)].sort();
  checkedAt = Date.now();
  return cachedMissing;
}
