export type CourtWindow = { court: string; start: string; end: string; date?: string; blocked?: Array<{ start: string; end: string }> };
export type Fixture = { id: string; home: string; away: string; round: string; stage?: number; bye?: string[] };
export type ScheduledFixture = Fixture & { court: string; start: string; end: string };
export type SchedulePlan = { scheduled: ScheduledFixture[]; unscheduled: Array<{ fixture: Fixture; reason: string }>; capacityByCourt: Record<string, number>; required: number; capacity: number; feasible: boolean };
export type SportFixtureSet = { sportId: string; sportName: string; category: string | null; dates: string[]; duration: number; venues: string[]; fixtures: Fixture[] };
export type MultiSportFixture = ScheduledFixture & { sportId: string; sportName: string; category: string | null; date: string; duration: number };
export type MultiSportSchedulePlan = { scheduled: MultiSportFixture[]; unscheduled: Array<{ fixture: Fixture; sportId: string; sportName: string; date: string; reason: string }>; required: number; feasible: boolean };
const time = (value: string) => { const [h,m]=value.split(':').map(Number); return h*60+m; };
const clock = (value: number) => `${String(Math.floor(value/60)).padStart(2,'0')}:${String(value%60).padStart(2,'0')}`;

export type ExistingScheduleMatch = { sport_id: string; court_name: string | null; venue?: string | null; scheduled_at: string | null; duration_minutes: number | null; home_team_id: string | null; away_team_id: string | null; category?: string | null };

export function planMultiSportSchedule(sportSets: SportFixtureSet[], windows: CourtWindow[], gap: number, teamRest: number, existing: ExistingScheduleMatch[] = []): MultiSportSchedulePlan {
  if (gap < 0 || teamRest < 0) throw new Error('Intervalos não podem ser negativos.');
  const timeSlots = new Map<string, Array<{ court: string; date: string; start: number; end: number; timestamp: number }>>();
  for (const set of sportSets) {
    if (!Number.isInteger(set.duration) || set.duration <= 0) throw new Error(`Informe uma duração válida para ${set.sportName}.`);
    const slots: Array<{ court: string; date: string; start: number; end: number; timestamp: number }> = [];
    const seen = new Set<string>();
    for (const window of windows.filter(w => set.dates.includes(w.date ?? '') && set.venues.includes(w.court))) {
      const from = time(window.start), until = time(window.end);
      const blocks = (window.blocked ?? []).map(b => ({ start: time(b.start), end: time(b.end) }));
      for (let start = from; start + set.duration <= until; start += set.duration + gap) {
        const end = start + set.duration;
        if (blocks.some(b => start < b.end && end > b.start)) continue;
        const startText = clock(start), endText = clock(end), key = `${window.date}|${window.court}|${startText}|${endText}`;
        if (seen.has(key)) continue;
        seen.add(key);
        slots.push({ court: window.court, date: window.date!, start, end, timestamp: new Date(`${window.date}T${startText}:00`).getTime() / 60000 });
      }
    }
    slots.sort((a,b) => a.timestamp-b.timestamp || a.court.localeCompare(b.court, 'pt-BR'));
    timeSlots.set(`${set.sportId}|${set.category ?? ''}`, slots);
  }

  const tasks = sportSets.flatMap(set => set.fixtures.map((fixture, index) => ({ set, fixture, index })))
    .sort((a,b) => roundIndex(a.fixture.round)-roundIndex(b.fixture.round) || a.set.sportName.localeCompare(b.set.sportName, 'pt-BR') || (a.set.category ?? '').localeCompare(b.set.category ?? '', 'pt-BR') || a.index-b.index);
  const occupiedCourts = new Map<string, Array<{ start: number; end: number }>>();
  const occupiedTeams = new Map<string, Array<{ start: number; end: number }>>();
  const scheduled: MultiSportFixture[] = [];
  const unscheduled: MultiSportSchedulePlan['unscheduled'] = [];

  const rosterKey = (team:string, category:string|null|undefined) => `${team}|${/feminino/i.test(category??'')?'female':/masculino/i.test(category??'')?'male':'mixed'}`;
  const existingBusy = existing.filter(m => m.scheduled_at).map(m => {
    const timestamp = new Date(m.scheduled_at!).getTime() / 60000;
    return { ...m, timestamp, end: timestamp + (m.duration_minutes ?? 10) };
  });
  for (const match of existingBusy) for (const team of [match.home_team_id, match.away_team_id]) {
    if (team) { const key=rosterKey(team,match.category); occupiedTeams.set(key, [...(occupiedTeams.get(key) ?? []), { start: match.timestamp, end: match.end }]); }
  }
  const pending = [...tasks];
  while (pending.length) {
    const candidates = pending.flatMap((task, taskIndex) => {
      const { set, fixture } = task;
      const stage = fixture.stage ?? 0;
      if (pending.some(other => other.set === set && (other.fixture.stage ?? 0) < stage)) return [];
      const previous = scheduled.filter(m => m.sportId === set.sportId && m.category === set.category && (m.stage ?? 0) < stage);
      const earliest = Math.max(-Infinity, ...previous.map(m => new Date(`${m.date}T${m.end}:00`).getTime() / 60000 + teamRest));
      const slots = timeSlots.get(`${set.sportId}|${set.category ?? ''}`) ?? [];
      const slot = slots.find(candidate => {
        if (candidate.timestamp < earliest) return false;
        // Existing published slots remain reserved. Parallel volleyball capacity is
        // intentionally not assumed until the database policy confirms it.
        if (existingBusy.some(m => (m.court_name ?? m.venue) === candidate.court && candidate.timestamp < m.end + gap && candidate.timestamp + set.duration > m.timestamp - gap)) return false;
        const history = scheduled.filter(m => m.date === candidate.date && m.court === candidate.court).sort((a,b) => time(a.start)-time(b.start));
        const parallelVolley = candidate.court === 'Quadra 1' && /^(VOLEIBOL|V[ÔO]LEI)$/i.test(set.sportName.trim());
        // Court utilisation takes priority; sport alternation is a preference.
        // A male roster and a female roster are separate competing teams.
        const overlaps = history.filter(m => candidate.start < time(m.end) + gap && candidate.end > time(m.start) - gap);
        if (overlaps.length && (!parallelVolley || overlaps.some(m => m.sportId !== set.sportId))) return false;
        if (parallelVolley && [candidate.start, ...overlaps.map(m => Math.max(candidate.start, time(m.start)-gap))].some(point => overlaps.filter(m => point >= time(m.start)-gap && point < time(m.end)+gap).length >= 2)) return false;
        return ![fixture.home, fixture.away].filter(team=>!team.startsWith('A definir')).some(team => {
          const key=rosterKey(team,set.category);
          const keys=key.endsWith('|mixed')?[`${team}|male`,`${team}|female`,`${team}|mixed`]:[key,`${team}|mixed`];
          if(keys.some(k=>(occupiedTeams.get(k)??[]).some(busy=>candidate.timestamp<busy.end+teamRest&&candidate.timestamp+set.duration>busy.start-teamRest)))return true;
          const history=occupiedTeams.get(key)??[];
          const previous=history.find(busy=>busy.end===candidate.timestamp);
          return !!previous && history.some(busy=>busy.end===previous.start);
        });
      });
      if (!slot) return [];
      const history = scheduled.filter(m => m.date === slot.date && m.court === slot.court);
      const last = history[history.length - 1];
      const repeatSport = last?.sportId === set.sportId ? 1 : 0;
      const consecutiveTeams = [fixture.home, fixture.away].filter(team => (occupiedTeams.get(rosterKey(team,set.category)) ?? []).some(busy => busy.end === slot.timestamp)).length;
      const flexibleSport = /BASQUETE|FUTMESA|VOLEI DE MESA/.test(set.sportName.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase());
      const repeatedTeams = last && (last.category?.match(/Masculino|Feminino/i)?.[0]??'mixed') === (set.category?.match(/Masculino|Feminino/i)?.[0]??'mixed') ? [fixture.home, fixture.away].filter(team => [last.home, last.away].includes(team)).length : 0;
      const division = set.category?.match(/Masculino|Feminino/i)?.[0]?.toLowerCase();
      const previousDivision = last?.category?.match(/Masculino|Feminino/i)?.[0]?.toLowerCase();
      const repeatedDivision = flexibleSport && last?.sportId === set.sportId && division && division === previousDivision ? 1 : 0;
      const remaining = pending.filter(other=>other.set===set).length;
      const urgency = remaining / Math.max(1, slots.filter(s=>s.timestamp>=slot.timestamp).length);
      return [{ task, taskIndex, slot, urgency, penalty: consecutiveTeams * 100 + repeatedTeams * 50 + repeatedDivision * 10 + (flexibleSport ? 0 : repeatSport * 4) }];
    });
    candidates.sort((a,b) => a.slot.timestamp-b.slot.timestamp || b.urgency-a.urgency || a.penalty-b.penalty || a.taskIndex-b.taskIndex);
    const chosen = candidates[0];
    if (!chosen) {
      for (const { set, fixture } of pending) unscheduled.push({ fixture, sportId: set.sportId, sportName: set.sportName, date: set.dates.join(', '), reason: /FUTMESA|VOLEI DE MESA|BASQUETE/.test(set.sportName.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase()) ? 'Sequência liberada, sem limite de três jogos. Não há horário livre compatível com os dias, locais, jogos publicados, turmas e fases anteriores.' : 'Sem horário que respeite disponibilidade, conflitos e as regras de sequência das modalidades por local.' });
      break;
    }
    const { task: { set, fixture }, slot, taskIndex } = chosen;
    pending.splice(taskIndex, 1);
    const startText = clock(slot.start), endText = clock(slot.end);
    scheduled.push({ ...fixture, sportId: set.sportId, sportName: set.sportName, category: set.category, date: slot.date, duration: set.duration, court: slot.court, start: startText, end: endText });
    const courtKey = `${slot.date}|${slot.court}`;
    occupiedCourts.set(courtKey, [...(occupiedCourts.get(courtKey) ?? []), { start: slot.start, end: slot.end }]);
    const end = slot.timestamp + set.duration;
    for (const team of [fixture.home, fixture.away].filter(team=>!team.startsWith('A definir'))) occupiedTeams.set(rosterKey(team,set.category), [...(occupiedTeams.get(rosterKey(team,set.category)) ?? []), { start: slot.timestamp, end }]);
  }
  return { scheduled, unscheduled, required: tasks.length, feasible: tasks.length > 0 && unscheduled.length === 0 };
}

function roundIndex(round: string) { const match = round.match(/(?:Rodada|Fase|Round|Returno)\s*(\d+)/i); return match ? Number(match[1]) + (/Returno/i.test(round) ? 1000 : 0) : 0; }

export function requiredMatches(count: number, format: 'single_elimination'|'round_robin'|'third_place', returnLeg = false) {
  if (!Number.isInteger(count) || count < 2) return 0;
  if (format === 'round_robin') return count*(count-1)/2*(returnLeg?2:1);
  const base = count-1;
  return format === 'third_place' && count >= 3 ? base+1 : base;
}

export function makeFixtures(teamIds: string[], format: 'single_elimination'|'round_robin'|'third_place', seed: number, returnLeg = false): Fixture[] {
  const teams=[...teamIds];
  // Seeded Fisher-Yates: same input and seed produces the same draw.
  let state=seed>>>0;
  const random=()=>{state=(state*1664525+1013904223)>>>0;return state/4294967296;};
  for(let i=teams.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[teams[i],teams[j]]=[teams[j],teams[i]];}
  if(format==='round_robin'){
    const ring=[...teams];if(ring.length%2)ring.push('BYE');const rounds=ring.length-1;const out:Fixture[]=[];
    for(let r=0;r<rounds;r++){for(let i=0;i<ring.length/2;i++){const a=ring[i],b=ring[ring.length-1-i];if(a!=='BYE'&&b!=='BYE')out.push({id:`${seed}-r${r+1}-${i+1}`,home:r%2?b:a,away:r%2?a:b,round:`Rodada ${r+1}`});}ring.splice(1,0,ring.pop()!);}
    if(returnLeg) return [...out,...out.map((f,i)=>({id:`${f.id}-2`,home:f.away,away:f.home,round:`Returno ${Math.floor(i/(teams.length/2))+1}`}))];
    return out;
  }
  const size=2**Math.ceil(Math.log2(teams.length));
  const byes=size-teams.length;
  const out:Fixture[]=[];
  // Seedless draw: byes are explicitly listed and only known first-round pairings are scheduled.
  const byeTeams=teams.slice(0,byes);
  const playing=teams.slice(byes);
  for(let i=0;i<playing.length;i+=2) if(playing[i+1]) out.push({id:`${seed}-r1-${out.length+1}`,home:playing[i]!,away:playing[i+1]!,round:'Eliminatória · 1ª fase',bye:out.length===0?byeTeams:[]});
  if(format==='third_place'&&teams.length>=3) out.push({id:`${seed}-third`,home:'A definir após semifinais',away:'A definir após semifinais',round:'Disputa de 3º lugar'});
  let entrants = [...out.map(f => `A definir · vencedor ${f.id}`), ...byeTeams];
  let stage = 1;
  while (entrants.length > 1) {
    const next: string[] = [];
    for (let i = 0; i < entrants.length; i += 2) {
      const id = `${seed}-stage${stage}-${i / 2 + 1}`;
      out.push({ id, home: entrants[i], away: entrants[i + 1], stage, round: entrants.length === 2 ? 'Final' : entrants.length === 4 ? 'Semifinal' : `Eliminatória · fase ${stage + 1}` });
      next.push(`A definir · vencedor ${id}`);
    }
    entrants = next; stage++;
  }
  return out;
}

export function makeGroupFixtures(teamIds: string[], seed: number): Fixture[] {
  if (teamIds.length < 2) return [];
  const shuffled = [...teamIds];
  let state = seed >>> 0;
  const random = () => { state = (state * 1664525 + 1013904223) >>> 0; return state / 4294967296; };
  for (let i = shuffled.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [shuffled[i], shuffled[j]] = [shuffled[j]!, shuffled[i]!]; }
  const groups: [string[], string[]] = [[], []];
  shuffled.forEach((team, index) => groups[index % 2]!.push(team));
  const fixtures = groups.flatMap((group, groupIndex) => makeFixtures(group, 'round_robin', seed + groupIndex + 1)
    .map(fixture => ({ ...fixture, id: `g${groupIndex + 1}-${fixture.id}`, round: `Grupo ${groupIndex === 0 ? 'A' : 'B'} · ${fixture.round}` })));
  fixtures.push(
    { id: 'semi-1', home: 'A definir · 1º do grupo A', away: 'A definir · 2º do grupo B', round: 'Semifinal 1', stage: 1 },
    { id: 'semi-2', home: 'A definir · 1º do grupo B', away: 'A definir · 2º do grupo A', round: 'Semifinal 2', stage: 1 },
    { id: 'final', home: 'A definir · vencedor da semifinal 1', away: 'A definir · vencedor da semifinal 2', round: 'Final', stage: 2 }
  );
  return fixtures;}

export function planSchedule(fixtures: Fixture[], windows: CourtWindow[], duration: number, gap: number, teamRest: number): SchedulePlan {
  if(duration<=0||gap<0||teamRest<0) throw new Error('Duração deve ser positiva e intervalos não podem ser negativos.');
  const slots:{court:string;start:number;end:number}[]=[];const capacityByCourt:Record<string,number>={};
  for(const w of windows){const from=time(w.start),to=time(w.end);let cursor=from;let capacity=0;const blocks=(w.blocked??[]).map(b=>({start:time(b.start),end:time(b.end)})).sort((a,b)=>a.start-b.start);
    while(cursor+duration<=to){const block=blocks.find(b=>cursor<b.end&&cursor+duration>b.start);if(block){cursor=block.end+gap;continue;}slots.push({court:w.court,start:cursor,end:cursor+duration});capacity++;cursor+=duration+gap;}capacityByCourt[w.court]=(capacityByCourt[w.court]??0)+capacity;
  }
  slots.sort((a,b)=>a.start-b.start||a.court.localeCompare(b.court));
  const scheduled:ScheduledFixture[]=[],unscheduled:SchedulePlan['unscheduled']=[];const teamHistory=new Map<string,number[]>();const courtHistory=new Map<string,number>();
  for(const f of fixtures){let placed=false;
    for(let i=0;i<slots.length;i++){const s=slots[i]!;if(s.start<(courtHistory.get(s.court)??-Infinity))continue;const lastHome=teamHistory.get(f.home)??[],lastAway=teamHistory.get(f.away)??[];if([...lastHome,...lastAway].some(t=>s.start-t<teamRest))continue;
      scheduled.push({...f,court:s.court,start:clock(s.start),end:clock(s.end)});courtHistory.set(s.court,s.end+gap);for(const team of [f.home,f.away])teamHistory.set(team,[...(teamHistory.get(team)??[]),s.start]);slots.splice(i,1);placed=true;break;
    }
    if(!placed)unscheduled.push({fixture:f,reason:'Sem horário que respeite disponibilidade, intervalo e descanso das equipes.'});
  }
  return {scheduled,unscheduled,capacityByCourt,required:fixtures.length,capacity:Object.values(capacityByCourt).reduce((a,b)=>a+b,0),feasible:unscheduled.length===0};
}






