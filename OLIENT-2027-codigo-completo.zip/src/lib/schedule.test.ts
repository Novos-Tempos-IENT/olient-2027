import { describe, expect, it } from 'vitest';
import { makeFixtures, planSchedule, requiredMatches } from './schedule';
describe('formatos e agendamento',()=>{
 it('calcula confrontos em todos contra todos e eliminatória',()=>{expect(requiredMatches(5,'round_robin')).toBe(10);expect(requiredMatches(5,'single_elimination')).toBe(4);expect(requiredMatches(5,'third_place')).toBe(5);});
 it('sorteio é determinístico e não repete confrontos em round robin',()=>{const a=makeFixtures(['a','b','c','d','e'],'round_robin',42);const b=makeFixtures(['a','b','c','d','e'],'round_robin',42);expect(a).toEqual(b);expect(a).toHaveLength(10);expect(new Set(a.map(x=>[x.home,x.away].sort().join(':'))).size).toBe(10);});
 it('respeita bloqueios, intervalos, quadras e descanso de equipes',()=>{const p=planSchedule([{id:'1',home:'a',away:'b',round:'1'},{id:'2',home:'a',away:'c',round:'1'},{id:'3',home:'d',away:'e',round:'1'}],[{court:'Quadra 1',start:'08:00',end:'10:00',blocked:[{start:'08:30',end:'09:00'}]},{court:'Quadra 2',start:'08:00',end:'09:00'}],30,10,40);expect(p.scheduled).toHaveLength(3);expect(p.feasible).toBe(true);expect(p.scheduled.find(x=>x.id==='2')!.start>p.scheduled.find(x=>x.id==='1')!.start).toBe(true);});
 it('informa capacidade insuficiente sem retirar jogos',()=>{const p=planSchedule([{id:'1',home:'a',away:'b',round:'1'},{id:'2',home:'c',away:'d',round:'1'}],[{court:'Quadra 1',start:'08:00',end:'08:30'}],30,0,0);expect(p.scheduled).toHaveLength(1);expect(p.unscheduled).toHaveLength(1);expect(p.feasible).toBe(false);});
});
