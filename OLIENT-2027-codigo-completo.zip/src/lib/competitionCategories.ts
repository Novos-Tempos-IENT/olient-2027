export const SCHOOL_CATEGORIES = ['6º e 7º anos', '8º, 9º, 1º e 2º anos'];
export function competitionCategories(sportName: string) {
 const name = sportName.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase();
 const mixed = !/BASQUETE|FUTSAL|FUTMESA|TENIS DE MESA|VOLEI DE MESA/.test(name);
 return mixed ? SCHOOL_CATEGORIES : SCHOOL_CATEGORIES.flatMap(category => [`${category} · Masculino`, `${category} · Feminino`]);
}
export function sportMatchLabel(name: string, category?: string | null) {
 const division = category?.match(/masculino|feminino|misto/i)?.[0];
 if (division) return `${name} · ${division[0].toUpperCase()}${division.slice(1).toLowerCase()}`;
 return `${name} · ${competitionCategories(name).length === 2 ? 'Misto' : 'Categoria não definida'}`;
}
