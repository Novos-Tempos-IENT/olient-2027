export interface LedgerLine { teamId: string; points: number; voidedAt?: string | null }
export function calculateStandings(lines: LedgerLine[], names: Record<string, string>) {
  const totals = new Map<string, number>();
  for (const line of lines) if (!line.voidedAt) totals.set(line.teamId, (totals.get(line.teamId) ?? 0) + line.points);
  return [...totals].map(([team_id, total_points]) => ({ team_id, team_name: names[team_id] ?? 'Equipe', total_points }))
    .sort((a, b) => b.total_points - a.total_points || a.team_name.localeCompare(b.team_name, 'pt-BR'))
    .map((row, index) => ({ ...row, place: index + 1 }));
}
