import { describe, expect, it } from 'vitest';
import { calculateStandings } from './scoring';
describe('classificação derivada do livro-razão', () => {
  it('soma créditos e penalidades e ignora lançamentos revertidos', () => {
    const actual = calculateStandings([{ teamId: 'a', points: 15000 }, { teamId: 'a', points: -500 }, { teamId: 'b', points: 10000 }, { teamId: 'b', points: 300, voidedAt: 'now' }], { a: 'Azul', b: 'Amarela' });
    expect(actual.map(({ team_name, total_points, place }) => [team_name, total_points, place])).toEqual([['Azul', 14500, 1], ['Amarela', 10000, 2]]);
  });
  it('usa nome como ordenação estável apenas para apresentar empate, sem afirmar desempate oficial', () => {
    expect(calculateStandings([{ teamId: 'b', points: 100 }, { teamId: 'a', points: 100 }], { a: 'Azul', b: 'Amarela' }).map(x => x.team_name)).toEqual(['Amarela', 'Azul']);
  });
});
