function normalizeGender(value:string):'male'|'female'|undefined { const text=value.trim().toLowerCase();return ['m','masculino','male'].includes(text)?'male':['f','feminino','female'].includes(text)?'female':undefined; }
export type RosterRow={row:number;className:string;fullName:string;gender?:'male'|'female';error?:string};

function parseDelimited(text:string):string[][]{
 const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).filter(line=>line.trim());
 const delimiter=(lines[0]?.split(';').length??0)>(lines[0]?.split(',').length??0)?';':',';
 return lines.map(line=>{const cells:string[]=[];let cell='',quoted=false;for(let i=0;i<line.length;i++){const ch=line[i];if(ch==='"'&&line[i+1]==='"'&&quoted){cell+='"';i++;}else if(ch==='"')quoted=!quoted;else if(ch===delimiter&&!quoted){cells.push(cell.trim());cell='';}else cell+=ch;}cells.push(cell.trim());return cells;});
}
function xmlText(el:Element,shared:string[]):string{
 const type=el.getAttribute('t');if(type==='inlineStr')return el.querySelector('is t')?.textContent?.trim()??'';
 const value=el.querySelector('v')?.textContent?.trim()??'';if(type==='s')return shared[Number(value)]??'';return value;
}
async function readXlsx(file:File):Promise<string[][]>{
 const bytes=await file.arrayBuffer(),view=new DataView(bytes);let eocd=-1;
 for(let i=view.byteLength-22;i>=Math.max(0,view.byteLength-65558);i--)if(view.getUint32(i,true)===0x06054b50){eocd=i;break;}
 if(eocd<0)throw new Error('O arquivo XLSX não contém uma estrutura ZIP válida.');
 const count=view.getUint16(eocd+10,true),centralOffset=view.getUint32(eocd+16,true),decoder=new TextDecoder();let offset=centralOffset;const entries=new Map<string,{method:number;compressed:number;local:number}>();
 for(let i=0;i<count;i++){if(view.getUint32(offset,true)!==0x02014b50)throw new Error('A planilha está corrompida.');const method=view.getUint16(offset+10,true),compressed=view.getUint32(offset+20,true),nameLen=view.getUint16(offset+28,true),extra=view.getUint16(offset+30,true),comment=view.getUint16(offset+32,true),local=view.getUint32(offset+42,true),name=decoder.decode(new Uint8Array(bytes,offset+46,nameLen));entries.set(name,{method,compressed,local});offset+=46+nameLen+extra+comment;}
 const extract=async(name:string)=>{const entry=entries.get(name);if(!entry)return null;const start=entry.local,namelen=view.getUint16(start+26,true),extra=view.getUint16(start+28,true),dataStart=start+30+namelen+extra,compressed=new Uint8Array(bytes,dataStart,entry.compressed);if(entry.method===0)return decoder.decode(compressed);if(entry.method!==8)throw new Error('Formato de compressão XLSX não suportado.');if(typeof DecompressionStream==='undefined')throw new Error('Este navegador não oferece suporte à leitura XLSX. Salve como CSV.');const stream=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate-raw' as CompressionFormat));return await new Response(stream).text();};
 const workbook=await extract('xl/workbook.xml');if(!workbook)throw new Error('Não foi possível localizar a primeira planilha.');const rels=await extract('xl/_rels/workbook.xml.rels');const doc=new DOMParser().parseFromString(workbook,'application/xml'),relDoc=rels?new DOMParser().parseFromString(rels,'application/xml'):null;const sheet=doc.querySelector('sheets sheet');if(!sheet)throw new Error('A planilha está vazia.');const relation=sheet.getAttribute('r:id');const target=relDoc?[...relDoc.querySelectorAll('Relationship')].find(r=>r.getAttribute('Id')===relation)?.getAttribute('Target'):null;const sheetPath=target?(target.startsWith('/')?target.slice(1):`xl/${target}`):'xl/worksheets/sheet1.xml';const sheetXml=await extract(sheetPath);if(!sheetXml)throw new Error('Não foi possível ler a primeira aba da planilha.');const sharedXml=await extract('xl/sharedStrings.xml');const shared=sharedXml?[...new DOMParser().parseFromString(sharedXml,'application/xml').querySelectorAll('si')].map(si=>si.textContent?.trim()??''):[];const sheetDoc=new DOMParser().parseFromString(sheetXml,'application/xml');
 return [...sheetDoc.querySelectorAll('sheetData row')].map(row=>{const cells:string[]=[];for(const cell of row.querySelectorAll('c')){const ref=cell.getAttribute('r')??'',col=ref.match(/[A-Z]+/)?.[0]??'';const index=[...col].reduce((n,ch)=>n*26+ch.charCodeAt(0)-64,0)-1;cells[index]=xmlText(cell,shared);}return cells;});
}
export async function parseRosterFile(file:File):Promise<RosterRow[]>{
 const rows=file.name.toLowerCase().endsWith('.csv')?parseDelimited(await file.text()):file.name.toLowerCase().endsWith('.xlsx')?await readXlsx(file):(()=>{throw new Error('Selecione um arquivo .xlsx ou .csv.');})();
 const data=rows.map((cells,index)=>({row:index+1,className:(cells[0]??'').trim(),fullName:(cells[1]??'').trim(),gender:normalizeGender(cells[2]??'')}));const first=data[0];const hasHeader=!!first&&/turma|classe/i.test(first.className)&&/nome/i.test(first.fullName);const body=hasHeader?data.slice(1):data;
 return body.map(item=>({...item,error:!item.gender?'Terceira coluna ausente ou inválida (M/F)':!item.className?'Turma ausente':!item.fullName?'Nome ausente':item.fullName.length>240?'Nome acima de 240 caracteres':/[\u0000-\u001f]/.test(item.fullName)?'Nome contém caracteres inválidos':undefined}));
}
