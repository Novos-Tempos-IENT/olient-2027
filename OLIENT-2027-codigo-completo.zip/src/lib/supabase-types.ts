// The SQL migrations are the schema source of truth. Regenerate with `supabase gen types typescript` after deployment.
export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];
export interface Database {
  public: {
    Tables: {
      teams: { Row: { id: string; name: string; color: string | null; logo_path: string | null; active: boolean; created_at: string }; Insert: { id?: string; name: string; color?: string | null; logo_path?: string | null; active?: boolean }; Update: Partial<{ name: string; color: string | null; logo_path: string | null; active: boolean }>; Relationships: [] };
      sports: { Row: { id: string; name: string; description: string | null; status: string; category: string | null }; Insert: { id?: string; name: string; description?: string | null; status?: string; category?: string | null }; Update: Partial<{ name: string; description: string | null; status: string; category: string | null }>; Relationships: [] };
      profiles: { Row: { id: string; display_name: string; role: string; created_at: string }; Insert: { id: string; display_name: string; role?: string }; Update: { display_name?: string }; Relationships: [] };
      score_ledger: { Row: { id: string; team_id: string; points: number; source_type: string; source_id: string | null; description: string; created_at: string; reversal_of: string | null; voided_at: string | null; sport_id: string | null }; Insert: never; Update: never; Relationships: [] };
      publications: { Row: { id: string; title: string; body: string | null; kind: string; published_at: string; created_at: string }; Insert: never; Update: never; Relationships: [] };
      matches: { Row: { id: string; sport_id: string; scheduled_at: string | null; venue: string | null; round: string | null; status: string; home_team_id: string; away_team_id: string; home_score: number | null; away_score: number | null }; Insert: never; Update: never; Relationships: [] };
    };
    Views: { public_standings: { Row: { team_id: string; team_name: string; total_points: number; place: number } } }; Functions: { setup_first_admin: { Args: { display_name: string }; Returns: undefined }; record_manual_score: { Args: { p_team_id: string; p_points: number; p_description: string; p_rule_id: string; p_source_type?: string }; Returns: string }; confirm_match_result: { Args: { p_match_id: string; p_home_score: number; p_away_score: number; p_idempotency_key: string }; Returns: string }; reverse_score_entry: { Args: { p_entry_id: string; p_reason: string }; Returns: string }; publish_match_result: { Args: { p_result_id: string; p_title?: string | null; p_body?: string | null }; Returns: string }; withdraw_publication: { Args: { p_publication_id: string; p_reason: string }; Returns: undefined } }; Enums: Record<string, never>; CompositeTypes: Record<string, never>;
  };
}
