export type GincanaSection = { id: string; name: string; sort_order: number };
export type GincanaItem = { id: string; section_id: string; event_date: string | null; title: string; sort_order: number; champion_points: number | null; runner_up_points: number | null; points_value: number | null };

export const fallbackSections: GincanaSection[] = [
  'Gincanas', 'Ação social', 'Entrada', 'Vídeos', 'Esportes', 'Cartões', 'Punições',
].map((name, index) => ({ id: `local-section-${index + 1}`, name, sort_order: index + 1 }));

const rows: Array<[string, string | null, string]> = [
  ...['Continue a música','Embaixadinha feminina','Batatinha frita 1, 2, 3','Balde de água nos pés','Trazer funcionários para dançar','Itens aleatórios'].map(name => ['Gincanas','2027-09-30',name] as [string,string,string]),
  ...['Batalha de robôs','Karaokê / Videokê','Guerra de cotonete','Corrida do chinelão','Twister','Crossfit Betim','Arco e flecha','Itens aleatórios','Embaixadinha masculina'].map(name => ['Gincanas','2027-10-01',name] as [string,string,string]),
  ...['Cano furado','Itens aleatórios','Cabo de guerra','Torta na cara','Batalha dos robôs'].map(name => ['Gincanas','2027-10-02',name] as [string,string,string]),
  ['Ação social','2027-09-30','Brinquedos'], ['Ação social','2027-10-01','Higiene'], ['Ação social','2027-10-02','1 kg de alimento'],
  ...['Camisa (entrada)','Camisa (criatividade)','Bandeira','Traje (criatividade)','Traje (entrada)'].map(name => ['Entrada',null,name] as [string,null,string]),
  ...['Grito de guerra','Origem do personagem','Convite para abertura'].map(name => ['Vídeos',null,name] as [string,null,string]),
  ...['Basquete masculino','Basquete feminino','Dodgeball','Futsal masculino','Futsal feminino','Handebol misto','Tênis de mesa masculino','Tênis de mesa feminino','Futmesa masculino','Futmesa feminino','Vôlei de mesa masculino','Vôlei de mesa feminino','Voleibol'].map(name => ['Esportes',null,name] as [string,null,string]),
  ['Cartões',null,'Futsal masculino'], ['Cartões',null,'Handebol masculino'],
];

export const fallbackItems: GincanaItem[] = rows.map(([section, event_date, title], index) => ({
  id: `local-item-${index + 1}`,
  section_id: fallbackSections.find(item => item.name === section)!.id,
  event_date,
  title,
  sort_order: index + 1,
  champion_points: section === 'Esportes' ? 15000 : null,
  runner_up_points: section === 'Esportes' ? 5000 : null,
  points_value: null,
}));
