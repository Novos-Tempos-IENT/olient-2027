import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
export default function StudentGenderField({studentId,admin}:{studentId:string;admin:boolean}) {
 const [value,setValue]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
 useEffect(()=>{let active=true;setValue('');setError('');void supabase?.from('students').select('gender').eq('id',studentId).single().then(({data,error})=>{if(!active)return;if(error)setError(error.message);else setValue(data?.gender??'')});return()=>{active=false}},[studentId]);
 const save=async(gender:string)=>{if(!supabase||!admin)return;setBusy(true);setError('');const {error}=await supabase.rpc('admin_set_student_gender',{p_student_id:studentId,p_gender:gender});if(error)setError(error.message);else setValue(gender);setBusy(false)};
 return <label>Sexo para inscrição esportiva<select value={value} disabled={!admin||busy} onChange={e=>void save(e.target.value)}><option value="" disabled>Não informado</option><option value="male">Masculino</option><option value="female">Feminino</option></select>{error&&<small className="form-error">{error}</small>}</label>;
}
