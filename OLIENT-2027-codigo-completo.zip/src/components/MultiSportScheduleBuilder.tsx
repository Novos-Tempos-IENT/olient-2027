import { competitionCategories, sportMatchLabel } from '../lib/competitionCategories';
import { useEffect, useMemo, useState } from 'react';
import { Check, LoaderCircle, ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { makeFixtures, makeGroupFixtures, planMultiSportSchedule, type CourtWindow, type MultiSportSchedulePlan, type SportFixtureSet, type ExistingScheduleMatch } from '../lib/schedule';
import type { Sport, Team } from '../types/database';

const VENUES = ['Quadra 1', 'Quadra 2', 'Futmesa', 'Tênis de Mesa'];
const CATEGORIES = ['6º e 7º anos', '8º, 9º, 1º e 2º anos'];
function teamCategory(name: string) {
  const year = Number(name.match(/\d+/)?.[0]);
  return [6, 7].includes(year) ? CATEGORIES[0] : [8, 9, 1, 2].includes(year) ? CATEGORIES[1] : null;
}
type Registration = { team_id: string; sport_id: string; category: string | null };
type Format = 'round_robin' | 'knockout' | 'groups';
type Config = { format: Format; dates: string[]; duration: number; venues: string[] };
type Props = { sports: Sport[]; teams: Team[]; onPublished: () => Promise<void> };

function localDate(value: string) {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date(value));
  const part = (type: string) => parts.find(item => item.type === type)?.value ?? '';
  return `${part('year')}-${part('month')}-${part('day')}`;
}
function localTime(value: string) {
  return new Intl.DateTimeFormat('en-GB', { timeZone: 'America/Sao_Paulo', hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(value));
}

export default function MultiSportScheduleBuilder({ sports, teams, onPublished }: Props) {
  const activeSports = useMemo(() => sports.filter(s => s.status === 'active'), [sports]);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [registrationDrafts, setRegistrationDrafts] = useState<Record<string, string[]>>({});
  const [registeringSport, setRegisteringSport] = useState('');
  const [existingSchedule,setExistingSchedule]=useState<ExistingScheduleMatch[]>([]);
  const [windows, setWindows] = useState<CourtWindow[]>([]);
  const [configs, setConfigs] = useState<Record<string, Config>>({});
  const [gap, setGap] = useState(0);
  const [rest, setRest] = useState(0);
  const [previewDay, setPreviewDay] = useState('');
  const [plan, setPlan] = useState<MultiSportSchedulePlan | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [savingAvailability, setSavingAvailability] = useState(false);
  const [availabilitySaved, setAvailabilitySaved] = useState(false);
  const [eventDateDraft, setEventDateDraft] = useState('');
  const [eventDates, setEventDates] = useState<string[]>([]);
  const [eventStart, setEventStart] = useState('07:00');
  const [eventEnd, setEventEnd] = useState('12:30');

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      if (!supabase) { setError('Supabase não está conectado.'); setLoading(false); return; }
      if (!activeSports.length) { setError('Não há modalidades ativas para gerar.'); setLoading(false); return; }
      try {
        const [r, a] = await Promise.all([
          supabase.from('registrations').select('team_id,sport_id,category').in('sport_id', activeSports.map(s => s.id)).eq('status', 'approved'),
          supabase.from('court_availability').select('*').order('available_from'),
        ]);
        if (r.error) throw r.error;
        if (a.error) throw a.error;
        if (!mounted) return;
        const loadedWindows: CourtWindow[] = (a.data ?? []).map((row: any) => ({
          court: row.court_name, date: localDate(row.available_from), start: localTime(row.available_from), end: localTime(row.available_until),
          blocked: [...(row.blocked_windows ?? []), ...(row.pause_windows ?? [])],
        }));
        setWindows(loadedWindows);
        setRegistrations((r.data ?? []) as Registration[]);
        let draft: any = null;
        try { draft = JSON.parse(localStorage.getItem('olient-schedule-draft-v1') ?? 'null'); } catch { /* Start with defaults when no valid draft exists. */ }
        const dates = Array.isArray(draft?.eventDates) ? draft.eventDates : [];
        setEventDates(dates); setEventStart(draft?.eventStart ?? '07:00'); setEventEnd(draft?.eventEnd ?? '12:30');
        setGap(draft?.defaultsVersion === 4 ? draft.gap ?? 0 : 0); setRest(draft?.defaultsVersion === 4 ? draft.rest ?? 0 : 0);
        setConfigs(Object.fromEntries(activeSports.map(s => [s.id, { format: 'round_robin' as const, duration: 10, venues: [], ...draft?.configs?.[s.id], ...(draft?.defaultsVersion === 4 ? {} : { duration: 10 }), dates }])));
      } catch (e) { if (mounted) setError(e instanceof Error ? e.message : 'Falha ao carregar a configuração da agenda.'); }
      finally { if (mounted) setLoading(false); }
    };
    void load();
    return () => { mounted = false; };
  }, [activeSports]);
  useEffect(() => {
    if (loading) return;
    localStorage.setItem('olient-schedule-draft-v1', JSON.stringify({ defaultsVersion: 4, eventDates, eventStart, eventEnd, gap, rest, configs }));
  }, [loading, eventDates, eventStart, eventEnd, gap, rest, configs]);

  const previewDates = [...new Set(plan?.scheduled.map(match => match.date) ?? [])].sort();
  const currentPreviewDate = previewDates.includes(previewDay) ? previewDay : previewDates[0] ?? '';
  const previewDateIndex = previewDates.indexOf(currentPreviewDate);
  const teamName = (id: string) => teams.find(t => t.id === id)?.name ?? id;
  const activeTeamIds = useMemo(() => new Set(teams.filter(t => t.active).map(t => t.id)), [teams]);
  const teamCounts = (sportId: string) => new Set(registrations.filter(r => r.sport_id === sportId && activeTeamIds.has(r.team_id)).map(r => r.team_id)).size;
  const participantOptions = (sport: Sport) => teams.filter(t=>t.active).flatMap(team => competitionCategories(sport.name).filter(category=>category.startsWith(teamCategory(team.name)??'Invalid')).map(category=>({team,category,key:`${team.id}|${category}`,label:competitionCategories(sport.name).length===4?`${team.name} - ${category.endsWith('Feminino')?'Feminino':'Masculino'}`:team.name})));
  const selectedParticipants = (sport: Sport) => registrationDrafts[sport.id] ?? participantOptions(sport).filter(option=>registrations.some(row=>row.sport_id===sport.id&&row.team_id===option.team.id&&(row.category===option.category||!row.category||row.category===teamCategory(option.team.name)))).map(option=>option.key);
  const approveTeams = async (sportId: string, ids: string[]) => {
    if (!supabase) return;
    setRegisteringSport(sportId); setError('');
    try {
      if (ids.some(id => !teamCategory(teamName(id.split('|')[0])))) throw new Error('Há uma equipe sem ano reconhecido. Use turmas do 6º, 7º, 8º, 9º, 1º ou 2º ano.');
      const sportCategories = competitionCategories(activeSports.find(s => s.id === sportId)?.name ?? '');
      for (const category of sportCategories) {
        const { error: rpcError } = await supabase.rpc('set_modality_registrations', { p_sport_id: sportId, p_team_ids: ids.filter(id => id.split('|')[1] === category).map(id=>id.split('|')[0]), p_category: category });
        if (rpcError) throw new Error(rpcError.message);
      }
      for (const oldCategory of [null, ...CATEGORIES.filter(c => !sportCategories.includes(c))]) {
        const { error: clearError } = await supabase.rpc('set_modality_registrations', { p_sport_id: sportId, p_team_ids: [], p_category: oldCategory });
        if (clearError) throw new Error(clearError.message);
      }
      const { data, error: readError } = await supabase.from('registrations').select('team_id,sport_id,category').in('sport_id', activeSports.map(s => s.id)).eq('status', 'approved');
      if (readError) throw new Error(readError.message);
      setRegistrations((data ?? []) as Registration[]); setPlan(null); setSaved(false);
    } catch (e) { setError(e instanceof Error ? e.message : 'Não foi possível aprovar as equipes.'); }
    finally { setRegisteringSport(''); }
  };
  const update = (sportId: string, change: Partial<Config>) => {
    setConfigs(current => ({ ...current, [sportId]: { ...current[sportId], ...change } }));
    setPlan(null); setSaved(false); setAvailabilitySaved(false);
  };
  const updateEventDates = (dates: string[]) => {
    const normalized = [...new Set(dates)].sort();
    setEventDates(normalized);
    setConfigs(current => Object.fromEntries(Object.entries(current).map(([sportId, config]) => [sportId, { ...config, dates: normalized }])));
    setPlan(null); setSaved(false); setAvailabilitySaved(false);
  };

  const makeSets = (approved = registrations): SportFixtureSet[] => {
    const sets: SportFixtureSet[] = [];
    for (const sport of activeSports) {
      const cfg = configs[sport.id];
      if (!cfg?.dates.length || !cfg.venues.length) continue;
      const entries = approved.filter(r => r.sport_id === sport.id && activeTeamIds.has(r.team_id));
      const categories = new Map<string, string[]>();
      for (const entry of entries) {
        const key = entry.category;
        if (!key || !competitionCategories(sport.name).includes(key) || !key.startsWith(teamCategory(teamName(entry.team_id)) ?? 'Invalid')) continue;
        const ids = categories.get(key) ?? [];
        if (!ids.includes(entry.team_id)) ids.push(entry.team_id);
        categories.set(key, ids);
      }
      for (const [category, ids] of categories) {
        if (ids.length < 2) continue;
        const fixtures = cfg.format === 'groups' ? makeGroupFixtures(ids, 2027)
          : cfg.format === 'knockout' ? makeFixtures(ids, 'single_elimination', 2027)
            : makeFixtures(ids, 'round_robin', 2027);
        sets.push({ sportId: sport.id, sportName: sport.name, category: category || null, dates: cfg.dates, duration: cfg.duration, venues: cfg.venues, fixtures });
      }
    }
    return sets;
  };

  const preview = async () => {
    try {
      setError(''); setSaved(false); setRegisteringSport('generation');
      const missing = activeSports.filter(s => !configs[s.id]?.dates.length || !configs[s.id]?.venues.length);
      if (missing.length) throw new Error(`Defina ao menos um dia e um local para todas as modalidades: ${missing.map(s => s.name).join(', ')}.`);
      if (!supabase) throw new Error('Supabase indisponível.');
      const normalized: Registration[] = [];
      for (const sport of activeSports) {
        const selections = selectedParticipants(sport);
        for (const category of competitionCategories(sport.name)) {
          const categoryIds = selections.filter(id => id.split('|')[1] === category).map(id=>id.split('|')[0]);
          if (configs[sport.id]?.format === 'groups' && categoryIds.length > 0 && categoryIds.length < 4) throw new Error(`${sport.name} · ${category}: o formato de grupos exige pelo menos quatro turmas.`);
          const { error: approvalError } = await supabase.rpc('set_modality_registrations', { p_sport_id: sport.id, p_team_ids: categoryIds, p_category: category });
          if (approvalError) throw new Error(approvalError.message);
          categoryIds.forEach(team_id => normalized.push({ team_id, sport_id: sport.id, category }));
        }
      }
      setRegistrations(normalized);
      if (!windows.length) throw new Error('Salve o calendário geral antes de gerar.');
      const sets = makeSets(normalized);
      if (!sets.length) throw new Error('Confirme as equipes participantes nos cartões para separar as inscrições em 6º/7º e 8º/9º/1º/2º. Cada categoria precisa de pelo menos duas equipes para gerar jogos.');
      const eventWindows = windows.filter(w => eventDates.includes(w.date ?? '')).map(w => ({ ...w, start: w.start > eventStart ? w.start : eventStart, end: w.end < eventEnd ? w.end : eventEnd })).filter(w => w.start < w.end);
      const { error: clearError } = await supabase.rpc('admin_clear_previous_schedule');
      if (clearError) throw new Error(clearError.code === 'PGRST202' ? 'Aplique a migration 202610300007_replace_schedule_on_preview.sql para substituir a agenda anterior automaticamente.' : clearError.message);

      const { data: existingMatches, error: existingError } = await supabase.from('matches').select('sport_id,court_name,venue,scheduled_at,duration_minutes,home_team_id,away_team_id,category').is('deleted_at', null).neq('schedule_status', 'cancelled');
      if (existingError) throw new Error(existingError.message);
      setExistingSchedule(existingMatches ?? []);
      const result = planMultiSportSchedule(sets, eventWindows, gap, rest, existingMatches ?? []);
      setPlan(result);
      if (!result.required) throw new Error('Nenhum confronto elegível foi encontrado.');
    } catch (e) { setPlan(null); setError(e instanceof Error ? e.message : 'Não foi possível calcular a agenda.'); } finally { setRegisteringSport(''); }
  };

  const publish = async () => {
    if (!supabase || !plan?.feasible) return;
    setSaving(true); setError('');
    try {
      const configsForSave = activeSports.map(s => ({ sport_id: s.id, sport_name: s.name, ...configs[s.id], advancing_per_group: configs[s.id]?.format === 'groups' ? 2 : null }));
      const resultForSave = { scheduled: plan.scheduled.map(m => ({ id: m.id, sport_id: m.sportId, category: m.category, date: m.date, duration: m.duration, court: m.court, start: m.start, end: m.end, home: m.home, away: m.away, round: m.round })), unscheduled: plan.unscheduled };
      const idempotencyKey = crypto.randomUUID();
      const { error: saveError } = await supabase.rpc('publish_multi_sport_schedule', { p_idempotency_key: idempotencyKey, p_config: { sports: configsForSave, interval_minutes: gap, team_rest_minutes: rest }, p_result: resultForSave });
      if (saveError) throw saveError;
      setSaved(true); setPlan(null); await onPublished();
    } catch (e) {
      const failure = e as { message?: string; details?: string; hint?: string; code?: string };
      const message = failure?.message || (e instanceof Error ? e.message : String(e));
      let guidance = '';
      if (failure?.code === 'PGRST202') guidance = 'A função de publicação não está disponível no Supabase. Aplique as migrations pendentes.';
      else if (/unresolved participants|invalid input syntax for type uuid|home_team_id.*null|away_team_id.*null/i.test(message)) guidance = 'Aplique a migration 202610290001_future_stage_schedule.sql para publicar semifinais e finais com participantes a definir.';
      else if (/Team rest conflict/i.test(message)) guidance = 'Aplique a migration 202610300008_gender_aware_schedule_conflicts.sql para separar equipes masculinas e femininas na validação de horários. Depois gere uma nova prévia.';
      else if (/Court time conflict/i.test(message)) guidance = 'Há sobreposição com jogos já publicados. Para duas partidas de voleibol na Quadra 1, aplique também 202610290003_parallel_volleyball.sql. Confira se esta tabela já foi publicada antes de tentar novamente.';
      setError([guidance, message, failure?.details, failure?.hint, failure?.code ? `Código: ${failure.code}` : ''].filter(Boolean).join(' — '));
    }
    finally { setSaving(false); }
  };

  const saveAvailability = async () => {
    if (!supabase) { setError('Configure a conexão com o Supabase para cadastrar janelas oficiais.'); return; }
    if (!eventDates.length || !eventStart || !eventEnd || eventStart >= eventEnd) {
      setError('Defina ao menos um dia e um intervalo de horário válido na configuração geral.'); return;
    }
    const missing = activeSports.filter(sport => !configs[sport.id]?.venues.length);
    if (missing.length) { setError(`Escolha ao menos um local nos cartões: ${missing.map(sport => sport.name).join(', ')}.`); return; }
    setSavingAvailability(true); setError(''); setAvailabilitySaved(false);
    let createdCount = 0;
    try {
      const planned = new Map<string, { court: string; date: string }>();
      activeSports.forEach(sport => configs[sport.id].venues.forEach(court => eventDates.forEach(date => planned.set(`${court}|${date}`, { court, date }))));
      const toCreate = [...planned.values()].filter(item => !windows.some(window => window.court === item.court && window.date === item.date && window.start === eventStart && window.end === eventEnd));
      for (const item of toCreate) {
        const { error: saveError } = await supabase.rpc('admin_create_court_availability', {
          p_court_name: item.court,
          p_event_date: item.date,
          p_start_time: eventStart,
          p_end_time: eventEnd,
        });
        if (saveError) {
          if (saveError.code === 'PGRST202') throw new Error('Aplique a migration 202610270013_court_availability_management.sql para habilitar o cadastro de janelas.');
          throw new Error(`${item.date} · ${item.court}: ${saveError.message}`);
        }
        createdCount += 1;
      }
      const { data, error: loadError } = await supabase.from('court_availability').select('*').order('available_from');
      if (loadError) throw loadError;
      const refreshedWindows: CourtWindow[] = (data ?? []).map((row: any) => ({
        court: row.court_name,
        date: localDate(row.available_from),
        start: localTime(row.available_from),
        end: localTime(row.available_until),
        blocked: [...(row.blocked_windows ?? []), ...(row.pause_windows ?? [])],
      }));
      setWindows(refreshedWindows);
      setPlan(null); setSaved(false);
      setAvailabilitySaved(true);
    } catch (e) {
      const message = e instanceof Error ? e.message : 'Não foi possível salvar as janelas no Supabase.';
      setError(createdCount ? `Parte da operação foi salva (${createdCount} janela(s)); falha ao continuar: ${message}` : message);
    } finally { setSavingAvailability(false); }
  };

  return <section className="schedule-builder multi-sport-builder">
    <div className="builder-heading"><div><div className="section-kicker">CONFIGURAÇÃO DO CALENDÁRIO</div><h3>Gerador de tabela · todas as modalidades</h3><p>Uma geração reúne os confrontos elegíveis de cada modalidade e categoria, somente com inscrições aprovadas.</p></div></div>
    {loading ? <div className="schedule-loading"><LoaderCircle size={17}/> Carregando modalidades, inscrições e janelas oficiais…</div> : <>
      <div className="schedule-bulk-setup">
        <div className="schedule-bulk-heading"><div><h4>Calendário geral</h4><p>Datas e horários padrão para todas as modalidades.</p></div></div>
        <div className="schedule-bulk-fields">
          <label>Dia do evento<input type="date" value={eventDateDraft} onChange={e => setEventDateDraft(e.target.value)}/></label>
          <button type="button" className="button secondary" disabled={!eventDateDraft} onClick={() => { updateEventDates([...eventDates, eventDateDraft]); setEventDateDraft(''); }}>Adicionar dia</button>
          <label>Início<input type="time" value={eventStart} onChange={e => { setEventStart(e.target.value); setPlan(null); setAvailabilitySaved(false); }}/></label>
          <label>Término<input type="time" value={eventEnd} onChange={e => { setEventEnd(e.target.value); setPlan(null); setAvailabilitySaved(false); }}/></label>
        </div>
        <div className="schedule-bulk-days">{eventDates.map(day => <button type="button" key={day} onClick={() => updateEventDates(eventDates.filter(d => d !== day))}>{new Date(`${day}T12:00:00`).toLocaleDateString('pt-BR')} ×</button>)}</div>
      </div>
      <div className="multi-sport-configs">{activeSports.map((sport, index) => {
        const cfg: Config = configs[sport.id] ?? { format: 'round_robin', dates: [], duration: 10, venues: [] };
        const selectedWindows = windows.filter(w => cfg.dates.includes(w.date ?? '') && cfg.venues.includes(w.court));
        return <article className="sport-schedule-card" key={sport.id}>
          <header><span className="sport-order">{String(index + 1).padStart(2, '0')}</span><div><h4>{sport.name}</h4><small>{teamCounts(sport.id)} turmas inscritas · {competitionCategories(sport.name).length === 4 ? 'Masculino e feminino separados' : 'Disputa única por faixa de anos'}</small></div></header>
          <div className="sport-schedule-fields">
            <label>Formato<select value={cfg.format} onChange={e => update(sport.id, { format: e.target.value as Format })}><option value="round_robin">Todos contra todos</option><option value="knockout">Mata-mata</option><option value="groups">Grupos · 2 grupos, avançam os 2 primeiros</option></select></label>
            <label>Duração da partida (min)<input type="number" min="1" max="240" value={cfg.duration} onChange={e => update(sport.id, { duration: Math.max(1, Number(e.target.value)) })} /></label>
          </div>
          <fieldset className="venue-picker"><legend>Locais permitidos para esta modalidade · salvos automaticamente</legend><div>{VENUES.map(venue => <label key={venue}><input type="checkbox" checked={cfg.venues.includes(venue)} onChange={e => update(sport.id, { venues: e.target.checked ? [...cfg.venues, venue] : cfg.venues.filter(v => v !== venue) })}/>{venue}</label>)}</div></fieldset>
          <details className="venue-picker"><summary>Turmas participantes</summary><p className="sport-window-note">Selecione as turmas participantes. No sorteio, turmas de 6º e 7º anos se enfrentam entre si; turmas de 8º, 9º, 1º e 2º anos se enfrentam entre si. Cada turma mantém sua própria equipe. Selecione masculino e feminino de forma independente; handebol, voleibol e queimada possuem disputa única.</p><div>{participantOptions(sport).map(option => {
            const ids = selectedParticipants(sport);
            return <label key={option.key}><input type="checkbox" checked={ids.includes(option.key)} onChange={e => { setRegistrationDrafts(current => ({ ...current, [sport.id]: e.target.checked ? [...ids, option.key] : ids.filter(id => id !== option.key) })); setPlan(null); }}/>{option.label}</label>;
          })}</div><button type="button" className="button secondary" disabled={!!registeringSport} onClick={() => void approveTeams(sport.id, selectedParticipants(sport))}>{registeringSport === sport.id ? 'Salvando…' : 'Confirmar equipes aprovadas'}</button></details>
          <p className="sport-window-note">{cfg.format === 'groups' ? 'Fase de grupos: dois grupos equilibrados, todos se enfrentam dentro do grupo e os 2 primeiros avançam. Semifinais dependem dos resultados.' : cfg.format === 'knockout' ? 'O sorteio agenda a primeira fase com equipes definidas; fases seguintes dependem dos resultados.' : teamCounts(sport.id) < 2 ? 'Sem jogos: são necessárias ao menos duas equipes aprovadas nesta modalidade.' : selectedWindows.length ? `Janelas oficiais: ${selectedWindows.map(w => `${w.date} · ${w.court} ${w.start}–${w.end}`).join(' · ')}` : 'Nenhuma janela oficial encontrada para os dias e locais escolhidos.'}</p>
        </article>;
      })}</div>
      <div className="builder-actions"><button type="button" className="button secondary" onClick={() => { setGap(0); setRest(0); setConfigs(current => Object.fromEntries(Object.entries(current).map(([id, config]) => [id, { ...config, duration: 10 }]))); setPlan(null); setSaved(false); }}>Restaurar padrões do sorteio</button><span className="draft-pending">10 min por partida · intervalo 0 · descanso 0 · até 3 jogos seguidos por esporte/local (exceto Tênis de Mesa, Basquete, Futmesa e Vôlei de Mesa) · alternância de esportes e turmas</span></div>
      <div className="builder-grid batch-rules"><label>Intervalo entre partidas (min)<input type="number" min="0" value={gap} onChange={e => { setGap(Math.max(0, Number(e.target.value))); setPlan(null); }}/></label><label>Descanso mínimo da equipe (min)<input type="number" min="0" value={rest} onChange={e => { setRest(Math.max(0, Number(e.target.value))); setPlan(null); }}/></label></div>
      <p className="schedule-warning">Ao pré-visualizar uma nova agenda completa, todos os jogos anteriores serão retirados da agenda ativa, inclusive jogos com resultados. A nova agenda só ficará pública após a publicação.</p><div className="builder-actions"><button className="button secondary" disabled={savingAvailability} onClick={() => void saveAvailability()}>Salvar calendário geral</button><button className="button secondary" disabled={loading || savingAvailability || !!registeringSport} onClick={() => void preview()}>Pré-visualizar agenda completa</button>{plan?.feasible && <button className="button primary" disabled={saving} onClick={publish}>{saving ? <LoaderCircle size={15}/> : <Check size={15}/>} Publicar todas as partidas</button>}{plan && <span className="draft-pending">Prévia · {plan.scheduled.length} jogos em {activeSports.length} modalidades</span>}</div>
      {error && <div className="form-error schedule-message">{error}</div>}{availabilitySaved && <div className="schedule-success">Dias, locais e horários salvos no Supabase.</div>}{saved && <div className="schedule-success">Tabela completa publicada com sucesso.</div>}
      {plan && <div className="schedule-preview"><div className="preview-summary"><div><span>Confrontos necessários</span><b>{plan.required}</b></div><div><span>Alocados</span><b>{plan.scheduled.length}</b></div><div><span>Sem horário</span><b className={plan.feasible ? 'good' : 'bad'}>{plan.unscheduled.length}</b></div><div><span>Viabilidade</span><b className={plan.feasible ? 'good' : 'bad'}>{plan.feasible ? 'Viável' : 'Ajuste necessário'}</b></div></div><div className="schedule-day-nav"><button type="button" className="button secondary" aria-label="Dia anterior" disabled={previewDateIndex <= 0} onClick={() => setPreviewDay(previewDates[previewDateIndex - 1])}><ChevronLeft size={18}/></button><div><b>{currentPreviewDate ? new Date(`${currentPreviewDate}T12:00:00`).toLocaleDateString('pt-BR') : 'Nenhum jogo alocado'}</b><small>{previewDates.length ? `Dia ${previewDateIndex + 1} de ${previewDates.length}` : ''}</small></div><button type="button" className="button secondary" aria-label="Próximo dia" disabled={previewDateIndex < 0 || previewDateIndex >= previewDates.length - 1} onClick={() => setPreviewDay(previewDates[previewDateIndex + 1])}><ChevronRight size={18}/></button></div>
<div className="schedule-venue-columns">{['Quadra 1', 'Quadra 2', 'Tênis de Mesa', 'Futmesa'].map(venue => {
  const matches = plan.scheduled.filter(match => match.date === currentPreviewDate && match.court === venue).sort((a,b) => a.start.localeCompare(b.start));
  const reserved = existingSchedule.filter(m=>m.scheduled_at&&localDate(m.scheduled_at)===currentPreviewDate&&(m.court_name??m.venue)===venue);
  const available = windows.filter(w=>w.date===currentPreviewDate&&w.court===venue);
  return <section className="schedule-venue-column" key={venue}><header><h4>{venue}</h4><span>{matches.length} novos · {reserved.length} existentes</span></header><div>{reserved.map((m,index)=><article className="venue-fixture" key={`existing-${index}`}><span className="venue-fixture-time">{localTime(m.scheduled_at!)} · Já cadastrado</span><b>{teamName(m.home_team_id??'A definir')} × {teamName(m.away_team_id??'A definir')}</b><small>{sportMatchLabel(activeSports.find(s=>s.id===m.sport_id)?.name??'Modalidade',m.category)}</small></article>)}{matches.map((m, index) => <article className="venue-fixture" key={`${m.sportId}-${m.category}-${m.id}-${index}`}><span className="venue-fixture-time">{m.start}–{m.end}</span><b>{teamName(m.home)} <span>×</span> {teamName(m.away)}</b><small className="match-division-label">{sportMatchLabel(m.sportName, m.category)}</small><small>{m.category} · {m.round}</small></article>)}{!matches.length && <p className="sport-window-note">{reserved.length?'Os horários dos jogos acima já estão reservados e não são publicados novamente.':!available.length?'Sem disponibilidade oficial cadastrada para este local nesta data. Salve o calendário geral.':'Sem novo confronto alocado: confira locais permitidos, inscrições e conflitos das turmas.'}</p>}</div></section>;
})}</div>{plan.unscheduled.map((m, i) => <div className="schedule-warning" key={`${m.sportId}-${m.fixture.id}-${i}`}>{m.sportName} · {teamName(m.fixture.home)} × {teamName(m.fixture.away)} — {m.reason}</div>)}</div>}
    </>}
  </section>;
}















