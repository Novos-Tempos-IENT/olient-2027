import { competitionCategories } from '../lib/competitionCategories';
import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { makeGroupFixtures } from '../lib/schedule';
import type { Sport, Team } from '../types/database';

export default function SportGroups({ sport, teams }: { sport: Sport; teams: Team[] }) {
  const [open, setOpen] = useState(false);
  const [groups, setGroups] = useState<{ category: string; name: string; ids: string[] }[]>([]);
  const [message, setMessage] = useState('');
  const show = async () => {
    setOpen(true); setMessage('Carregando grupos…'); setGroups([]);
    if (!supabase) { setMessage('Supabase indisponível.'); return; }
    const { data: published, error: publishedError } = await supabase.from('matches').select('home_team_id,away_team_id,category,round').eq('sport_id', sport.id).eq('schedule_status','published').is('deleted_at',null);
    if (publishedError) { setMessage(publishedError.message); return; }
    const official = new Map<string, {category:string;name:string;ids:string[]}>();
    for (const match of published ?? []) {
      const name = match.round?.match(/Grupo\s+([AB])/i)?.[1]?.toUpperCase();
      if (!name) continue;
      const category = match.category ?? 'Categoria não informada';
      const key = `${category}|${name}`;
      const group: {category:string;name:string;ids:string[]} = official.get(key) ?? {category,name,ids:[]};
      for (const id of [match.home_team_id,match.away_team_id]) if(id&&!group.ids.includes(id))group.ids.push(id);
      official.set(key,group);
    }
    if (official.size) { setGroups([...official.values()]); setMessage('Grupos oficiais dos jogos publicados deste esporte. Os dois primeiros avançam às semifinais.'); return; }
    if (published?.length) { setMessage('Os jogos publicados deste esporte não possuem fase de grupos.'); return; }
    const { data, error } = await supabase.from('registrations').select('team_id,category').eq('sport_id', sport.id).eq('status', 'approved');
    if (error) { setMessage(error.message); return; }
    let draft: any = null;
    try { draft = JSON.parse(localStorage.getItem('olient-schedule-draft-v1') ?? 'null'); } catch {}
    if (draft?.configs?.[sport.id]?.format !== 'groups') { setMessage('Esta modalidade ainda não possui uma configuração de disputa em grupos neste gerador.'); return; }
    const result: typeof groups = [];
    for (const category of competitionCategories(sport.name)) {
      const ids = [...new Set((data ?? []).filter(r => r.category === category && teams.some(t => t.id === r.team_id && t.active)).map(r => r.team_id))];
      if (ids.length < 4) continue;
      const fixtures = makeGroupFixtures(ids, 2027);
      for (const name of ['A', 'B']) {
        const matches = fixtures.filter(f => f.round.startsWith(`Grupo ${name} ·`));
        result.push({ category, name, ids: [...new Set(matches.flatMap(f => [f.home, f.away]))] });
      }
    }
    setGroups(result); setMessage(result.length ? 'Prévia do sorteio atual · os dois primeiros de cada grupo avançam às semifinais.' : 'São necessárias ao menos quatro turmas aprovadas por categoria para formar os grupos.');
  };
  return <><button type="button" className="button secondary sport-groups-button" onClick={() => void show()}>Ver grupos</button>{open && <div className="modal-overlay" onMouseDown={e => { if (e.target === e.currentTarget) setOpen(false); }}><section className="modal sport-groups-modal" role="dialog" aria-modal="true" aria-label={`Grupos de ${sport.name}`}><button className="modal-close" onClick={() => setOpen(false)} aria-label="Fechar">×</button><h2>{sport.name}</h2><p>{message}</p>{[...new Set(groups.map(group=>group.category))].map(category => <div key={category}>{groups.some(g => g.category === category) && <h3>{category}</h3>}{groups.filter(g => g.category === category).map(group => <section className="venue-picker" key={group.name}><h4>Grupo {group.name}</h4>{group.ids.map(id => <p key={id}>{teams.find(t => t.id === id)?.name ?? id}</p>)}</section>)}</div>)}</section></div>}</>;
}

