import { useEffect, useState } from 'react';
import { CalendarDays, Clock3, Trophy } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { GincanaItem, GincanaSection } from '../lib/gincanaProgram';
import type { Team } from '../types/database';

const formatDate = (value: string) => new Date(`${value}T12:00:00`).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
const formatPoints = (value: number | null) => value === null ? '—' : value.toLocaleString('pt-BR');
type SportAward = { sport_id: string; sport_name: string; champion_name: string | null; champion_points: number | null; champion_status: string; runner_up_name: string | null; runner_up_points: number | null; runner_up_status: string };
type TeamTotal = { team_id: string; team_name: string; sports_points: number; other_points: number; champion_bonus: number; runner_up_bonus: number; final_points: number; place: number };
type ItemScore = { team_id: string; score_type: 'standard' | 'variable'; points: number };

export default function GincanaPanel({ admin = false, teams = [] }: { admin?: boolean; teams?: Team[] }) {
  const [sections, setSections] = useState<GincanaSection[]>([]);
  const [items, setItems] = useState<GincanaItem[]>([]);
  const [sportAwards, setSportAwards] = useState<SportAward[]>([]);
  const [teamTotals, setTeamTotals] = useState<TeamTotal[]>([]);
  const [pointDrafts, setPointDrafts] = useState<Record<string,string>>({});
  const [savingPointId, setSavingPointId] = useState('');
  const [pointError, setPointError] = useState<{ id: string; message: string } | null>(null);
  const [selectedItem, setSelectedItem] = useState<GincanaItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const pointsLabel = (item: GincanaItem) => item.points_value !== null
    ? `${item.points_value.toLocaleString('pt-BR')} pontos`
    : 'Valor não definido';
  const saveItemPoints = async (item: GincanaItem) => {
    if (!admin) return;
    const raw = pointDrafts[item.id] ?? (item.points_value === null ? '' : String(item.points_value));
    const value = raw.trim() === '' ? null : Number(raw);
    if (value !== null && (!Number.isFinite(value) || value < 0 || value > 1000000000)) {
      setPointError({ id: item.id, message: 'Informe um valor entre 0 e 1.000.000.000.' }); return;
    }
    if (value === item.points_value) { setPointDrafts(current => { const next={...current}; delete next[item.id]; return next; }); return; }
    if (!supabase) {
      setPointError({ id: item.id, message: 'Supabase não está configurado. O valor não foi salvo.' });
      return;
    }
    if (item.id.startsWith('local-item-')) {
      setPointError({ id: item.id, message: 'Não foi enviado ao Supabase. Aplique as migrations 008 (atividades) e 011 (valor em pontos) e recarregue a página.' });
      return;
    }
    setSavingPointId(item.id); setPointError(null);
    const { error: saveError } = await supabase.rpc('set_gincana_program_item_points', { p_item_id: item.id, p_points: value });
    setSavingPointId('');
    if (saveError) {
      const message = saveError.code === 'PGRST202' ? 'Aplique a migration 202610270011_gincana_item_points.sql no Supabase.' : saveError.message;
      setPointError({ id: item.id, message }); return;
    }
    setItems(current => current.map(row => row.id === item.id ? { ...row, points_value: value } : row));
    setPointDrafts(current => { const next={...current}; delete next[item.id]; return next; });
  };
  const sportAwardFor = (title: string) => {
    const normalized = title.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR');
    const key = normalized.includes('basquete') ? 'basquete'
      : normalized.includes('dodgeball') ? 'queimada'
        : normalized.includes('futsal') ? 'futsal'
          : normalized.includes('handebol') ? 'handebol'
            : normalized.includes('tenis de mesa') ? 'tenis de mesa'
              : normalized.includes('futmesa') ? 'futmesa'
                : normalized.includes('volei de mesa') ? 'volei de mesa'
                  : normalized.includes('voleibol') ? 'voleibol' : '';
    return sportAwards.find(award => award.sport_name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR').includes(key));
  };
  const renderProgramItem = (section: GincanaSection, item: GincanaItem) => {
    const isSport = section.name === 'Esportes';
    const award = isSport ? sportAwardFor(item.title) : undefined;
    return <article className={`gincana-item ${isSport ? 'sport-program-item' : ''}`} key={item.id}>
      {isSport ? <span>{item.title}</span> : <button type="button" className="gincana-item-title" onClick={() => setSelectedItem(item)}>{item.title}<small>Distribuir pontos →</small></button>}
      {isSport ? <div className="sport-award-pair">
        {award?.champion_points !== null && award?.champion_points !== undefined && award.champion_name && <small className="sport-award-chip"><b>{award.champion_name}</b><span>{formatPoints(award.champion_points)} pontos</span></small>}
        {award?.runner_up_points !== null && award?.runner_up_points !== undefined && award.runner_up_name && <small className="sport-award-chip"><b>{award.runner_up_name}</b><span>{formatPoints(award.runner_up_points)} pontos</span></small>}
      </div> : admin ? <label className="gincana-point-editor"><span>Valor em pontos</span><input type="number" min="0" max="1000000000" step="1" aria-label={`Valor em pontos para ${item.title}`} placeholder="Definir pontos" value={pointDrafts[item.id] ?? (item.points_value === null ? '' : String(item.points_value))} disabled={savingPointId===item.id} onChange={event => { setPointDrafts(current => ({ ...current,[item.id]:event.target.value })); setPointError(null); }} onBlur={() => void saveItemPoints(item)} onKeyDown={event => { if (event.key === 'Enter') { event.preventDefault(); event.currentTarget.blur(); } }}/>{savingPointId===item.id && <small>Sincronizando…</small>}{pointError?.id===item.id && <small className="gincana-point-error">{pointError.message}</small>}</label> : <small className="gincana-points-readonly">{pointsLabel(item)}</small>}
    </article>;
  };
  useEffect(() => {
    let mounted = true;
    const load = async () => {
      if (mounted) setError('');
      if (!supabase) { setSections([]); setItems([]); setError('Configure a conexão com o Supabase para carregar a programação oficial.'); setLoading(false); return; }
      try {
        const [s, i] = await Promise.all([
          supabase.from('gincana_program_sections').select('id,name,sort_order').order('sort_order'),
          supabase.from('gincana_program_items').select('id,section_id,event_date,title,sort_order,champion_points,runner_up_points,points_value').order('sort_order'),
        ]);
        if (s.error || i.error) {
          const failure = s.error ?? i.error;
          const details = failure as { code?: string; message?: string };
          if (details.code === 'PGRST205' || details.message?.includes('gincana_program_')) {
            if (mounted) { setSections([]); setItems([]); setError('A programação ainda não foi criada no banco conectado. Aplique as migrations da Gincana antes de consultar ou editar seus dados.'); }
            return;
          }
          throw failure;
        }
        if (mounted) { setSections(s.data ?? []); setItems(i.data ?? []); }
        const [awards, totals] = await Promise.all([
          supabase.from('public_gincana_sport_awards').select('*').order('sport_name'),
          supabase.from('public_gincana_totals').select('*').order('place').order('team_name'),
        ]);
        if (!mounted) return;
        if (awards.error || totals.error) {
          const failure = awards.error ?? totals.error;
          const details = failure as { code?: string; message?: string };
          setError(`Aplique a migration 202610270010_gincana_auto_results_and_totals.sql para exibir resultados e totais automaticamente.${details.message ? ` ${details.message}` : ''}`);
        } else {
          setSportAwards(awards.data ?? []);
          setTeamTotals(totals.data ?? []);
        }
      } catch (e) {
        if (!mounted) return;
        const details = e as { message?: string; code?: string };
        setSections([]); setItems([]); setSportAwards([]); setTeamTotals([]);
        setError(details.message ? `${details.message}${details.code ? ` (${details.code})` : ''}` : 'falha não identificada');
      } finally { if (mounted) setLoading(false); }
    };
    void load();
    if (!supabase) return () => { mounted = false; };
    let timer: ReturnType<typeof setTimeout> | undefined;
    const channel=supabase.channel('olient-gincana-sync')
      .on('postgres_changes',{event:'*',schema:'public',table:'gincana_program_sections'},()=>{if(timer)clearTimeout(timer);timer=setTimeout(()=>void load(),150);})
      .on('postgres_changes',{event:'*',schema:'public',table:'gincana_program_items'},()=>{if(timer)clearTimeout(timer);timer=setTimeout(()=>void load(),150);})
      .on('postgres_changes',{event:'*',schema:'public',table:'gincana_item_scores'},()=>{if(timer)clearTimeout(timer);timer=setTimeout(()=>void load(),150);})
      .on('postgres_changes',{event:'*',schema:'public',table:'score_ledger'},()=>{if(timer)clearTimeout(timer);timer=setTimeout(()=>void load(),150);})
      .on('postgres_changes',{event:'*',schema:'public',table:'matches'},()=>{if(timer)clearTimeout(timer);timer=setTimeout(()=>void load(),150);})
      .on('postgres_changes',{event:'*',schema:'public',table:'sports'},()=>{if(timer)clearTimeout(timer);timer=setTimeout(()=>void load(),150);})
      .subscribe();
    return () => { mounted = false; if(timer)clearTimeout(timer);void supabase?.removeChannel(channel); };
  }, []);

  return <div className="panel full-panel gincana-page">
    <div className="gincana-hero"><div><div className="section-kicker">DESAFIOS E CONHECIMENTO · OLIENT 2027</div><h2>Programação da Gincana</h2><p>Atividades, ações e disputas organizadas por categoria e data.</p></div><span className="gincana-icon"><Trophy size={22}/></span></div>
    {loading ? <div className="empty-state"><span><Clock3 size={18}/></span><p>Carregando programação…</p></div> : <>{error && <div className="schedule-warning">{error}</div>}<div className="gincana-date-layout">
      {[...new Set(items.flatMap(item => item.event_date ? [item.event_date] : []))].sort().map(date => <section className="gincana-day" key={date}>
        <header className="gincana-day-heading"><CalendarDays size={16}/><h3>{formatDate(date)}</h3></header>
        <div className="gincana-day-categories">{sections.map(section => {
          const dayItems = items.filter(item => item.section_id === section.id && item.event_date === date);
          if (!dayItems.length) return null;
          return <section className={`gincana-category ${section.name === 'Esportes' ? 'gincana-sport-category' : ''}`} key={section.id}><h4>{section.name}</h4><div className="gincana-list">{dayItems.map(item => renderProgramItem(section,item))}</div></section>;
        })}</div>
      </section>)}
      <section className="gincana-day gincana-undated"><header className="gincana-day-heading"><CalendarDays size={16}/><h3>Data a definir</h3></header><p>Estes itens não tinham uma data indicada na programação recebida.</p>
        <div className="gincana-day-categories">{sections.map(section => {
          const undated = items.filter(item => item.section_id === section.id && !item.event_date);
          if (!undated.length) return null;
          return <section className={`gincana-category ${section.name === 'Esportes' ? 'gincana-sport-category' : ''}`} key={section.id}><h4>{section.name}</h4><div className="gincana-list">{undated.map(item => renderProgramItem(section,item))}</div></section>;
        })}</div>
        {sections.filter(section => section.name === 'Punições').every(section => !items.some(item => item.section_id === section.id)) && <p className="gincana-empty">Nenhum item de punição foi informado.</p>}
      </section>
    </div></>}
    <section className="gincana-auto-table"><header><div><div className="section-kicker">CONSOLIDADO DA COMPETIÇÃO</div><h3>Pontuação final por equipe</h3></div><span>Pontuação esportiva e da Gincana consolidada</span></header><div className="table-wrap"><table><thead><tr><th>POS.</th><th>EQUIPE</th><th className="align-right">ESPORTES</th><th className="align-right">GINCANA E OUTROS</th><th className="align-right">TOTAL FINAL</th></tr></thead><tbody>{teamTotals.length ? teamTotals.map(total => <tr key={total.team_id}><td data-label="Posição">{String(total.place).padStart(2,'0')}</td><td data-label="Equipe"><b>{total.team_name}</b></td><td className="align-right" data-label="Esportes">{formatPoints(Number(total.sports_points)+Number(total.champion_bonus)+Number(total.runner_up_bonus))}</td><td className="align-right" data-label="Gincana e outros">{formatPoints(total.other_points)}</td><td className="align-right" data-label="Total final"><b>{formatPoints(total.final_points)}</b></td></tr>) : <tr><td colSpan={5} className="table-empty">A soma será exibida quando a consulta de totais estiver ativa.</td></tr>}</tbody></table></div></section>
    <p className="gincana-footnote">A pontuação das modalidades e das atividades da Gincana é consolidada automaticamente no total final.</p>
    {selectedItem && <GincanaScoreModal item={selectedItem} teams={teams} admin={admin} close={() => setSelectedItem(null)} onSaved={async () => { if (!supabase) return; const { data } = await supabase.from('public_gincana_totals').select('*').order('place').order('team_name'); if (data) setTeamTotals(data as TeamTotal[]); }}/ >}
  </div>;
}

function GincanaScoreModal({ item, teams, admin, close, onSaved }: { item: GincanaItem; teams: Team[]; admin: boolean; close: () => void; onSaved: () => Promise<void> }) {
  const [assignments, setAssignments] = useState<ItemScore[]>([]);
  const [variableDrafts, setVariableDrafts] = useState<Record<string,string>>({});
  const [variableValues, setVariableValues] = useState<Record<string,string>>({});
  const [query, setQuery] = useState('');
  const [selectedTeamId, setSelectedTeamId] = useState('');
  const [poolDragOver, setPoolDragOver] = useState(false);
  const [loading, setLoading] = useState(true);
  const [savingTeamId, setSavingTeamId] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      if (!supabase) { setError('Conecte o Supabase e aplique a migration 202610270012_gincana_item_scores.sql.'); setLoading(false); return; }
      const { data, error: loadError } = await supabase.from('gincana_item_scores').select('team_id,score_type,points').eq('item_id',item.id);
      if (!mounted) return;
      if (loadError) setError(loadError.code === 'PGRST205' ? 'Aplique a migration 202610270012_gincana_item_scores.sql no Supabase.' : loadError.message);
      else setAssignments((data ?? []) as ItemScore[]);
      setLoading(false);
    };
    void load();
    return () => { mounted = false; };
  }, [item.id]);

  const assignedIds = new Set([...assignments.map(x => x.team_id), ...Object.keys(variableDrafts)]);
  const availableTeams = teams.filter(team => !assignedIds.has(team.id) && team.name.toLocaleLowerCase('pt-BR').includes(query.toLocaleLowerCase('pt-BR'))).sort((a,b) => a.name.localeCompare(b.name,'pt-BR',{numeric:true}));
  const saveAssignment = async (teamId: string, scoreType: 'standard'|'variable', points: number) => {
    if (!admin || !supabase) return;
    setSavingTeamId(teamId); setError('');
    const { error: saveError } = await supabase.rpc('set_gincana_item_result', { p_item_id: item.id, p_team_id: teamId, p_score_type: scoreType, p_points: points });
    setSavingTeamId('');
    if (saveError) { setError(saveError.code === 'PGRST202' ? 'Aplique a migration 202610270012_gincana_item_scores.sql no Supabase.' : saveError.message); return; }
    setAssignments(current => [...current.filter(x => x.team_id !== teamId), { team_id: teamId, score_type: scoreType, points }]);
    setVariableDrafts(current => { const next={...current}; delete next[teamId]; return next; });
    setVariableValues(current => { const next={...current}; delete next[teamId]; return next; });
    setSelectedTeamId('');
    await onSaved();
  };
  const removeAssignment = async (teamId: string) => {
    if (!admin || !supabase) return;
    setSavingTeamId(teamId); setError('');
    const { error: removeError } = await supabase.rpc('remove_gincana_item_result', { p_item_id: item.id, p_team_id: teamId });
    setSavingTeamId('');
    if (removeError) { setError(removeError.message); return; }
    setAssignments(current => current.filter(x => x.team_id !== teamId));
    await onSaved();
  };
  const returnTeamToPool = async (teamId: string) => {
    if (!admin || !teamId) return;
    if (Object.prototype.hasOwnProperty.call(variableDrafts,teamId)) {
      setVariableDrafts(current => { const next={...current}; delete next[teamId]; return next; });
      setVariableValues(current => { const next={...current}; delete next[teamId]; return next; });
      setError('');
      return;
    }
    if (assignments.some(assignment => assignment.team_id===teamId)) await removeAssignment(teamId);
  };
  const dropTeam = (scoreType: 'standard'|'variable', teamId: string) => {
    if (!admin || !teamId) return;
    if (scoreType === 'standard') {
      if (item.points_value === null) { setError('Defina primeiro o valor padrão desta atividade.'); return; }
      void saveAssignment(teamId,'standard',item.points_value);
    } else {
      setVariableDrafts(current => ({...current,[teamId]:current[teamId]??''}));
      setSelectedTeamId(''); setError('');
    }
  };
  const renderAssigned = (scoreType: 'standard'|'variable') => assignments.filter(x => x.score_type===scoreType).map(assignment => <article className="gincana-assigned-team" key={assignment.team_id} draggable={admin} onDragStart={event => { event.dataTransfer.effectAllowed='move'; event.dataTransfer.setData('text/plain',assignment.team_id); }}><b>{teams.find(x => x.id===assignment.team_id)?.name ?? 'Turma'}</b><span>{formatPoints(assignment.points)} pts</span>{admin && <button type="button" disabled={savingTeamId===assignment.team_id} onClick={() => void removeAssignment(assignment.team_id)} aria-label="Remover turma desta pontuação">×</button>}</article>);

  return <div className="modal-overlay gincana-score-overlay" onMouseDown={event => { if (event.target===event.currentTarget) close(); }}><section className="gincana-score-modal" role="dialog" aria-modal="true" aria-labelledby="gincana-score-title">
    <header className="gincana-score-heading"><div><div className="section-kicker">DISTRIBUIÇÃO DA ATIVIDADE</div><h2 id="gincana-score-title">{item.title}</h2><p>Arraste as turmas para a pontuação padrão ou variável.</p></div><button type="button" onClick={close} aria-label="Fechar">×</button></header>
    {loading ? <div className="schedule-loading">Carregando turmas e pontos registrados…</div> : <div className="gincana-assignment-layout">
      <section className={`gincana-team-pool ${poolDragOver?'is-drop-target':''}`} onDragOver={event => { event.preventDefault(); event.dataTransfer.dropEffect='move'; }} onDragEnter={() => setPoolDragOver(true)} onDragLeave={event => { if (!event.currentTarget.contains(event.relatedTarget as Node|null)) setPoolDragOver(false); }} onDrop={event => { event.preventDefault(); setPoolDragOver(false); void returnTeamToPool(event.dataTransfer.getData('text/plain')); }}><h3>Turmas disponíveis</h3><input type="search" value={query} onChange={event => setQuery(event.target.value)} placeholder="Buscar turma…" aria-label="Buscar turma"/><div className="gincana-team-list">{availableTeams.map(team => <button type="button" draggable={admin} key={team.id} className={`gincana-team-token ${selectedTeamId===team.id?'selected':''}`} onClick={() => setSelectedTeamId(team.id)} onDragStart={event => { event.dataTransfer.effectAllowed='move'; event.dataTransfer.setData('text/plain',team.id); }}>{team.name}</button>)}{!availableTeams.length && <p>Nenhuma turma disponível.</p>}</div>{selectedTeamId && admin && <div className="gincana-keyboard-actions"><span>Selecionada: {teams.find(x=>x.id===selectedTeamId)?.name}</span><button type="button" disabled={item.points_value===null} onClick={() => dropTeam('standard',selectedTeamId)}>Pontuação padrão</button><button type="button" onClick={() => dropTeam('variable',selectedTeamId)}>Pontuação variável</button></div>}<small className="gincana-return-hint">Arraste para cá uma turma atribuída para devolvê-la à lista.</small></section>
      <div className="gincana-score-zones"><section className="gincana-score-zone standard" onDragOver={event => event.preventDefault()} onDrop={event => {event.preventDefault();dropTeam('standard',event.dataTransfer.getData('text/plain'));}}><header><h3>Pontuação padrão</h3><b>{item.points_value===null?'Valor não definido':`${formatPoints(item.points_value)} pontos`}</b></header><p>A turma recebe o valor indicado nesta atividade.</p>{renderAssigned('standard')}{!assignments.some(x=>x.score_type==='standard')&&<div className="gincana-drop-hint">Solte uma turma aqui</div>}</section>
        <section className="gincana-score-zone variable" onDragOver={event => event.preventDefault()} onDrop={event => {event.preventDefault();dropTeam('variable',event.dataTransfer.getData('text/plain'));}}><header><h3>Pontuação variável</h3><b>Definida por turma</b></header><p>Informe quantos pontos a turma recebe.</p>{Object.keys(variableDrafts).map(teamId => <div className="gincana-variable-row" key={teamId} draggable={admin} onDragStart={event => { event.dataTransfer.effectAllowed='move'; event.dataTransfer.setData('text/plain',teamId); }}><b>{teams.find(x=>x.id===teamId)?.name}</b><input type="number" min="0" max="1000000000" step="1" placeholder="Pontos" value={variableValues[teamId]??''} onChange={event=>setVariableValues(current=>({...current,[teamId]:event.target.value}))}/><button type="button" disabled={!variableValues[teamId] || savingTeamId===teamId} onClick={()=>void saveAssignment(teamId,'variable',Number(variableValues[teamId]))}>Salvar</button></div>)}{renderAssigned('variable')}{!assignments.some(x=>x.score_type==='variable')&&!Object.keys(variableDrafts).length&&<div className="gincana-drop-hint">Solte uma turma aqui</div>}</section></div>
    </div>}
    {error && <div className="form-error gincana-score-error">{error}</div>}
    <footer className="gincana-score-footer"><span>{admin?'Os pontos são salvos ao confirmar cada turma.':'Visualização dos pontos registrados para esta atividade.'}</span><button type="button" className="button secondary" onClick={close}>Fechar</button></footer>
  </section></div>;
}
