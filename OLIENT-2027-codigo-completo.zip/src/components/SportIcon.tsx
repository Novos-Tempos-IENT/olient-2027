import type { ReactNode } from 'react';
export default function SportIcon({name,size=20}:{name:string;size?:number}) {
 const sport=name.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
 const ball=<><circle cx="12" cy="12" r="9"/><path d="m9 9 6 0 2 5-5 4-5-4zM9 9 7 5m8 4 3-4M7 14l-4 1m14-1 4 1m-9 3v3"/></>;
 const volley=<><circle cx="12" cy="12" r="9"/><path d="M12 12C9 9.5 8 6 9 3.5M12 12c3.7-1.3 6.8-.8 8.7 1.5M12 12c-.7 3.8-2.5 6.5-5.3 7.3M5.6 5.6C5.8 9 7 12 9 14M15.1 3.6c-1.8 2.1-2.8 4.5-2.7 7.2M20.5 8.9c-2.7-.6-5.3-.3-7.7.9M18.4 18.4c-1.2-3.1-3.1-5.4-5.5-6.6M11.8 21c2.1-2.1 3.4-4.5 3.8-7.3M3.2 13.8c2.8.8 5.5.6 8-.5"/></>;
 let shape:ReactNode=ball;
 if(sport.includes('BASQUETE'))shape=<><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3v18M5.5 5.5c8 1 12 5 13 13M18.5 5.5c-8 1-12 5-13 13"/></>;
 else if(sport.includes('TENIS'))shape=<><path d="M14 3a7 7 0 0 1 5 12c-2 2-5 2-7 1l-5 5-3-3 5-5a7 7 0 0 1 5-10Z"/><path d="m9 12 7 5"/><circle cx="4" cy="5" r="2"/></>;
 else if(sport.includes('MESA'))shape=<><path d="M3 8h18v9H3zM12 6v11M5 17v4m14-4v4M1 11h22"/>{sport.includes('FUT')?<circle cx="7" cy="4" r="2"/>:<path d="M6 2a2 2 0 1 0 3 2M6 2l3 2"/>}</>;
 else if(sport.includes('VOLEI'))shape=volley;
 else if(sport.includes('HANDEBOL'))shape=<><circle cx="12" cy="12" r="9"/><path d="m12 7 5 3-2 6H9l-2-6zM12 3v4m5 3 3-3m-5 9 3 3M9 16l-3 3m1-9L4 7"/></>;
 else if(sport.includes('QUEIMADA'))shape=<><circle cx="15" cy="12" r="7"/><path d="M9 8c6 0 9 3 10 9M10 17c1-5 4-8 9-9M2 7h4M1 12h4M2 17h4"/></>;
 return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{flexShrink:0}}>{shape}</svg>;
}
