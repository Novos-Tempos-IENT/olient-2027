import { useMemo, useState } from 'react';
import { Printer } from 'lucide-react';
import type { Sport, Team } from '../types/database';
import '../official-bulletin.css';

export type BulletinMatch = {
  id: string; sport_id: string; category?: string | null; round: string | null;
  scheduled_at: string | null; venue: string | null; court_name?: string | null;
  home_team_id: string; away_team_id: string; home_score: number | null; away_score: number | null;
  postponed?: boolean; postponement_reason?: string | null; schedule_status?: string | null; deleted_at?: string | null;
};

const dateInBetim = (value: string) => new Intl.DateTimeFormat('pt-BR', {timeZone:'America/Sao_Paulo',weekday:'long',day:'2-digit',month:'long',year:'numeric'}).format(new Date(value));
const timeInBetim = (value: string) => new Intl.DateTimeFormat('pt-BR', {timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit'}).format(new Date(value));
const shortDate = (value: string) => new Intl.DateTimeFormat('pt-BR', {timeZone:'America/Sao_Paulo',day:'2-digit',month:'2-digit',year:'numeric'}).format(new Date(value));

export default function OfficialBulletin({matches,teams,sports}:{matches:BulletinMatch[];teams:Team[];sports:Sport[]}) {
  const [number,setNumber]=useState('01');
  const published=useMemo(()=>matches.filter(m=>!m.deleted_at&&m.schedule_status!=='cancelled'),[matches]);
  const teamName=(id:string)=>teams.find(team=>team.id===id)?.name??'Equipe';
  const sportName=(id:string)=>sports.find(sport=>sport.id===id)?.name??'Modalidade';
  const eventDates=[...new Set(published.map(match=>match.scheduled_at?shortDate(match.scheduled_at):'Data a definir'))];
  const locations=[...new Set(published.map(match=>match.court_name??match.venue).filter((value):value is string=>!!value))].sort((a,b)=>a.localeCompare(b,'pt-BR'));
  const postponed=published.filter(match=>match.postponed).sort((a,b)=>(a.scheduled_at??'').localeCompare(b.scheduled_at??''));
  const completedFinals=published.filter(match=>match.round&&/final/i.test(match.round)&&!/semi/i.test(match.round)&&match.home_score!==null&&match.away_score!==null&&match.home_score!==match.away_score);
  const champions=[...new Map(completedFinals.map(match=>{
    const winner=match.home_score!>match.away_score!?match.home_team_id:match.away_team_id;
    const key=`${match.sport_id}:${match.category??''}`;
    return [key,{key,sport:sportName(match.sport_id),category:match.category,team:teamName(winner)}] as const;
  })).values()];
  const dayGroups=[...new Map(published.map(match=>[match.scheduled_at?new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo'}).format(new Date(match.scheduled_at)):'unknown',match.scheduled_at?dateInBetim(match.scheduled_at):'Data a definir'] as const).map(([key,label])=>[key,{key,label,matches:published.filter(match=>(match.scheduled_at?new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo'}).format(new Date(match.scheduled_at)):'unknown')===key)}])).values()];
  return <section className="official-bulletin">
    <div className="bulletin-actions"><div><div className="section-kicker">DOCUMENTO OFICIAL DA COMPETIÇÃO</div><h3>Boletim oficial</h3><p>Boletim pronto para impressão com calendário, jogos adiados, campeões e resultados cadastrados.</p></div><div className="bulletin-toolbar"><label>Nº do boletim<input aria-label="Número do boletim" value={number} maxLength={8} onChange={event=>setNumber(event.target.value)}/></label><button className="button primary" onClick={()=>window.print()}><Printer size={15}/>Imprimir boletim</button></div></div>
    <article id="olient-official-bulletin" className="bulletin-document">
      <header className="bulletin-cover"><img className="bulletin-school-logo" src="/logo-novos-tempos.png" alt="Colégio Novos Tempos"/><div className="bulletin-number">BOLETIM OFICIAL Nº {number||'—'}</div><h1>OLIENT <em>2027</em></h1><p>COMPETIÇÃO, ESPORTE E ESPÍRITO DE EQUIPE</p></header>
      <section className="bulletin-section"><h2>1. DATAS DOS JOGOS</h2>{eventDates.length?<ul>{eventDates.map(day=><li key={day}>{day}</li>)}</ul>:<p className="bulletin-empty">Nenhuma data de jogo cadastrada.</p>}</section>
      <section className="bulletin-section"><h2>2. LOCAIS DOS JOGOS</h2>{locations.length?<ul className="bulletin-locations">{locations.map(location=><li key={location}>{location}</li>)}</ul>:<p className="bulletin-empty">Nenhum local cadastrado.</p>}</section>
      <section className="bulletin-section"><h2>3. JOGOS ADIADOS / REAGENDADOS</h2>{postponed.length?<div className="bulletin-table-wrap"><table className="bulletin-table"><thead><tr><th>MODALIDADE</th><th>CONFRONTO</th><th>NOVA DATA</th><th>LOCAL</th><th>MOTIVO</th></tr></thead><tbody>{postponed.map(match=><tr key={match.id}><td>{sportName(match.sport_id)}{match.category?` · ${match.category}`:''}</td><td>{teamName(match.home_team_id)} × {teamName(match.away_team_id)}</td><td>{match.scheduled_at?`${shortDate(match.scheduled_at)} · ${timeInBetim(match.scheduled_at)}`:'A definir'}</td><td>{match.court_name??match.venue??'A definir'}</td><td>{match.postponement_reason||'Horário atualizado pela organização.'}</td></tr>)}</tbody></table></div>:<p className="bulletin-empty">Nenhuma partida foi adiada.</p>}</section>
      <section className="bulletin-section"><h2>4. EQUIPES CAMPEÃS</h2>{champions.length?<div className="bulletin-table-wrap"><table className="bulletin-table"><thead><tr><th>MODALIDADE</th><th>CATEGORIA</th><th>EQUIPE CAMPEÃ</th></tr></thead><tbody>{champions.map(champion=><tr key={champion.key}><td>{champion.sport}</td><td>{champion.category||'Geral'}</td><td><b>{champion.team}</b></td></tr>)}</tbody></table></div>:<p className="bulletin-empty">Os campeões aparecerão após o registro e a confirmação das partidas finais.</p>}</section>
      <section className="bulletin-section bulletin-results"><h2>5. RESULTADOS E PROGRAMAÇÃO DOS JOGOS</h2>{dayGroups.length?dayGroups.map(day=><section className="bulletin-day" key={day.key}><h3>{day.label}</h3>{[...new Set(day.matches.map(match=>match.court_name??match.venue??'Local a definir'))].sort((a,b)=>a.localeCompare(b,'pt-BR')).map(location=><div className="bulletin-location-group" key={location}><h4>{location}</h4><div className="bulletin-table-wrap"><table className="bulletin-table"><thead><tr><th>HORÁRIO</th><th>MODALIDADE / FASE</th><th>JOGO / RESULTADO</th></tr></thead><tbody>{day.matches.filter(match=>(match.court_name??match.venue??'Local a definir')===location).sort((a,b)=>(a.scheduled_at??'').localeCompare(b.scheduled_at??'')).map(match=><tr key={match.id}><td>{match.scheduled_at?timeInBetim(match.scheduled_at):'A definir'}</td><td>{sportName(match.sport_id)}{match.category?` · ${match.category}`:''}{match.round?` · ${match.round}`:''}{match.postponed?' *':''}</td><td>{teamName(match.home_team_id)} {match.home_score??'—'} × {match.away_score??'—'} {teamName(match.away_team_id)}{match.postponed&&<small className="bulletin-postponed-note">ADIADO / REAGENDADO</small>}</td></tr>)}</tbody></table></div></div>)}</section>):<p className="bulletin-empty">Nenhuma partida publicada para incluir neste boletim.</p>}</section>
      <footer className="bulletin-footer"><b>OLIENT 2027 · COLÉGIO NOVOS TEMPOS · UNIDADE BETIM</b><span>Documento gerado em {new Intl.DateTimeFormat('pt-BR',{timeZone:'America/Sao_Paulo',day:'2-digit',month:'2-digit',year:'numeric'}).format(new Date())}</span></footer>
    </article>
  </section>;
}
