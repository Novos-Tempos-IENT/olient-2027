import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { Plus, Search, Users } from 'lucide-react';
import { isSupabaseConfigured } from '../lib/supabase';
import { createClass, createStudent, getClasses, getStudents } from '../services/competition';
import type { SchoolClass, Student } from '../types/database';

export default function ClassesStudentsPanel({ canManage }: { canManage: boolean }) {
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [query, setQuery] = useState('');
  const [className, setClassName] = useState('');
  const [grade, setGrade] = useState('');
  const [shift, setShift] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [studentCode, setStudentCode] = useState('');
  const [classId, setClassId] = useState('');

  const load = async () => {
    if (!isSupabaseConfigured) {
      setError('Configure a conexão com o Supabase para carregar turmas e alunos.');
      setLoading(false);
      return;
    }
    setLoading(true);
    setError('');
    try {
      const [classRows, studentRows] = await Promise.all([getClasses(), getStudents()]);
      setClasses(classRows);
      setStudents(studentRows.filter(student => student.active));
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Não foi possível carregar os registros.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const classNames = useMemo(() => new Map(classes.map(item => [item.id, item.name])), [classes]);
  const filteredStudents = useMemo(() => {
    const term = query.trim().toLocaleLowerCase('pt-BR');
    if (!term) return students;
    return students.filter(student => `${student.first_name} ${student.last_name} ${student.student_code ?? ''} ${classNames.get(student.class_id ?? '') ?? ''}`.toLocaleLowerCase('pt-BR').includes(term));
  }, [students, query, classNames]);

  const save = async (event: FormEvent, action: () => Promise<void>, message: string, reset: () => void) => {
    event.preventDefault();
    setSaving(true);
    setError('');
    setSuccess('');
    try {
      await action();
      reset();
      await load();
      setSuccess(message);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Não foi possível salvar o registro.');
    } finally {
      setSaving(false);
    }
  };

  return <div className="panel full-panel academic-panel">
    <div className="panel-head academic-heading">
      <div><div className="section-kicker">CADASTRO INSTITUCIONAL</div><h2>Turmas e alunos</h2><p>Consulte os registros escolares e vincule cada aluno à sua turma.</p></div>
      <div className="academic-count"><Users size={16}/><span><b>{classes.length}</b> turmas <i>·</i> <b>{students.length}</b> alunos</span></div>
    </div>

    {!isSupabaseConfigured && <div className="academic-notice">Conecte o Supabase para carregar ou cadastrar registros. Os dados de alunos ficam restritos a usuários autenticados conforme as políticas atuais.</div>}
    {error && isSupabaseConfigured && <div className="error-banner academic-message" role="alert">{error}<button type="button" onClick={() => void load()}>Tentar novamente</button></div>}
    {success && <div className="academic-success" role="status">{success}</div>}

    {canManage && isSupabaseConfigured && <div className="academic-forms">
      <form className="academic-form" onSubmit={event => void save(event, () => createClass(className.trim(), grade.trim(), shift.trim()), 'Turma cadastrada.', () => { setClassName(''); setGrade(''); setShift(''); })}>
        <div className="section-kicker">NOVA TURMA</div>
        <label>Nome da turma<input required maxLength={80} value={className} onChange={event => setClassName(event.target.value)} placeholder="Ex.: 6°A"/></label>
        <div className="academic-form-row"><label>Ano/série<input maxLength={80} value={grade} onChange={event => setGrade(event.target.value)} placeholder="Ex.: 6º ano"/></label><label>Turno<input maxLength={40} value={shift} onChange={event => setShift(event.target.value)} placeholder="Ex.: Manhã"/></label></div>
        <button className="button primary" disabled={saving}><Plus size={15}/> Cadastrar turma</button>
      </form>
      <form className="academic-form" onSubmit={event => void save(event, () => createStudent(classId, firstName.trim(), lastName.trim(), studentCode.trim()), 'Aluno cadastrado.', () => { setFirstName(''); setLastName(''); setStudentCode(''); })}>
        <div className="section-kicker">NOVO ALUNO</div>
        <div className="academic-form-row"><label>Nome<input required maxLength={120} value={firstName} onChange={event => setFirstName(event.target.value)} autoComplete="off"/></label><label>Sobrenome<input required maxLength={120} value={lastName} onChange={event => setLastName(event.target.value)} autoComplete="off"/></label></div>
        <div className="academic-form-row"><label>Turma<select required value={classId} onChange={event => setClassId(event.target.value)}><option value="">Selecione uma turma</option>{classes.map(item => <option value={item.id} key={item.id}>{item.name}</option>)}</select></label><label>Código escolar (opcional)<input maxLength={80} value={studentCode} onChange={event => setStudentCode(event.target.value)} autoComplete="off"/></label></div>
        <button className="button primary" disabled={saving || classes.length === 0}><Plus size={15}/> Cadastrar aluno</button>
      </form>
    </div>}

    <div className="academic-lists">
      <section className="academic-list-block">
        <div className="panel-head"><div><div className="section-kicker">ORGANIZAÇÃO ESCOLAR</div><h3>Turmas cadastradas</h3></div><span className="academic-total">{classes.length}</span></div>
        {loading ? <div className="table-empty">Carregando turmas…</div> : classes.length ? <div className="table-wrap"><table><thead><tr><th>TURMA</th><th>ANO/SÉRIE</th><th>TURNO</th></tr></thead><tbody>{classes.map(item => <tr key={item.id}><td><b className="team-name">{item.name}</b></td><td>{item.grade ?? '—'}</td><td>{item.shift ?? '—'}</td></tr>)}</tbody></table></div> : <div className="table-empty">Nenhuma turma cadastrada.</div>}
      </section>
      <section className="academic-list-block">
        <div className="panel-head"><div><div className="section-kicker">DADOS RESTRITOS</div><h3>Alunos cadastrados</h3></div><label className="search-box academic-search"><Search size={15}/><input aria-label="Pesquisar aluno ou turma" placeholder="Buscar nome, código ou turma" value={query} onChange={event => setQuery(event.target.value)}/></label></div>
        {loading ? <div className="table-empty">Carregando alunos…</div> : filteredStudents.length ? <div className="table-wrap"><table><thead><tr><th>ALUNO</th><th>TURMA</th><th>CÓDIGO</th></tr></thead><tbody>{filteredStudents.map(student => <tr key={student.id}><td><b className="team-name">{student.first_name} {student.last_name}</b></td><td>{classNames.get(student.class_id ?? '') ?? 'Sem turma'}</td><td>{student.student_code ?? '—'}</td></tr>)}</tbody></table></div> : <div className="table-empty">{query ? 'Nenhum aluno corresponde à busca.' : 'Nenhum aluno cadastrado.'}</div>}
      </section>
    </div>
  </div>;
}
