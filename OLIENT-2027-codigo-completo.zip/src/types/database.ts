export type Role = 'administrator' | 'organizer' | 'viewer';
export interface Team { id: string; name: string; slug: string; color: string | null; logo_path: string | null; active: boolean; created_at: string }
export interface Sport { id: string; name: string; description: string | null; status: string; category: string | null }
export interface Publication { id: string; title: string; body: string | null; published_at: string; kind: string }
export interface Standing { team_id: string; team_name: string; total_points: number; place: number }
export interface Profile { id: string; display_name: string; role: Role }
export interface SchoolClass { id: string; name: string; grade: string | null; shift: string | null; active: boolean; created_at: string }
export interface Student { id: string; class_id: string | null; first_name: string; last_name: string; student_code: string | null; active: boolean; deleted_at: string | null; created_at: string }
